/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
		
package lehurament.AggregateObservers;

import peersim.core.*;
import peersim.util.*;
import peersim.vector.*;
import peersim.config.*;

import java.lang.Math;


/**
 */
public class VectorObserverForGAP extends VectControlDouble {


protected static final String PAR_SUM = "sum";
private final String prefix;
public static final String ANSI_RED = "\u001B[31m";
public static final String ANSI_GREEN = "\u001B[32m";
public static final String ANSI_BLUE = "\u001B[34m";
public static final String ANSI_RESET = "\u001B[0m";
public static final String ANSI_WHITE = "\u001B[37m";
public static final String ANSI_YELLOW = "\u001B[33m";
private IncrementalStats AverageEstError;
private IncrementalStats AverageRealValueAgg;
private IncrementalStats AverageVariance;
private IncrementalStats AverageEstErrorPercent;
protected final boolean sum;

//--------------------------------------------------------------------------
//Initialization
//--------------------------------------------------------------------------

/**
 * Standard constructor that reads the configuration parameters.
 * Invoked by the simulation engine.
 * @param prefix the configuration prefix for this class
 */
public VectorObserverForGAP(String prefix) {

	super(prefix);
	this.prefix = prefix;
	sum = Configuration.getBoolean(prefix + "." + PAR_SUM);
    AverageEstError = new IncrementalStats();
    AverageRealValueAgg = new IncrementalStats();
    AverageVariance = new IncrementalStats();
    AverageEstErrorPercent = new IncrementalStats();
}

//--------------------------------------------------------------------------
// Methods
//--------------------------------------------------------------------------

/**
 */
public boolean execute() {
	IncrementalStats EstimateValue = new IncrementalStats();
	IncrementalStats RealValue = new IncrementalStats();
	IncrementalStats EstError = new IncrementalStats();
	double RealValueAgg=0;
	for (int j = 0; j < Network.size(); j++)
		if(Network.get(j).isUp())
		{
			Number v2 = getter2.get(j);
			if ( (!Double.isNaN(v2.doubleValue())) & (!Double.isInfinite(v2.doubleValue())) ) 
				RealValue.add( v2.doubleValue() );
		}		
	if (sum==true) 
				RealValueAgg=RealValue.getSum();
			else
				RealValueAgg=RealValue.getAverage();
    for (int i = 0; i < Network.size(); i++) 
    	if(Network.get(i).isUp())
	    {
	    	Number v1 = getter1.get(i);
			if ( (!Double.isNaN(v1.doubleValue())) & (!Double.isInfinite(v1.doubleValue())) ) 
			{ 
				EstimateValue.add( v1.doubleValue() );
				EstError.add(Math.abs(v1.doubleValue()-RealValueAgg));
			}
	    }
    if (!Double.isNaN(EstError.getAverage()))
    {
        AverageEstError.add(EstError.getAverage());
        AverageEstErrorPercent.add(EstError.getAverage()*100/RealValueAgg);
        AverageVariance.add(EstimateValue.getVar());
        AverageRealValueAgg.add(RealValueAgg);
    }
	System.out.println(ProtocolName+" "+ANSI_WHITE+" "+(CommonState.getTime()/step)+" "+ANSI_RESET+" "+RealValueAgg+" "+ANSI_RED+" "+EstimateValue.getAverage()+" "+ANSI_RESET+" "+EstimateValue.getN()+" "+AverageEstErrorPercent.getVar()+" "+EstError.getAverage()+" "+ANSI_YELLOW+" "+AverageEstError.getAverage()*100/AverageRealValueAgg.getAverage()+" "+ANSI_RESET+" "+(long) getter3.getLong(0));    
	return false;
}
}

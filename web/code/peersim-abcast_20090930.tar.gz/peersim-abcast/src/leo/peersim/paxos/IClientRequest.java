package leo.peersim.paxos;

public interface IClientRequest {
	
	public long getClientIssuingTime();
	
	public long getExecutionTime();

}

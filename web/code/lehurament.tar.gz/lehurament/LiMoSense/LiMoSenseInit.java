/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.LiMoSense;

import peersim.config.*;
import peersim.core.*;

public class LiMoSenseInit implements Control {
    // ------------------------------------------------------------------------
    // Constants
    // ------------------------------------------------------------------------
	private static final String PAR_PROT = "protocol";
	private static final String LINKABLE_PROT = "linkable";
	private static final String PAR_SUM = "sum";

    // ------------------------------------------------------------------------
    // Fields
    // ------------------------------------------------------------------------
    /** Protocol identifier; obtained from config property {@link #PAR_PROT}. */
	private final int pid;	
	private final boolean sum;
	private final int linkpid;
    // ------------------------------------------------------------------------
    // Constructor
    // ------------------------------------------------------------------------

    /**
     * Creates a new instance and read parameters from the config file.
     */
	public LiMoSenseInit(String prefix) {
		pid = Configuration.getPid(prefix + "." + PAR_PROT);
		linkpid = Configuration.getPid(prefix + "." + LINKABLE_PROT);
		sum = Configuration.getBoolean(prefix + "." + PAR_SUM);
	}
    // ------------------------------------------------------------------------
    // Methods
	public boolean execute() {
	for (int i = 0; i < Network.size(); i++) {
		LiMoSense prot = (LiMoSense) Network.get(i).getProtocol(pid);
		Linkable linkable = (Linkable) Network.get(i).getProtocol(linkpid);
		for (int j = 0; j < linkable.degree(); ++j) {
		Node peer = linkable.getNeighbor(j);
		prot.newEntry(peer);
	}
	if (sum) { 
		if (i==0) prot.est.weight=1;
	} else prot.est.weight=1;
		prot.setValue(0);
	}
	return false;
}
}

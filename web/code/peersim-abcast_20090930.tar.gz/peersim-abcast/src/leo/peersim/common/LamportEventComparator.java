package leo.peersim.common;

import java.util.Comparator;

import org.apache.log4j.Logger;

/**
 * Defines a total order over {@link LamportEvent}
 */
public class LamportEventComparator implements Comparator<LamportEvent> {
	
	private Logger logger = Logger.getLogger(this.getClass().getName());
	
	public LamportEventComparator() {
		
	}

	/**
	 * 
	 */
	@Override
	public int compare(LamportEvent e1, LamportEvent e2) {
		
		if ( e1.getLamportTimestamp() == e2.getLamportTimestamp() ) {
			if (e1.getLamportNodeID() < e2.getLamportNodeID()) {
				return -1;
			} else if (e1.getLamportNodeID() > e2.getLamportNodeID()) {
				return 1;
			} else {
				//if happens, one of them it's not agreed
				//logger.error("Error: events with same id and same timestamp!!");
				//logger.error("e1:" + e1.getLamportTimestamp() + "@" + e1.getLamportNodeID() + ", e2:" + e2.getLamportTimestamp() + "@" + e2.getLamportNodeID());
				return 0;
			}
		} else if (e1.getLamportTimestamp() < e2.getLamportTimestamp()) {
			return -1;
		} else {
			return 1;
		}
	}
}


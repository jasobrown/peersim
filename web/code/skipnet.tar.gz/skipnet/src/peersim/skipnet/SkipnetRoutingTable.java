package peersim.skipnet;

import java.util.Vector;

import peersim.core.CommonState;
import peersim.core.Node;
import peersim.skipnet.SkipnetUtil.*;
import peersim.skipnet.messages.*;


/**
 * Represents the peersim.extras.am.skipnet routing table.
 * 
 * @author Rodolfo Cartas
 */
public class SkipnetRoutingTable {

	// --------------------------------------------------------------------------
	// Fields
	// --------------------------------------------------------------------------
	private static int height;

	private static int pid;

	private Vector<Node> neighbors;

	Node[] left;

	Node[] right;

	protected Vector rightLeafset, leftLeafset;

	Node localnode;

	// --------------------------------------------------------------------------
	// Initialization
	// --------------------------------------------------------------------------
	public SkipnetRoutingTable(Node localnode, int height, int skipnetpid) {
		SkipnetRoutingTable.height = height;
		SkipnetRoutingTable.pid = skipnetpid;
		this.localnode = localnode;

		neighbors = new Vector<Node>();

		left = new Node[height];
		right = new Node[height];
		for (int i = 0; i < height; i++) {
			left[i] = localnode;
			right[i] = localnode;
		}
	}

	// --------------------------------------------------------------------------
	// Methods
	// --------------------------------------------------------------------------
	public Node[] getNeighbors(Direction direction) {
		if (direction == Direction.LEFT)
			return left;
		else
			return right;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();

		buffer.append("Routing table in "
				+ SkipnetUtil.getSkipnetName(localnode, pid).getIdentifier()
				+ " (" + SkipnetUtil.getNumericId(localnode, pid).toString()
				+ ") @ " + CommonState.getTime() + "\n");
		for (int i = left.length - 1; i >= 0; i--) {
			buffer.append(i);
			buffer.append("|");
			buffer.append(SkipnetUtil.getSkipnetName(left[i], pid)
					.getIdentifier()
					+ "("
					+ SkipnetUtil.getNumericId(left[i], pid).toString()
					+ ")");
			buffer.append("|");
			buffer.append(SkipnetUtil.getSkipnetName(right[i], pid)
					.getIdentifier()
					+ "("
					+ SkipnetUtil.getNumericId(right[i], pid).toString()
					+ ")");
			buffer.append("\n");
		}

		return buffer.toString();
	}

	public void print() {
		StringBuffer buffer = new StringBuffer();
		buffer.append(toString());
		buffer.append("---------------------------\n");
		System.out.print(buffer.toString());
	}

	public boolean changeRoutingTableElement(Direction dir, int level,
			Node neighbor) {
		Node[] table = getNeighbors(dir);

		if (neighbor != null && !table[level].equals(neighbor)) {
			table[level] = neighbor;
			return true;
		} else
			return false;
	}

	public void flattenRoutingTable() {
		neighbors = new Vector<Node>();

		flattenRoutingTable(Direction.LEFT);
		flattenRoutingTable(Direction.RIGHT);
	}

	private void flattenRoutingTable(Direction dir) {
		Node table[] = getNeighbors(dir);

		for (int i = 0; i < table.length; i++) {
			if (!neighbors.contains(table[i]))
				neighbors.add(table[i]);
		}
	}

	public Node getNeighbor(Direction dir, int height) {
		return getNeighbors(dir)[height];
	}

	public int getHeight() {
		return height;
	}

	public Vector<Node> getNeighbors() {
		return neighbors;
	}

	public void insertIntoRings(Node[] msgRingNbrLeft, Node[] msgRingNbrRight) {
		mix(Direction.LEFT, msgRingNbrLeft);
		mix(Direction.RIGHT, msgRingNbrRight);
		flattenRoutingTable();
	}

	public void pingNeighbors() {
		ping(Direction.LEFT, left);
		ping(Direction.RIGHT, right);

	}

	private void ping(Direction dir, Node[] ngbrs) {
		for (int i = 0; i < height; i++)
			if (!localnode.equals(ngbrs[i])) {
				SkipnetMessage ping = new Ping(localnode, getNeighbor(dir, i),
						i, SkipnetUtil.inverseDirection(dir));
				getLocalSkipnet().sendMessage(ping);
			}
	}

	private void mix(Direction dir, Node[] newlist) {
		for (int i = 0; i < height; i++)
			if (changeRoutingTableElement(dir, i, newlist[i])) {
				SkipnetMessage insertion = new NeighborInsertionMessage(
						localnode, getNeighbor(dir, i), i, dir);
				getLocalSkipnet().sendMessage(insertion);
			}
	}

	public void verifyPing(Ping ping) {
		if (ping.ack) {
			Direction dir = SkipnetUtil.inverseDirection(ping.direction);
			System.out.println(getLocalSkipnet() + " pointing to "
					+ getSkipnet(ping.source) + " dir " + dir + " at level "
					+ ping.level + " is wrong.");
			System.out.println("It should point to "
					+ getSkipnet(ping.correctNeighbor));

			if (SkipnetName.liesBetween(getLocalSkipnet().localname,
					getSkipnet(ping.correctNeighbor).localname,
					getSkipnet(ping.source).localname, dir)) {
				changeRoutingTableElement(dir, ping.level, ping.correctNeighbor);
				SkipnetMessage insertion = new NeighborInsertionMessage(
						localnode, ping.correctNeighbor, ping.level, dir);
				getLocalSkipnet().sendMessage(insertion);
			} else if (SkipnetName.liesBetween(
					getSkipnet(ping.correctNeighbor).localname,
					getLocalSkipnet().localname,
					getSkipnet(ping.source).localname, dir)) {
				//in between
				System.out.println("in between");
				SkipnetMessage insertion = new NeighborInsertionMessage(
						localnode, ping.source, ping.level, dir);
				getLocalSkipnet().sendMessage(insertion);
				changeRoutingTableElement(SkipnetUtil.inverseDirection(dir),
						ping.level, ping.correctNeighbor);
				insertion = new NeighborInsertionMessage(localnode,
						ping.correctNeighbor, ping.level, SkipnetUtil
								.inverseDirection(dir));
				getLocalSkipnet().sendMessage(insertion);
			}

		} else {
			Node ngbr = getNeighbor(ping.direction, ping.level);
			if (!SkipnetUtil.getSkipnetName(ping.source, pid).equals(
					SkipnetUtil.getSkipnetName(ngbr, pid))) {
				// the source pinging is not the localnode neighbor at level
				// ping.level
				ping.createAck(ngbr);
				getLocalSkipnet().sendMessage(ping);
			}
		}
	}

	private Skipnet getLocalSkipnet() {
		return SkipnetUtil.getSkipnetProtocol(localnode, pid);
	}

	private Skipnet getSkipnet(Node node) {
		return SkipnetUtil.getSkipnetProtocol(node, pid);
	}

	public void setLeafset(SkipnetUtil.Direction dir, Vector leafset) {
		if (dir.equals(SkipnetUtil.Direction.LEFT))
			leftLeafset = leafset;
		else
			rightLeafset = leafset;
	}

	public Vector getLeafset(SkipnetUtil.Direction dir) {
		if (dir.equals(SkipnetUtil.Direction.LEFT))
			return leftLeafset;
		else
			return rightLeafset;
	}

	public Node tryRouteOneHop(SkipnetName destination) {
		int cmp = destination.compareTo(getSkipnet(localnode).getLocalname());
		Vector half;
		if (cmp < 0) {
			half = leftLeafset;
		} else if (cmp == 0) {
			return localnode;
		} else {
			half = rightLeafset;
		}

		if (half == null)
			return null;

		//see if the destination in on the leafset
		for (int i = 0; i < half.size(); i++) {
			Node nbr = (Node) half.get(i);
			if (destination.equals(getSkipnet(nbr).getLocalname()))
				return nbr;
		}

		return null;
	}

}

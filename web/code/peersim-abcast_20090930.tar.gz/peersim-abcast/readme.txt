
SYNOPSIS

ant exp1	ABCast demo, 5 replicas, 3 requests A,B,C at steps of 50 ms to random replica, latency [40,120] ms

ant exp2	ABCast load test, latency [5,25] ms 

ant exp3	Paxos demo, 3 replicas, 3 requests A,B,C to selected replica, latency [40,120] ms

ant exp4	Paxos load test, latency [5,25] ms 

ant exp5	Paxos failure of non-leader replica example, 3 replicas

NOTES
requires:
	Apache Ant (tested with version 1.7.1)
	Java Development Kit (tested with version Sun JDK 1.6.0_13)

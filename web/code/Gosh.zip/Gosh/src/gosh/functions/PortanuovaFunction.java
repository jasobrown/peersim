/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.config.*;

// d=? ; opt.=0.0
public class PortanuovaFunction extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;

// d=?; opt.=0.0
public PortanuovaFunction(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);
	rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = -5;
    rangeMax[i] = 5;
  }
}

public double eval(double[] x)
{
  double t,Result = 0.0;
  for ( int i = 0; i < d; i++ ) {
    t = (i%2!=0)? Math.sin(x[i]) : Math.cos(x[i]);
    Result += t * t;
  }
//  System.out.print(CommonState.getTime() + ": f(" + x[0]);
//  for (int i=1; i < d; i++) {
//  	System.out.print(", " + x[i]);
//  }
//  System.out.println(") = " + Result);
  return Result;
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;

}
}

package peersim.skipnet.messages;

import peersim.core.Node;
import peersim.skipnet.SkipnetUtil.*;

public class Ping extends SkipnetMessage {

	public int level;
	public Direction direction;
	public Node correctNeighbor;
	public boolean ack = false;
	
	public Ping(Node source, Node nextHop, int level, Direction dir) {
		super(source, nextHop);
		this.level = level;
		this.direction = dir;
	}
	
	public void createAck(Node correctNeighbor) {
		this.correctNeighbor = correctNeighbor;
		Node aux = source;
		source = nextHop;
		nextHop = aux;
		ack = true;
	}

}

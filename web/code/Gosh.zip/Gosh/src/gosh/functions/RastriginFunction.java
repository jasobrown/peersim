/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.PrintWriter;
import peersim.config.*;
//import peersim.core.CommonState;
//import java.lang.StrictMath;

// d=30 opt.=0.0
public class RastriginFunction extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;

public RastriginFunction(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);
	rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = -10;//-5.12;//
    rangeMax[i] = 10;//5.12; /
  }
}

public double eval(double[] x)
{
  double Result = 0.0;
  for ( int i = 0; i < d; i++ ) {
   Result +=(x[i]*x[i]) - 10.0*StrictMath.cos(2.0*StrictMath.PI*x[i])+10.0;
  }
//  try
//  {
//    PrintWriter output = new PrintWriter(new FileWriter("Rastrigin.txt",false));
//    output.print(CommonState.getTime() + ": f(" + x[0]);
//    for (int i=1; i < d; i++) {
//      output.print(", " + x[i]);
//    }
//    output.println(") = " + Result);
//  } catch (IOException ex)
//  { ex.printStackTrace();
//  }
  return Result;
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;

}
}

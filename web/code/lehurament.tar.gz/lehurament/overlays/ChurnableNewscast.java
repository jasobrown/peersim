/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
package lehurament.overlays;

import lehurament.peersim.dynamics.ChurnControl;
import lehurament.peersim.dynamics.Churnable;
import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Fallible;
import peersim.core.Network;
import peersim.core.Node;
import peersim.edsim.EDSimulator;

import peersim.config.*;
import peersim.core.*;
/**
 * This is a simple extension of the EDProtocol-based Newscast
 * which supports the modeling of churn.
 *
 * @author Róbert Ormándi
 * @author Lehel Nyers
 *
 */
public class ChurnableNewscast extends EdNewscastWithInits implements Churnable {
  protected int cacheSize;
  private long sessionLength = ChurnControl.INIT_SESSION_LENGTH;
  /** @hidden */
  private final String prefix;
  
  public ChurnableNewscast(String prefix) {
    super(prefix);
    cacheSize = Configuration.getInt(prefix + ".cache");
    this.prefix = prefix;
  }
  
  public ChurnableNewscast clone() {
    return new ChurnableNewscast(prefix);
  }

  public long getSessionLength() {
    return sessionLength;
  }

  public void setSessionLength(long sessionLength) {
    this.sessionLength = sessionLength;
  }

  public void initSession(Node node, int protocol) {
  }
  public void forUpNodes(Node node, int protocol) {
    deleteNeighbors();
    while (degree() < cacheSize) {
      int onlineNeighbor = CommonState.r.nextInt(Network.size());
      if ( Network.get(onlineNeighbor).getFailState() != Fallible.DOWN
          && Network.get(onlineNeighbor).getFailState() != Fallible.DEAD
          && Network.get(onlineNeighbor).getID() != node.getID()) {
        addNeighbor(Network.get(onlineNeighbor));
      }
    }
    startInits(node);
    EDSimulator.add(0, CycleMessage.inst, node, protocol);
  }
  public void forDownNodes(Node node, int protocol) {
  }
}

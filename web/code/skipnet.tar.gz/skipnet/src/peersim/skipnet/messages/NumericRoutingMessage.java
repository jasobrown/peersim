package peersim.skipnet.messages;

import peersim.core.Node;
import peersim.skipnet.*;

public class NumericRoutingMessage extends SkipnetMessage implements MessageStatisticData {

	public int ringLevel = -1;

	public boolean finalDestination;

	public Node bestNode;

	public Node startNode;

	public Node ringNbrLeft[];

	public Node ringNbrRight[];

	public NumericId destination;
	
	protected boolean succesfullookup;

	public void destinationReached(Skipnet skipnet) {
		succesfullookup = destination.equals(skipnet.getLocalNumId());

		super.destinationReached(skipnet);
	}
	
	public NumericRoutingMessage(Node source, Node nextHop) {
		super(source, nextHop);
	}

	public boolean isSuccesfullookup() {
		return succesfullookup;
	}

}

/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.AggregateEDggapRestart;

import java.lang.Math;
import peersim.config.*;
import peersim.core.*;
import peersim.cdsim.CDProtocol;
import peersim.edsim.EDProtocol;
import lehurament.peersim.dynamics.Churnable;
import lehurament.peersim.dynamics.ChurnControl;
/**
* Event driven version of Restart epidemic averaging.
*/
public class AggregateEDggapRestart extends VariableHolderGGap
implements CDProtocol, EDProtocol, Churnable{

	private static final String PAR_RESTART = "restart";
	private static final String PAR_SUM = "sum";
	private static final String PAR_STEP = "step";
	public static long packetCount=0;
	private long nodeID;
	private  int step;
	private int restart;
	public int epochID=0;
	public int epochFreqCount=0;
	public boolean sync=false;
	boolean syncInProgress=false;
	boolean sum;
	static long timestamp=1;
	long upTimestamp=-1;
	long downTimestamp=-1;
	private int minParticipateCounter=0;
	private long sessionLength = ChurnControl.INIT_SESSION_LENGTH;
	int pid;
//--------------------------------------------------------------------------
// Initialization
//--------------------------------------------------------------------------
/**
 * @param prefix string prefix for config properties
 */
public AggregateEDggapRestart(String prefix) { 
	super(prefix);
	restart = Configuration.getInt(prefix + "." + PAR_RESTART);
	sum = Configuration.getBoolean(prefix + "." + PAR_SUM);
    step = Configuration.getInt(prefix + "." + PAR_STEP);
}

//--------------------------------------------------------------------------
// methods
//--------------------------------------------------------------------------

public double getAverage() {
	AggregateEDggapRestart p = (AggregateEDggapRestart) Network.get(0).getProtocol(pid);
	if (p.sync) {
		return p.showvalue/p.showweight;
	}
	else return Double.NaN;
}
public void setRealValue(double value) {
	this.realvalue=value;
}

public long getPacketCount() {
	return packetCount;
}
void bouncePacketBack(Node node, int pid, ggapRestartPacket e) {
	ggapRestartPacket p = new ggapRestartPacket(e.value,e.weight,e.epochID,e.from);
	p.epochID=e.epochID;
	p.from=node;
	SendPacketToNeighbours.sendPacketToNode(node,e.from,pid, p);
}
void Observe(Node node, int pid ) {
	double weightsum =0;
	double valuesum=0;
	for (int i = 0; i < Network.size(); i++) {
 	AggregateEDggapRestart prot = (AggregateEDggapRestart) Network.get(i).getProtocol(pid);
 	valuesum+=prot.value;
 	weightsum+=prot.weight;
 	System.out.println(Network.get(i).getID());
 	System.out.println("VALUE = "+prot.value+"SHOWVALUE = "+prot.showvalue);
	System.out.println("WEIGHT =  "+prot.weight+"SHOWWEIGHT =  "+prot.showweight);
	System.out.println("AVERAGE =  "+prot.getAverage());
	}
	if  (node.getID()==0) 
	{
	System.out.println("VALUESUM "+valuesum);
	System.out.println("WEIGHTSUM "+weightsum);
	} 
}
void  broadcastParts(Node node, int pid ) 
{
	double startvalue = this.value;
	double startweight = this.weight;
	int degree = 0;
	long nodeID = node.getID();
	Linkable linkable = (Linkable) node.getProtocol(FastConfig.getLinkable(pid));
	for (int i = 0; i < linkable.degree(); ++i) {
		Node peer = linkable.getNeighbor(i);
		if (!peer.isUp()) continue;
		degree+=1;	
	}
	double part = 1f / (degree+1);
	if (degree > 0) 
	for (int i = 0; i < linkable.degree(); ++i) {
		Node peer = linkable.getNeighbor(i);
        if (!peer.isUp()) continue;
		int peerID= (int) peer.getID();
		AggregateEDggapRestart prot = (AggregateEDggapRestart) peer.getProtocol(pid);
		this.value -= startvalue*part;
		this.weight -= startweight*part;
		ggapRestartPacket p =	new ggapRestartPacket(startvalue*part,startweight*part,epochID,node);
		p.restart=restart;
		p.epochFreqCount=epochFreqCount;
		SendPacketToNeighbours.sendPacketToNode(node,peer,pid, p);
	}
}
boolean  isRestartFirstTime(Node node, int pid ) 
{
	if (epochFreqCount==restart) {
		if (minParticipateCounter>Math.round(restart*0.6) && (syncInProgress==false)) 
		{
			this.showvalue=this.value;
			this.showweight=this.weight;
		}
		this.value=this.realvalue;
		if  (sum==true) { 
			if (node.getID()==0) this.weight=1; else this.weight=0;
		} else this.weight=1;
		epochFreqCount=0;
		minParticipateCounter=0;
		epochID+=1;
		timestamp=CommonState.getTime()/step;
		syncInProgress=false;
		sync=true;
		return true;
		}
	minParticipateCounter+=1;
	epochFreqCount+=1;
	return false;
}
/**
 * This is the standard method the define periodic activity.
 * The frequency of execution of this method is defined by a
 * {@link peersim.edsim.CDScheduler} component in the configuration.
 */
public void nextCycle( Node node, int pid ) {
	this.pid= pid;	
	isRestartFirstTime(node,  pid );
	if (sync==true && syncInProgress==false) broadcastParts(node, pid );
}
/**
* This is the standard method to define to process incoming messages.
*/
public void processEvent( Node node, int pid, Object event ) {
	ggapRestartPacket e = (ggapRestartPacket)event;
	nodeID=node.getID();
	if (e.type==e.type.NEW) {
		if (epochID!=0)
			{
				ggapRestartPacket p=new ggapRestartPacket();
				p.type=p.type.NEWSYNC;
				p.restart=restart;
				p.epochFreqCount=epochFreqCount;
				p.epochID=epochID;
				p.from=node;
				p.value=this.showvalue;
				p.weight=this.showweight;
				//Send the packer NEWSYNC
				lehurament.AggregateEDggapRestart.SendPacketToNeighbours.sendPacketToNode(node,e.from, pid, p);
		}
	}
	if (e.type==e.type.NEWSYNC) {
		if (!sync) {
			restart=e.restart;
			epochFreqCount=e.epochFreqCount;
			epochID=e.epochID;
		}
	}
	if (e.type==e.type.FAIL) {
	}
	if (e.type==e.type.UPDATELOCAL) {
		this.realvalue = e.value;
	}
	if (e.type==e.type.UPDATE) {
		if (!sync) {
			bouncePacketBack(node, pid, e);
		} else {
				if (e.epochID==epochID)
				{
					if (syncInProgress==true) { bouncePacketBack(node, pid, e); return; }
					this.value += e.value;
					this.weight += e.weight;
				}
				if (e.epochID>epochID) 
				{
				    epochFreqCount=restart;
				    epochID=e.epochID-1; 
				    if (upTimestamp==CommonState.getTime()/step) syncInProgress=true;
				    isRestartFirstTime(node, pid ) ;
				    if (upTimestamp==CommonState.getTime()/step) {
						syncInProgress=true;
						bouncePacketBack(node, pid, e);
						return;
					}
				    this.value += e.value;
				    this.weight += e.weight;
				}
				if (e.epochID<epochID) 
				{
						return;
				}
		}			
	}
}

public void initSession(Node node, int protocol) {
}
public void forUpNodes(Node node, int protocol) {
	upTimestamp=CommonState.getTime()/step;
}
public void forDownNodes(Node node, int protocol) {
	downTimestamp=CommonState.getTime()/step;
}
public long getSessionLength() {
  return sessionLength;
}
public void setSessionLength(long sessionLength) {
  this.sessionLength = sessionLength;
}
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------
}



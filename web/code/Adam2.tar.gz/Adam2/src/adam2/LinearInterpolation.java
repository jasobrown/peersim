package adam2;


public class LinearInterpolation implements Interpolation {

	private double[] x;

	private double[] y;

	private int N;
	
	// Check if assertions are enabled
	protected static boolean assertionsEnabled = false;
	static { assert assertionsEnabled = true; } 

	/*
	 * Create a function approximation given a set of points.
	 * Assumes that the points are sorted by their x values.
	 */
	public LinearInterpolation(double[] x, double[] y) {
		this.x = x;
		this.y = y;
		this.N = x.length;
		
		assert x.length == y.length;
		assert x.length > 0;
		if (assertionsEnabled) {
			// Check if the points are sorted
			double prev = Double.NEGATIVE_INFINITY;
			for (double cur : x) {
				assert cur >= prev;
				prev = cur;
			}
		}
	}

	/*
	 * Create a function approximation given a set of points.
	 * Assumes that the points are sorted by their x values.
	 */
	public LinearInterpolation(int[] x, double[] y) {
		this(intToDouble(x), y);
	}

	/*
	 * Create a function approximation given a set of points.
	 * Assumes that the points are sorted by their x values.
	 */
	public LinearInterpolation(double[] x, int[] y) {
		this(x, intToDouble(y));
	}

	/*
	 * Approximate the function value for a given argument.
	 * @see adam2.Interpolation#interpolate(double)
	 */
	public double interpolate(double xx) {
		if (xx <= x[0]) {
			return y[0];
		}
		if (xx >= x[N - 1]) {
			return y[N - 1];
		}
		int i = binarySearch(xx, x);
		assert i < N - 1;
		return y[i] + (xx - x[i]) / (x[i + 1] - x[i]) * (y[i + 1] - y[i]);
	}

	// Find the closest element in a sorted array preceding a given value. 
	protected int binarySearch(double value, double[] sorted) {
		int from = 0;
		int to = sorted.length;
		while (to - from > 1) {
			int middle = (from + to) / 2;
			if (sorted[middle] <= value) {
				from = middle;
			}
			else {
				to = middle;
			}			
		}
		return from;
	}

	// Array type conversion
	protected static double[] intToDouble(int[] intArray) {
		double[] doubleArray = new double[intArray.length];
		for (int i = 0; i < intArray.length; i++) {
			doubleArray[i] = intArray[i];
		}
		return doubleArray;
	}
	
	
	// For testing...
	public static final void main(String[] args) {
		// Test
		double[] x = { 1, 2, 2, 2, 3, 3, 4, 5 };
		double[] y = { 2, 4, 4, 4, 6, 6, 8, 10 };
		LinearInterpolation li = new LinearInterpolation(x, y);
		double yy = li.interpolate(2.5);
		System.out.println("Test: " + yy);
	}
	
}

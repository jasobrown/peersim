package peersim.skipnet.messages;

import peersim.core.Node;
import peersim.skipnet.*;

public class ErrorMessage extends SkipnetMessage {
	
	public SkipnetUtil.Errors error;
	
	public ErrorMessage(SkipnetUtil.Errors error, Node source, Node nextHop) {
		super(source, nextHop);
		this.error = error;
	}

}

package leo.peersim.common;

import java.util.Vector;

import leo.peersim.paxos.IClientRequest;

public interface IFSAutomaton {
	
	//FIXME
	//public boolean submitCommand(String commandName);
	
	/**
	 * Returns the history of the commands in the order executed by the FSM
	 */
	public Vector<String> getCommandHistory();
	
	public Vector<IClientRequest> getClientRequests();

}

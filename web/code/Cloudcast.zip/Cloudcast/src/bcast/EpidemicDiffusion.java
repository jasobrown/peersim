/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package bcast;

import peersim.config.*;
import peersim.core.*;
import peersim.edsim.*;
import peersim.transport.*;
import cloudcast.*;

public class EpidemicDiffusion implements EDProtocol, Infectable
{

// /////////////////////////////////////////////////////////////////////////////
// Config parameters
// /////////////////////////////////////////////////////////////////////////////

/**
 * Linkable protocol to select random peers.
 * @config
 */
private static final String PAR_LINKABLE = "linkable";

/**
 * Transport protocol.
 * @config
 */
private static final String PAR_TRANSPORT = "transport";

/**
 * Probability of becoming removed.
 * @config
 */
private static final String PAR_PROB = "prob";

/**
 * Anti-entropy cycle length.
 * @config
 */
private static final String PAR_ENTROPY = "period.entropy";

/**
 * Rumor mongering cycle length.
 * @config
 */
private static final String PAR_RUMOR = "period.rumor";

/**
 * Maximum number of messages that can be sent.
 * @config
 */
private static final String PAR_MESSAGES = "messages";

// /////////////////////////////////////////////////////////////////////////////
// Configuration data
// /////////////////////////////////////////////////////////////////////////////

private class ConfigData
{

/** Protocol id */
final int pid;

/** Linkable id */
final int lid;

/** Transport id */
final int tid;

/** Probability of stopping */
final double prob;

/** Rumor mongering cycle length */
final int period_rumor;

/** Anti-entropy cycle length */
final int period_entropy;

/** Number of messages */
final int messages;

ConfigData(String prefix)
{
	pid = CommonState.getPid();
	lid = Configuration.getPid(prefix + "." + PAR_LINKABLE);
	tid = Configuration.getPid(prefix + "." + PAR_TRANSPORT);
	period_rumor = Configuration.getInt(prefix + "." + PAR_RUMOR);
	period_entropy = Configuration.getInt(prefix + "." + PAR_ENTROPY);
	prob = Configuration.getDouble(prefix + "." + PAR_PROB);
	messages = Configuration.getInt(prefix + "." + PAR_MESSAGES);
}

}

/** Configuration data */
private static ConfigData config;

// /////////////////////////////////////////////////////////////////////////////
// Constants
// /////////////////////////////////////////////////////////////////////////////

private static final Object TIMEOUT_RUMOR = new Object();

private static final Object TIMEOUT_ENTROPY = new Object();

private static final int SUSCEPTIBLE = 0;

private static final int INFECTED = 1;

private static final int REMOVED = 2;

private static Integer[] msgs;

// /////////////////////////////////////////////////////////////////////////////
// Static fields
// /////////////////////////////////////////////////////////////////////////////

private static long[] msgtime;

// /////////////////////////////////////////////////////////////////////////////
// Fields
// /////////////////////////////////////////////////////////////////////////////

/**
 * Time at which the node has been created
 */
private long time;

/**
 * Infection status of the various messages
 */
byte[] status;


/**
 * Maximum message identifier seen so far.
 */
int maxmsg;

/**
 * Number of rumor mongering messages received
 */
int rumorcount;

/**
 * Number of anti-entropy messages sent to the cloud
 */
int cloudcount = 0;



/**
 * Delay between the creation of node and the actual delivery of the
 * message
 */
int[] delay;


// /////////////////////////////////////////////////////////////////////////////
// Constructors
// /////////////////////////////////////////////////////////////////////////////

public EpidemicDiffusion(String prefix)
{
	config = new ConfigData(prefix);
	msgs = new Integer[config.messages];
	msgtime = new long[config.messages];
	for (int i = 0; i < msgs.length; i++) {
		msgs[i] = new Integer(i);
	}
}

private EpidemicDiffusion()
{
	time = CommonState.getTime();
	status = new byte[config.messages];
	delay = new int[config.messages];
	maxmsg = -1;
	for (int i = 0; i < status.length; i++)
		status[i] = SUSCEPTIBLE;

	/*
	 * Nodes are started at random times. They share the same starting time,
	 * but different cycle length.
	 */
	int r = CommonState.r.nextInt(config.period_rumor);
	EDSimulator.add(r, TIMEOUT_RUMOR, CommonState.getNode(), CommonState.getPid());
	EDSimulator.add(r, TIMEOUT_ENTROPY, CommonState.getNode(), CommonState.getPid());
}

public Object clone()
{
	return new EpidemicDiffusion();
}

// /////////////////////////////////////////////////////////////////////////////
// Methods
// /////////////////////////////////////////////////////////////////////////////

public void processEvent(Node lnode, int pid, Object event)
{
	Linkable l = (Linkable) lnode.getProtocol(config.lid);
	Transport t = (Transport) lnode.getProtocol(config.tid);

	if (event == TIMEOUT_RUMOR && lnode != Cloud.cloud) {
		EDSimulator.add(config.period_rumor, TIMEOUT_RUMOR, lnode, pid);

		for (int i = 0; i <= maxmsg; i++) {
			if (status[i] == INFECTED) {
				Node rnode = selectRegularPeer(lnode);
				if (rnode != null) {
					t.send(lnode, rnode, msgs[i], pid);
					rumorcount++;
				}

				float chance = CommonState.r.nextFloat();
				if (chance < config.prob)
					status[i] = REMOVED;
			
			}
		}

	} else if (event == TIMEOUT_ENTROPY && lnode != Cloud.cloud) {
		EDSimulator.add(config.period_entropy, TIMEOUT_ENTROPY, lnode, pid);

		Node rnode = selectPeer(lnode);
		if (rnode != null) {
			EntropyMessage msg = EntropyMessage.getMessage(status, maxmsg, lnode);
			t.send(lnode, rnode, msg, pid);
		}
		if (rnode == Cloud.cloud) {
			cloudcount++;
		}

	} else if (event instanceof Integer) {

    assert (lnode != Cloud.cloud);		
		int i = ((Integer) event).intValue();
		if (i > maxmsg)
			maxmsg = i;
		if (status[i] == SUSCEPTIBLE) {
			status[i] = INFECTED;
			delay[i] = (int) (CommonState.getTime() - Math.max(time, msgtime[i]));
		}

	} else if (event instanceof EntropyMessage) {

		// Local update
		EntropyMessage msg = (EntropyMessage) event;
		if (msg.maxmsg > maxmsg)
			maxmsg = msg.maxmsg;
		for (int i = 0; i <= maxmsg; i++) {
			if (msg.status[i] != SUSCEPTIBLE && status[i] == SUSCEPTIBLE) {
				// status[i] = INFECTED; // In this case, a push is started even after an anti-entropy message 
				status[i] = msg.status[i]; // In this case, a push is started only if it was already active at the sender
				delay[i] = (int) (CommonState.getTime() - Math.max(time, msgtime[i]));
			}
		}

		// Reply if the message was a request.
		if (msg.sender != null) {
			EntropyMessage reply = EntropyMessage.getMessage(status, maxmsg, null);
			t.send(lnode, msg.sender, reply, pid);
		}

		// Release the message for future re-use
		EntropyMessage.release(msg);

	}
}

/**
 * This method is called externally, to active the sending of a message.
 */
public void setInfected(int index)
{
	if (index > maxmsg)
		maxmsg = index;
	status[index] = INFECTED;
	msgtime[index] = CommonState.getTime();
}

public boolean isInfected(int index)
{
	return status[index] != SUSCEPTIBLE;
}

/**
 * This node returns a random peer, or null if no peer is available.
 * 
 * @param lnode
 * @return
 */
public Node selectPeer(Node lnode)
{
	Linkable linkable = (Linkable) lnode.getProtocol(config.lid);
	Node n = null;
	if (linkable.degree() > 0) {
		int r = CommonState.r.nextInt(linkable.degree());
		n = linkable.getNeighbor(r);
	}
	return n;
}

/**
 * This node returns a random peer different from the cloud, or null if no peer is 
 * available.
 * 
 * @param lnode
 * @return
 */
public Node selectRegularPeer(Node lnode)
{
	Linkable linkable = (Linkable) lnode.getProtocol(config.lid);

	if (linkable.degree() == 0 || (linkable.degree() == 1 && linkable.getNeighbor(0) == Cloud.cloud))
		return null;

	Node n = Cloud.cloud;
	while (n == Cloud.cloud) {
		int r = CommonState.r.nextInt(linkable.degree());
		n = linkable.getNeighbor(r);
	}
	return n; 
}

public int getCloudCount()
{
	// We don't want to count the activity of the cloud. It will be counted in a different way
	if (Cloud.cloud == CommonState.getNode()) 
		throw new UnsupportedOperationException();
	return cloudcount;
}

public int getDelay(int index)
{
	// We don't want to count the activity of the cloud. It will be counted in a different way
	if (Cloud.cloud == CommonState.getNode() || delay[index] < 0) 
		throw new UnsupportedOperationException();
	int temp = delay[index];
	delay[index] = -1;
	return temp;
}

public int getRumorCount()
{
	// We don't want to count the activity of the cloud. It will be counted in a different way
	if (Cloud.cloud == CommonState.getNode()) 
		throw new UnsupportedOperationException();
	return rumorcount;
}

}

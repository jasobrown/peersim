package leo.peersim.common;

import peersim.core.CommonState;

/**
 * 
 * @author leo
 */
public class FSMOperationRequest implements Cloneable {
	
	private String requestorClient; //FIXME
	private String operation;
	
	private long debug_issuingTime = -1;
	private long debug_executedTime = -1;
	
	public FSMOperationRequest(String richiedente, String operation) {
		this.requestorClient = richiedente;
		this.operation = operation;
		this.debug_issuingTime = CommonState.getTime();
	}
	
	public FSMOperationRequest(String richiedente, String operation, long issuingTime) {
		this.requestorClient = richiedente;
		this.operation = operation;
		this.debug_issuingTime = issuingTime;
	}
	
	@Override
	public FSMOperationRequest clone() {
		FSMOperationRequest req = null;
		try {
			req = (FSMOperationRequest) super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return req;
	}
	
	public String getRichiedente() {
		return this.requestorClient;
	}
	
	public String getOperazione() {
		return this.operation;
	}
	
	@Override
	public String toString(){
		return this.operation;
	}

	public long getDebug_issuingTime() {
		return this.debug_issuingTime;
	}
	
	public void setExecutedTime(long exTime) {
		this.debug_executedTime = exTime;
	}
	
	public long get_DebugExecutedTime() {
		return this.debug_executedTime;
	}
	
	public String debugToString() {
		return super.toString();
	}
	
}
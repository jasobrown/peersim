/*
 * Copyright (c) 2003 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package superpeer;

import java.util.*;
import peersim.core.*;


/**
 * 
 *
 * @author Alberto Montresor
 * @version $Revision: 1.1 $
 */
@SuppressWarnings("unchecked")
public class CapacityComparator implements Comparator
{

private int direction;

private int pid;

	
/**
 * Initializes the direction of this comparator. If 
 * direction is 1, an array sorted with this comparator
 * is sorted in increasing order of capacity. If direction
 * is -1, the array is sorted in decreasing order. 
 */
public CapacityComparator(int direction)
{
	this.direction = direction;
	this.pid = -1;
}

/**
 * Initializes the direction of this comparator. If 
 * direction is 1, an array sorted with this comparator
 * is sorted in increasing order of capacity. If direction
 * is -1, the array is sorted in decreasing order. 
 */
public CapacityComparator(int direction, int pid)
{
	this.direction = direction;
	this.pid = pid;
}

// Comment inherited from interface
public int compare(Object o1, Object o2)
{
	if (pid < 0) {
		Superpeer s1 = (Superpeer) o1;
		Superpeer s2 = (Superpeer) o2;
		return (s1.getCapacity()-s2.getCapacity())*direction;
	} else {
		Superpeer s1 = (Superpeer) ((Node) o1).getProtocol(pid);
		Superpeer s2 = (Superpeer) ((Node) o2).getProtocol(pid);
		return (s1.getCapacity()-s2.getCapacity())*direction;
	}
}
	

}

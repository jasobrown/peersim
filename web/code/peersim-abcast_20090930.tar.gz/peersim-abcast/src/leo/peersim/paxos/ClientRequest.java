package leo.peersim.paxos;

import peersim.core.CommonState;

public class ClientRequest implements IClientRequest, Cloneable {
	
	private boolean _hasBeenStarted = false;
	private int attempts = 0;
	private boolean hasReachedConsensus = false;
	
	private ReplicaCommand _replicaCommand;
	
	private String opName;
	
	private long _clientIssuingTime;
	
	public ClientRequest(String opName) {
		this.opName = opName;
		this._clientIssuingTime = CommonState.getTime();
	}
	
	public ClientRequest(String opName, long issuingTime) {
		this.opName = opName;
		this._clientIssuingTime = issuingTime;
	}
	
	public boolean hasBeenManaged() {
		return this._hasBeenStarted;
	}
	
	public String getOpName() {
		return this.opName;
	}

	public void startManage() {
		this._hasBeenStarted = true;
		
	}
	
	public boolean hasReachedConsensus() {
		return this.hasReachedConsensus;
	}

	public void newAttempt() {
		this.attempts++;
	}
	
	public int getAttempts() {
		return this.attempts;
	}

	public void decide() {
		this.hasReachedConsensus = true;
		
	}

	@Override
	public long getClientIssuingTime() {
		return this._clientIssuingTime;
	}
	
	public ClientRequest clone() {
		ClientRequest c = null;
		try {
			c = (ClientRequest)super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return c;
	}

	public void setReplicaCommand(ReplicaCommand r) {
		this.hasReachedConsensus = true;
		this._replicaCommand = r;
	}
	
	public long getExecutionTime() {
		long exTime = -1;
		
		if(this._replicaCommand!=null) {
			exTime = this._replicaCommand.getExecutionTime();
		}
		return exTime;
	}

}

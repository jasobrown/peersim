/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package bcast;

import peersim.config.*;
import peersim.core.*;
import cloudcast.*;


public class InfectionGenerator implements Control
{

/**
 * The protocol to be infected.
 * @config
 */
private static final String PAR_PROTOCOL = "protocol";

/**
 * The identifier of the protocol to be infected.
 */

private final int pid;

/**
 * Identifier of the next message to be generated. Starts at 0.
 */
private int message;


public InfectionGenerator(String prefix)
{
	message = 0;
	pid = Configuration.getPid(prefix + "." + PAR_PROTOCOL); 
}

/**
 * Infect both the cloud and a random node (sender). It emulate a scenario where the
 * sender infect itself and the cloud.
 */
public boolean execute()
{
	Infectable i;
	if (Network.size() > 1) {
	  Node found = null;	
		while (found == null) {
			int r = CommonState.r.nextInt(Network.size());
			if (Network.get(r) != Cloud.cloud) {
				found = Network.get(r);
			}
		}
		i = (Infectable) found.getProtocol(pid);
		i.setInfected(message);
	}
	i = (Infectable) Cloud.cloud.getProtocol(pid);
	i.setInfected(message);
	message++;
	return false;
}



}

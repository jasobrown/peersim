package adam2;

import java.io.FileNotFoundException;
import java.lang.reflect.Field;

import javax.xml.stream.XMLStreamException;

import peersim.config.Configuration;
import peersim.config.IllegalParameterException;
import peersim.core.CommonState;
import boinc.BoincHost;
import boinc.BoincParser;
import boinc.CycledBoincParser;


/**
 * This object generates node attribute values using a probability
 * distribution or a filtered trace file.
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class AttributeCalculator {

	// Attribute distribution types.
	// BOINC uses trace file.
	public enum Distribution { UNIFORM, NORMAL, PARETO, EXPONENTIAL, BOINC }

	// // Config file parsing strings
	protected static final String PAR_DISTRIBUTION = "distribution";
	protected static final String PAR_BOINC_FILE = "boinc.trace";
	protected static final String PAR_BOINC_ATTR = "boinc.field";
	protected static final String PAR_BOINC_UNIT = "boinc.unit";

	// Attribute values must be cropped to avoid int overflows 
	protected static double maxValue = Integer.MAX_VALUE / 2;
	
	// Attribute distribution
	protected Distribution distribution;

	//  BOINC stuff
	protected BoincParser boincParser;
	protected String boincAttr;
	protected Field boincField;
	protected double unit;
	protected int skipped;
	

	// Create an attribute calculator object. Configuration is
	// retrieved from the PeerSim config using a given prefix.
	public AttributeCalculator(String prefix) throws FileNotFoundException, XMLStreamException {
		// Check the attribute distribution
		String distString = Configuration.getString(prefix + "." + PAR_DISTRIBUTION);
		distribution = parseDistribution(distString);
		// Create a BOINC parser (if needed)
		if (distribution == Distribution.BOINC) {
			String boincFile = Configuration.getString(prefix + "." + PAR_BOINC_FILE);
			String boincAttr = Configuration.getString(prefix + "." + PAR_BOINC_ATTR);
			double unit = Configuration.getDouble(prefix + "." + PAR_BOINC_UNIT, 1);
			createBoincParser(boincFile, boincAttr, unit);			
		}
	}

	// Type conversion
	protected Distribution parseDistribution(String distributionName) {
		if ("UNIFORM".equals(distributionName)) {
			return Distribution.UNIFORM;
		}
		else if ("NORMAL".equals(distributionName)) {
			return Distribution.NORMAL;
		}
		else if ("PARETO".equals(distributionName)) {
			return Distribution.PARETO;
		}
		else if ("EXPONENTIAL".equals(distributionName)) {
			return Distribution.EXPONENTIAL;
		}
		else if ("BOINC".equals(distributionName)) {
			return Distribution.BOINC;
		}
		else {
			throw new IllegalParameterException(PAR_DISTRIBUTION, "Unknown distribution: " + distributionName);
		}
	}
	
	// Initialises a BOINC trace parser
	protected void createBoincParser(String boincFile, String boincAttribute, double unit) throws FileNotFoundException, XMLStreamException {
		System.out.println("Creating a BOINC parser");

		this.boincAttr = boincAttribute;
		this.unit = unit;
		this.skipped = 0;
		
		// XXX Some traces contain jitter and should be filtered.
		// Attributes above domain-specific limits are assumed
		// unreasonable and discarded.  
		// disk size: 100 TB
		if ("d_total".equals(boincAttr) || "d_free".equals(boincAttr) || "m_swap".equals(boincAttr)) {
			maxValue = 1e14;
		}
		// bandwidth: 1 GB/s
		if ("n_bwdown".equals(boincAttr) || "n_bwup".equals(boincAttr)) {
			maxValue = 1e9;
		}
		// FLOPS/IOPS: 1 TFLOPS 
		if ("p_fpops".equals(boincAttr) || "p_iops".equals(boincAttr)) {
			maxValue = 1e12;
		}
		// RAM: 1 TB
		if ("m_nbytes".equals(boincAttr)) {
			maxValue = 1e12;
		}

		try {
			// BOINC fields are identified using Java reflection
			Class hostClass = new BoincHost().getClass();
			boincField = hostClass.getField(boincAttr);
		} 
		catch (NoSuchFieldException e) {
			throw new IllegalArgumentException("Invalid BOINC attribute: " + boincAttr);
		}			
		boincParser = new CycledBoincParser(boincFile);
	}
	
	public int getAttribute() {
		switch (distribution) {
			case UNIFORM:
				return CommonState.r.nextInt(1000);
			case NORMAL:
				return (int)Math.round(CommonState.r.nextGaussian() * 1000);
			case PARETO:
				return (int)Math.round(Math.pow(100.0 / CommonState.r.nextDouble(), 0.5));
			case EXPONENTIAL:
				return (int)Math.round(-Math.log(CommonState.r.nextDouble()) * 1000);
			case BOINC:
				try {
					double doubleValue = 0;
					for (;;) {
						// Get the next host from the trace
						BoincHost host = boincParser.readHost();
						assert host != null;
						// Get the field value
						doubleValue = boincField.getDouble(host);
						
						// Filter out any outliers
						if (doubleValue < 0 || doubleValue > maxValue || doubleValue > Integer.MAX_VALUE * unit) {
							System.out.println("Skipping BOINC attribute value: " + boincAttr + "=" + doubleValue);
							skipped++;
						}
						else {
							// Convert units
							return (int)Math.round(doubleValue / unit);
						}
					}
				} 
				catch (IllegalArgumentException e) {
					throw new RuntimeException("Non-numeric BOINC attribute: " + e.getMessage(), e);
				} 
				catch (XMLStreamException e) {
					throw new RuntimeException("Error parsing BOINC trace file: " + e.getMessage(), e);
				} 
				catch (IllegalAccessException e) {
					throw new RuntimeException("Access exception: " + e.getMessage(), e);
				}
			default:
				throw new RuntimeException("Invalid attribute distribution: " + distribution);
		}
	}
	
}

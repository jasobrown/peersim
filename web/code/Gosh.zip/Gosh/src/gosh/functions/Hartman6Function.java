/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.config.*;

// d=6; opt. = -3.3223680114155156318
public class Hartman6Function extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;

private double[][] szego_table_a;

private double[] szego_table_c;

private double[][] szego_table_p;

public Hartman6Function(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);
        
        createTables();
        
        rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = 0.0;
    rangeMax[i] = 1.0;
  }	
}

public double eval(double[] x)
{
  int	i, j;
  double w;
  
  double Result = 0;
    for (i = 0; i < 4; ++i)
    {
      w = 0;
      for (j = 0; j < 6; ++j)
              w -= szego_table_a[i][j] * StrictMath.pow(x[j] - szego_table_p[i][j],2);
      Result -= szego_table_c[i] * StrictMath.exp(w);
    }
  return Result;
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;
	
}

private void createTables()
{
 //int i,j;
 double[][] a =
 {
  {10.00,  3.00, 17.00,  3.50,  1.70,  8.00},
  { 0.05, 10.00, 17.00,  0.10,  8.00, 14.00},
  { 3.00,  3.50,  1.70, 10.00, 17.00,  8.00},
  {17.00,  8.00,  0.05, 10.00,  0.10, 14.00}
 };
 double[] c =
 {
  1.0, 1.2, 3.0, 3.2
 };
 double[][] p =
 {
  {0.1312, 0.1696, 0.5569, 0.0124, 0.8283, 0.5886},
  {0.2329, 0.4135, 0.8307, 0.3736, 0.1004, 0.9991},
  {0.2348, 0.1451, 0.3522, 0.2883, 0.3047, 0.6650},
  {0.4047, 0.8828, 0.8732, 0.5743, 0.1091, 0.0381}
 }; 
 
 szego_table_a = a;
 szego_table_c = c;
 szego_table_p = p;
}

}

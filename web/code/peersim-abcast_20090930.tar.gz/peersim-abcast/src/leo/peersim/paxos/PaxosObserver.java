package leo.peersim.paxos;

import leo.peersim.common.QueueConsistencyValidator;

import org.apache.log4j.Logger;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;

public class PaxosObserver implements Control {
	
	private Logger logger = Logger.getLogger(this.getClass().getName());
	private int _protocolID;
	
	public PaxosObserver(String prefix) {
		this._protocolID = Configuration.getPid(prefix + "." + "protocol");
	}

	@Override
	public boolean execute() {
		logger.info(CommonState.getTime() + " observing...");
		
		QueueConsistencyValidator qv = new QueueConsistencyValidator(this._protocolID);
		if (qv.isConsistent()) {
			logger.info(qv.getAtomicQueue() + " atomically broadcast on " + qv.getNumOfLiveNodes() + " agents (" + qv.getNumOfFailedNodes() + " failed)");
		} else {
			logger.fatal("Inconsistent queues :(");
		}
		
		PaxosSnooper sn = new PaxosSnooper(this._protocolID);
		
		return false;
	}
}

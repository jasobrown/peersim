/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;

import peersim.config.*;
import peersim.core.*;
import peersim.edsim.*;

public class PSOSwarm_M implements EDProtocol, Gosh
{

//---------------------------------------------------------------------
//CommonData
//---------------------------------------------------------------------

/**
* @config
*/
private static final String PAR_PARTICLES = "particles";

/**
 * @config
 */
private static final String PAR_FUNCTION = "function";

/**
* @config
*/
private static final String PAR_MAXITER = "maxIter";

/**
 * @config
 */
private static final String PAR_W1 = "w1";

/**
 * @config
 */
private static final String PAR_W2 = "w2";

/**
 * @config
 */
private static final String PAR_C1 = "c1";

/**
 * @config
 */
private static final String PAR_C2 = "c2";

/**
 * @config
 */
//private static final String PAR_SPEED = "speed";

//---------------------------------------------------------------------
//Fields
//---------------------------------------------------------------------

/** Current best value */
//private double[] best;

/** Current best value */
//private double bestval;

/** Current particle being evaluated */
//private int current;

/** */
private PSOParticle_M[] particles;

/** */
private PSOConfig_M pc;

//BufferedWriter out;

/*****************************************************/
 
//  double maximumInitialSpeed;
      double[] bestPosition;
      double bestValue;
  int nextRunningParticle;
      int nparticles;
//      int activeparticles;
      int count;
//      double w1, w2, c1, c2;
//      int maxIter;
  //double updateProbability;
  //void addParticle ();




//---------------------------------------------------------------------
//Constructor
//---------------------------------------------------------------------

public PSOSwarm_M(String prefix)
{
	Function f = (Function) Configuration.getInstance(prefix + "." + PAR_FUNCTION);
	double w1 = Configuration.getDouble(prefix + "." + PAR_W1);
        double w2 = Configuration.getDouble(prefix + "." + PAR_W2);
	double c1 = Configuration.getDouble(prefix + "." + PAR_C1);
	double c2 = Configuration.getDouble(prefix + "." + PAR_C2);
//	double maxSpeed = Configuration.getDouble(prefix + "." + PAR_SPEED);
        int maxIter = Configuration.getInt(prefix + "." + PAR_MAXITER);
        nparticles = Configuration.getInt(prefix + "." + PAR_PARTICLES);
        count=0;
        init(nparticles,new PSOConfig_M(f,w1,w2,c1,c2,maxIter));
}

private void init(int nparticles, PSOConfig_M pc)
{
//  try {out = new BufferedWriter(new FileWriter("Swarm"+CommonState.r.nextInt()+".log"));}
//  catch (IOException ioe) {};
	this.pc = pc;
  particles = new PSOParticle_M[nparticles];
  for (int i=0; i < nparticles; i++) {
          particles[i] = new PSOParticle_M(pc);
  }

//    maximumInitialSpeed = pc.maxv;
    bestValue = Double.MAX_VALUE;
    nextRunningParticle = 0;
//    maxiter = mxi;
//    updateProbability = updprob;
    //  f (fun),
    //  dimension (fun->dimension),
    //  minRange = pc.f.getRangeMin();
    //  maxRange = pc.f.getRangeMax();
    int dim= pc.f.d();
    double[] max = pc.f.getRangeMax();
    double[] min = pc.f.getRangeMin();
    bestPosition = new double[dim];
    for (int i=0; i<dim;i++)
    /**/  bestPosition[i]=(max[i]-min[i])*CommonState.r.nextDouble()+min[i]; //
    
//    try
//    {
//      PrintWriter pout = new PrintWriter(new FileWriter("peersimStats.log",true));
//      pout.println("Starting from :");
//      for (int z=0;z<dim;z++)
//        pout.print("\t"+bestPosition[z]+";");
//      pout.print("\n\n");
//      pout.close();
//    } catch (IOException ex)
//    {
//      ex.printStackTrace();
//    }


    //  w1 (inertia1),
    //  w2 (inertia2),
    //  c1 (const1),
    //  c2 (const2),
    //  resize (np);

  long delay = pc.f.getTime();
  EDSimulator.add(delay, this, CommonState.getNode(), CommonState.getPid());

//	this.pc = pc;
//	bestval = Double.MAX_VALUE;
//	best = new double[pc.f.d()];
//	particles = new PSOParticle_M[size];
//	for (int i=0; i < size; i++) {
//		particles[i] = new PSOParticle_M();
//	}
//	current = 0;
//	long delay = pc.f.getTime();
//	EDSimulator.add(delay, this, CommonState.getNode(), CommonState.getPid());
}


//public PSOSwarm_M (PSOConfig_M pso_c,  
//	      int mxi,
//              double updprob)
//{
//
//}

public Object clone() 
{
	PSOSwarm_M ret = null;
	try {
		ret = (PSOSwarm_M) super.clone();
	} catch (CloneNotSupportedException e) {
	}
	ret.init(particles.length, pc);
	return ret;
}


 //---------------------------------------------------------------------
//Methods
//---------------------------------------------------------------------

public int getCount()
{
	return count;
}

public void processEvent(Node node, int pid, Object event)
{
	count++;
	int myPid = CommonState.getPid();
//	particles[nextRunningParticle].step(bestPosition,false);
//	if (particles[nextRunningParticle].bestValue < bestValue) {
//		bestValue = particles[nextRunningParticle].bestValue;
//		System.arraycopy(particles[nextRunningParticle].bestPosition, 0, bestPosition, 0, pc.f.d());
//	}
//	nextRunningParticle = (nextRunningParticle+1)%particles.length;
	
//        step(myPid);
        if ( particles[nextRunningParticle].step (bestPosition,myPid) ) {
          final double[] p = particles[nextRunningParticle].getBest ();
          double v = particles[nextRunningParticle].getBestValue ();
/*          try {
        	  out.write(""+v+'	');
        	  for (int i=0;i<pc.f.d();i++) 
        		  if (p[i]<pc.f.getRangeMin()[i] || p[i]>pc.f.getRangeMax()[i]) {
        			  out.write("OUT OF BOUNDS!"); break; }
*/          if ( v < bestValue ) {
            System.arraycopy(p, 0, bestPosition, 0, pc.f.d());
            bestValue = v;
//          out.write(" - BEST"); 
          }
/*          out.write('\n'); out.flush();
          }
          catch (IOException ioe) {};
 */       }
        nextRunningParticle = (nextRunningParticle + 1) % nparticles;
//        System.out.println("Valutazioni fatte : "+count);
        long delay = pc.f.getTime();
	EDSimulator.add(delay, this, CommonState.getNode(), myPid);
}


public double getValue()
{
	return bestValue;
}

public double[] getBest()
{
	return bestPosition;
}

public void setValue(double value)
{
	this.bestValue = value;
}

public void setBest(double[] best)
{
	this.bestPosition = best;
}


// double[] getBest (Double v)
//{
//  v = new Double(bestValue);
//  return bestPosition;
//}

//int getSize ()
//{
//  return nparticles;
//}

//double getCurrentInertia ()
//{
//  return w1;
//}

//void addParticle ()
//{
//  particles[nparticles] = new PSOParticle_M (pc, maximumInitialSpeed,
//				     maxiter);
//  recomputeBest (nparticles);
//  nparticles++;
//}

//public void step (int pid)
//{
////  double v=Double.MAX_VALUE;
////  if ( updateProbability!= 0.0 ) {
////    particles[nextRunningParticle].step ();
////    final double[] p = particles[nextRunningParticle].getBest ();
////    v=particles[nextRunningParticle].getBestValue ();
////    if ( CommonState.r.nextDouble() < updateProbability ) {
////      int i = CommonState.r.nextInt(nparticles);
////      if ( i != nextRunningParticle ) {
////        double w=Double.MAX_VALUE;
////        final double[] q = particles[i].getBest ();
////        w=particles[i].getBestValue();
////        if ( v < w )
////          particles[i].setBestKnown (p, v);
////        else if ( w < v )
////          particles[nextRunningParticle].setBestKnown (q, w);
////      }
////    }
////  }
////  else {
//    if ( particles[nextRunningParticle].step (bestPosition,pid) )
//      recomputeBest (nextRunningParticle);
////    else
////      v=particles[nextRunningParticle].getBestValue ();
////  }
//  nextRunningParticle = (nextRunningParticle + 1) % nparticles;
//}

//public void recomputeBest (int i)
//{
//  double v = Double.MAX_VALUE;
//  final double[] p;
//  p = particles[i].getBest ();
//  v=particles[i].getBestValue ();
//  if ( v < bestValue ) {
//    System.arraycopy(p, 0, bestPosition, 0, pc.f.d());
//    bestValue = v;
//  }
//}

//void resize (int n)
//{
//  while ( (int)particles.capacity() < n )
//    particles.reserve (2 * particles.capacity());
//  while ( nparticles > n ) {
//    Double maxp;
//    particles[0].getBest (maxp);
//    int maxpos = 0;
//    for ( int i = 1; i < nparticles; i++ ) {
//      Double p;
//      particles[i].getBest (p);
//      if ( p.doubleValue() > maxp.doubleValue() ) {
//	maxpos = i;
//	maxp = p;
//      }
//    }
//    nparticles--;
//    if ( maxpos != nparticles )
//      particles[maxpos] = particles[nparticles];
//  }
//  while ( nparticles < n )
//    addParticle ();
//}

//void setInertia (double w)
//{
//  w1 = w2 = w;
//  for ( int i = 0; i < nparticles; i++ )
//    particles[i].setInertia (w);
//}


//void Swarm::synchronize (int p1, int p2)
//{
//	double v1, v2;
//	const vector<double>
//		&x1 = particles[p1].getBestKnown (v1),
//		&x2 = particles[p2].getBestKnown (v2);
//	if ( v1 < v2 )
//		particles[p2].setBestKnown (x1, v1);
//	else if ( v2 < v1 )
//		particles[p1].setBestKnown (x2, v2);
//} 
 
}

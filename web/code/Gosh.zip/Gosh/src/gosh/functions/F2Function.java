/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.config.*;


public class F2Function extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;

// d=2; opt.=0.0
public F2Function(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);
	rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = -2.048;
    rangeMax[i] = 2.048;
  }	
}

public double eval(double[] x)
{
  double x0 = x[0], x1 = x[1], dx = x0*x0 - x1*x1, xx = 1.0-x0;
  return 100.0 * dx * dx + xx * xx;
//  System.out.print(CommonState.getTime() + ": f(" + x[0]);
//  for (int i=1; i < d; i++) {
//  	System.out.print(", " + x[i]);
//  }
//  System.out.println(") = " + Result);
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;
	
}
}

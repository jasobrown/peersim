package boinc;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;

import javax.xml.stream.XMLStreamException;


/**
 * A tool for plotting BOINC host properties. In takes two BOINC host properies 
 * as input parameters.
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class Plotter {

	public static void main(String[] args) {
		if (args.length < 4 || args.length > 5) {
			System.out.println("Usage: java Plotter <trace-file> <output-name> <x-axis> <y-axis> [max-entries]");
			return;
		}
		
		try {
			String traceFile = args[0];
			BoincParser parser = new BoincParser(traceFile); 
	
			String xProp = args[2];
			String yProp = args[3];

			int limit = Integer.MAX_VALUE;
			if (args.length == 5) {
				limit = Integer.parseInt(args[4]);
			}

			Class hostClass = new BoincHost().getClass();
			Field xField = hostClass.getField(xProp);
			Field yField = hostClass.getField(yProp);

			String outputName = args[1];
			OutputStream dataStream = new FileOutputStream(outputName + ".txt");
			OutputStreamWriter dataWriter = new OutputStreamWriter(dataStream);

			System.out.println("Parsing...");
			int i;
			for (i = 0; i < limit; i++) {
				BoincHost host = parser.readHost(); 	
				
				if (host == null) {
					// End of trace
					break;
				}
				else {
					double x = xField.getDouble(host);
					double y = yField.getDouble(host);
					
					dataWriter.write(x + " " + y + "\n");
					
					if (i % 10000 == 9999) {
						System.out.print("*");
					}
				}
			}
			parser.close();
			dataWriter.close();
			
			System.out.println();
			System.out.println("Parsed " + i + " host entries.");
			
			System.out.print("Generating gnuplot file...");
			OutputStream gnuplotStream = new FileOutputStream(outputName + ".gnuplot");
			OutputStreamWriter gnuplotWriter = new OutputStreamWriter(gnuplotStream);

			gnuplotWriter.write("set terminal postscript\n");
			gnuplotWriter.write("set output \"" + outputName + ".eps\"\n");
			gnuplotWriter.write("set xlabel \"" + xProp + "\"\n");
			gnuplotWriter.write("set ylabel \"" + yProp + "\"\n");
			gnuplotWriter.write("#set xrange [1:1e10]\n");
			gnuplotWriter.write("#set yrange [1:1e10]\n");
			gnuplotWriter.write("set logscale x\n");
			gnuplotWriter.write("set logscale y\n");
			gnuplotWriter.write("plot \"" + outputName + ".txt\" using 1:2 title \"" + traceFile + "\" with points\n");
			gnuplotWriter.close();

			System.out.println(" done");
		} 
		catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
		}
		catch (XMLStreamException e) {
			System.out.println("Read error: " + e.getMessage());
		}
		catch (IOException e) {
			System.out.println("Write error: " + e.getMessage());
		}
		catch (NoSuchFieldException e) {
			System.out.println("Invalid host property: " + e.getMessage());
		}
		catch (IllegalArgumentException e) {
			System.out.println("Cannot convert host property to number");
		} 
		catch (IllegalAccessException e) {
			e.printStackTrace();
		} 
	}

}

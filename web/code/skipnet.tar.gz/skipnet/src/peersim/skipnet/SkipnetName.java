package peersim.skipnet;

/**
 * Defines a name address for the peersim.extras.am.skipnet protocol.
 * 
 * @author Rodolfo Cartas
 * 
 */
public class SkipnetName implements Cloneable {

	// --------------------------------------------------------------------------
	// Fields
	// --------------------------------------------------------------------------
	public static final char DELIMITER = '/';

	private String identifier = "";

	// --------------------------------------------------------------------------
	// Initialization
	// --------------------------------------------------------------------------
	public SkipnetName() {
	}

	public SkipnetName(String id) {
		this.identifier = id;
	}

	// --------------------------------------------------------------------------
	// Methods
	// --------------------------------------------------------------------------
	public String toString() {
		return identifier.toString();
	}

	public int compareTo(SkipnetName comp) {
		return identifier.compareTo(comp.identifier);
	}

	public boolean equals(SkipnetName comp) {
		boolean b = identifier.equals(comp.identifier);
		return b;
	}

	/**
	 * Determine if B is located between A and C, allowing for the possibility
	 * that A==B
	 */
	public static boolean liesBetweenIncl(SkipnetName A, SkipnetName B,
			SkipnetName C) {
		// There are 3 cases:
		// Case 1: A --- B --- C
		// Case 2: C --- A --- B
		// Case 3: B --- C --- A
		// Case 4: A==B --- C or C --- A==B or A==B==C
		if ((A.compareTo(B) < 0 && B.compareTo(C) < 0) // Case 1
				|| (C.compareTo(A) < 0 && A.compareTo(B) < 0) // Case 2
				|| (B.compareTo(C) < 0 && C.compareTo(A) < 0) // Case 3
				|| (A.equals(B))) // Case 4

			return true;
		else
			return false;
	}

	/**
	 * Determine if B is located at the right side of A
	 */
	public static boolean isAtRight(SkipnetName A, SkipnetName B) {
		return A.compareTo(B) < 0;
	}

	/**
	 * Determine if B is located between A and C, allowing for the possibility
	 * that A==C
	 */
	public static boolean liesBetween(SkipnetName A, SkipnetName B,
			SkipnetName C) {
		// There are 3 cases:
		// Case 1: A --- B --- C
		// Case 2: C --- A --- B
		// Case 3: B --- C --- A
		// Case 4: C==A --- B
		if ((A.compareTo(B) < 0 && B.compareTo(C) < 0) // Case 1
				|| (C.compareTo(A) < 0 && A.compareTo(B) < 0) // Case 2
				|| (B.compareTo(C) < 0 && C.compareTo(A) < 0) // Case 3
				|| (C.equals(A))) // Case 4
		{
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Determines if this name ID has the given prefix
	 */
	public boolean isWithinPrefix(String prefix) {
		return identifier.startsWith(prefix);
	}

	/**
	 * Determines if this name ID has the given prefix
	 */
	public boolean isWithinPrefix(SkipnetName prefix) {
		return isWithinPrefix(prefix.identifier);
	}

	/**
	 * Compute the length of the longest common prefix of two name IDs, ignoring
	 * delimiters
	 */
	public int longestCommonPrefixLength(SkipnetName n) {
		int len = 0;

		byte lid[] = identifier.getBytes();
		byte nid[] = n.identifier.getBytes();

		while (true) {
			if (len >= lid.length || len >= nid.length)
				return len;
			if (lid[len] != nid[len])
				return len;
			len++;
		}
	}

	/**
	 * 
	 * Determine if B is located between A and C, when going in direction given
	 * by 'dir'
	 */
	public static boolean liesBetween(SkipnetName A, SkipnetName B,
			SkipnetName C, SkipnetUtil.Direction dir) {
		if (dir == SkipnetUtil.Direction.LEFT) {
			return liesBetween(C, B, A);
		} else {
			return liesBetween(A, B, C);
		}
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public int hashCode() {
		return identifier.hashCode();
	}

	public Object clone() {
		SkipnetName result = null;
		try {
			result = (SkipnetName) super.clone();
		} catch (CloneNotSupportedException e) {
		} // never happens
		result.identifier = "";

		return result;
	}

}

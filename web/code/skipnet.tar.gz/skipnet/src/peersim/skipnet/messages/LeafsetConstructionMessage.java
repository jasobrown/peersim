package peersim.skipnet.messages;

import java.util.Vector;

import peersim.core.Node;
import peersim.skipnet.SkipnetUtil.*;

public class LeafsetConstructionMessage extends SkipnetMessage {

	public static final int MAXLEAFSETSIZE = 16;
	
	protected Vector leafset;
	
	public LeafsetConstructionMessage(Node source, Node nextHop, Direction dir) {
		super(source, nextHop);
		this.direction = dir;
		leafset = new Vector(MAXLEAFSETSIZE);
	}
	
	public void addSkipnetNodeToLeafset(Node node) {
		if(leafset.size()<MAXLEAFSETSIZE) {
			leafset.add(node);
		}			
	 }
	
	public boolean isLeafSetFull() {
		return leafset.size()>=MAXLEAFSETSIZE;
	}

	public Vector getLeafset() {
		return leafset;
	}

	public void setLeafset(Vector leafset) {
		this.leafset = leafset;
	}

}

package peersim.chord;

public class Parameters {
	int pid;

	int tid;
}

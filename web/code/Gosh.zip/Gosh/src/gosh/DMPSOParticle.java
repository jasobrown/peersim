/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;
import peersim.core.*;

//import java.io.*;

public class DMPSOParticle
{

  double[] position;
  double[] speed;
  double[] bestPosition;

  double currentValue;
  double bestValue;

  
 public DMPSOParticle ( DMPSOSwarm swarm )
 {

	 
  position = new double[swarm.f.d()];
  speed = new double[swarm.f.d()];
  bestPosition = new double[swarm.f.d()];

  for ( int i = 0; i < swarm.f.d(); i++ ) {
      position[i] = swarm.bestPosition[i]+(2*swarm.radius*CommonState.r.nextDouble()
      						-swarm.radius);
//    bestPosition[i]=bestPosition[i]<swarm.f.getRangeMin()[i]?swarm.f.getRangeMin()[i]:
//		bestPosition[i]>swarm.f.getRangeMax()[i]?swarm.f.getRangeMax()[i]:
//			bestPosition[i];
	bestPosition[i] = /*swarm.bestP*/position[i];
    speed[i] = 2*swarm.pc.maxv*CommonState.r.nextDouble()-swarm.pc.maxv; //
  }
  bestValue = currentValue = swarm.f.eval(position);
//    bestValue = swarm.bestValue;
}

 
public double getBestValue ()
{
  return bestValue;
}


public double[] getBest ()
{
  return bestPosition;
}


boolean step (DMPSOSwarm swarm)
{
  int fevals = swarm.getCount(); double r1=0,r2=0;
  double w = (swarm.pc.w1 - swarm.pc.w2) * 
  			(((double)(swarm.pc.maxIter - fevals)) / (double)swarm.pc.maxIter) + swarm.pc.w2;
  for ( int i = 0; i < swarm.f.d(); i++ ) {
    r1 = CommonState.r.nextDouble(); 
    r2 = CommonState.r.nextDouble(); 
    speed[i] = w * speed[i]
      + swarm.pc.c1 * r1 * (bestPosition[i] - position[i])
      + swarm.pc.c2 * r2 * (swarm.bestPosition[i] - position[i]);
    if ( speed[i] > swarm.pc.maxv )
      speed[i] = swarm.pc.maxv;
    else if ( speed[i] < -swarm.pc.maxv )
      speed[i] = -swarm.pc.maxv;
    position[i] = position[i] + speed[i];
    
  }
  currentValue = swarm.f.eval(position);
//    try
//    {
//      PrintWriter pout = new PrintWriter(new FileWriter("mySolverStats.log",true));
//      for(int z=0;z<swarm.pc.f.d();z++)
//        pout.println("position["+z+"] = "+position[z]+"\tspeed["+z+"] = "+speed[z]);
//      pout.println("w1 = "+swarm.pc.w1+"\t\tw2 = "+swarm.pc.w2+"\t\tmaxv = "+swarm.pc.maxv+"w = "+w);
//      pout.println("Iteration # "+fevals+";\tr1= "+r1+"\tr2= "+r2+"\tValue: "+currentValue);
//      pout.close();
//    } catch (IOException ex)
//    {
//      ex.printStackTrace();
//    }
  if ( currentValue < bestValue ) {
	  boolean outOfBound = false;
	  for (double p : position) 
    	if (p<swarm.f.getRangeMin()[0] || p>swarm.f.getRangeMax()[0]) {
    		outOfBound = true;
    		break;
    	}
	  if (!outOfBound) {
		  bestValue = currentValue;
		  System.arraycopy(position,0,bestPosition,0,bestPosition.length);
		  return true;
	  }
  }
  return false;
}
 

}
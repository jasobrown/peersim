package boinc;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import javax.xml.stream.XMLStreamException;

/**
 * A tool for copying BOINC trace files. Used mainly for debugging.
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class Copy {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("Usage: java Copy <trace-file> <out-file>");
			return;
		}
		
		try {
			String traceFile = args[0];
			BoincParser parser = new BoincParser(traceFile); 
			
			String outFile = args[1];
			OutputStream outStream = new FileOutputStream(outFile);
			OutputStreamWriter writer = new OutputStreamWriter(outStream);

			writer.write("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n");
			writer.write("<hosts>\n");
			
			System.out.println("Parsing...");
			int parsed = 0;
			for (;;) {
				BoincHost host = parser.readHost(); 	
				
				if (host == null) {
					// End of trace
					writer.write("</hosts>\n");
					writer.close();
					parser.close();
					break;
				}
				else {
					parsed++;
					writer.write(host.toString());
					writer.write("\n");
					if (parsed % 10000 == 0) {
						System.out.print("*");
					}
				}
			}
			System.out.println();
			System.out.println("Copied " + parsed + " host entries");
		} 
		catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
		}
		catch (XMLStreamException e) {
			System.out.println("Read error: " + e.getMessage());
		} 
		catch (IOException e) {
			System.out.println("Write error: " + e.getMessage());
		}
	}

}

package peersim.skipnet.messages;

import peersim.core.Node;
import peersim.skipnet.*;
import peersim.skipnet.SkipnetUtil.*;

public class SkipnetMessage {
	public Node source;

	public Node nextHop;

	public Direction direction;
	
	private SkipnetMessageCallback callback;
	
	public Object payload;
	
	private int hopCount = 0;
	
	//public Vector trace;
	
	public SkipnetMessage(Node source,
			Node nextHop) {
		super();
		this.source = source;
		this.nextHop = nextHop;
		//trace = new Vector();
	}
	
	public void arrivedAtHop(Skipnet skipnet) {
		//trace.add(peersim.extras.am.skipnet);
		hopCount++;
	}
	
	public void destinationReached(Skipnet skipnet) {
		//System.out.println("Number of hops: " + hopCount);
		if(callback!=null)
			callback.callback(this);
	}
	
	public void maxHopCountReached(Skipnet node) {
		System.out.println("MAX HOP COUNT REACHED");
		if(callback!=null)
			callback.callback(this);
	}

	public SkipnetMessageCallback getCallback() {
		return callback;
	}

	public void setCallback(SkipnetMessageCallback callback) {
		this.callback = callback;
	}

	public int getHopCount() {
		return hopCount;
	}

}

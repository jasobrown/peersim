/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;

//import java.io.*;

public class DMPSOSwarm
{

//---------------------------------------------------------------------
//Fields
//---------------------------------------------------------------------



/** */
	DMPSOParticle[] particles;

     double[] bestPosition;
      double bestValue;
  int nextRunningParticle;
      int nparticles=16;
      int count;
  DMPSOConfig pc;
  Function f;
  double radius;


//---------------------------------------------------------------------
//Constructor
//---------------------------------------------------------------------

public DMPSOSwarm(Function _f,double rad)
{
    f = _f;
    radius = rad;
	//init(nparticles,new PSOConfig(f,maxIter));
}

public void init(DMPSOSolver s, double[] initPos)
{
	count=0;
	pc = s.pc;
	bestPosition = new double[f.d()];
	System.arraycopy(initPos,0,bestPosition,0,initPos.length);
	
	nparticles = pc.particles;
	nextRunningParticle = 0;
	
	particles = new DMPSOParticle[nparticles];
	for (int i=0; i < nparticles; i++) {
          particles[i] = new DMPSOParticle(this);
	}
	
/*	if (s.bestValue!=Double.MAX_VALUE) {
		System.arraycopy(s.bestPosition,0,bestPosition,0,bestPosition.length);
		bestValue = s.bestValue;
	}
	else {
*/		bestValue = f.eval(initPos); 
//	}
}


//public Object clone() 
//{
//	PSOSwarm ret = null;
//	try {
//		ret = (PSOSwarm) super.clone();
//	} catch (CloneNotSupportedException e) {
//	}
//	ret.init(particles.length, pc);
//	return ret;
//}


 //---------------------------------------------------------------------
//Methods
//---------------------------------------------------------------------

public int getCount()
{
	return count;
}

public void next()
{
	double[] p;
	double v;
//	for (DMPSOParticle par : particles) {
		count++;
		if (particles[nextRunningParticle].step(this)) {
			p = particles[nextRunningParticle].getBest ();
			v = particles[nextRunningParticle].getBestValue ();
			if ( v < bestValue ) {
				System.arraycopy(p, 0, bestPosition, 0, f.d());
				bestValue = v;
			}
		}
//	}
	nextRunningParticle = (nextRunningParticle + 1) % nparticles;
        
}


}

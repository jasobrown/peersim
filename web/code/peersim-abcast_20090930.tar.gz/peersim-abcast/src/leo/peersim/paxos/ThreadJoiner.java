package leo.peersim.paxos;

import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;

@Deprecated
public class ThreadJoiner implements Control {
	
	private int protocolID;

	public ThreadJoiner(String prefix) {
		this.protocolID = Configuration.getPid(prefix + "." + "protocol");
	}

	@Override
	public boolean execute() {
		for(int i=0; i<Network.size(); i++) {
			Node n = Network.get(i);
			Paxos p = (Paxos)n.getProtocol(protocolID);
			//p.stopAgents();
		}
		return false;	
	}
}

package leo.peersim.common;

import org.apache.log4j.Logger;

import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Linkable;
import peersim.core.Network;
import peersim.core.Node;

/**
 * Gives the adjacency matrix of the directed network graph
 * 
 * @author leo
 */
public class TopologySnapshotter implements Control {
	
	private static Logger logger = Logger.getLogger(TopologySnapshotter.class.getName());
	
	private int protocolID;
	
	public TopologySnapshotter(String prefix) {
		this.protocolID = Configuration.getPid(prefix + "." + "protocol");
	}

	@Override
	public boolean execute() {	
		
		logger.debug("Snapshot of network topology...");
		
		for (int i=0; i<Network.size(); i++) {
			
			Node node = Network.get(i);
			
			Linkable linkable = (Linkable) node.getProtocol(this.protocolID);
			
			for (int j=0; j<linkable.degree(); j++) {
				Node neighbour = linkable.getNeighbor(j);
				logger.trace(node.getID() + " --> " + neighbour.getID() );
			}
		}
			
		return false;
	}
}
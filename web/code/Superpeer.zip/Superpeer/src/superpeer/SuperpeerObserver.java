/*
 * Copyright (c) 2003 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package superpeer;

import java.util.Arrays;

import peersim.reports.*;
import peersim.config.*;
import peersim.core.*;
import peersim.util.*;


/**
 * 
 *
 * @author Alberto Montresor
 * @version $Revision: 1.1 $
 */
public class SuperpeerObserver implements Observer
{

//--------------------------------------------------------------------------
// Constants
//--------------------------------------------------------------------------

/** 
* String name of the parameter 
*/
public static final String PAR_PROTOCOL = "protocol";


/** 
* String name of the parameter 
*/
public static final String PAR_LIMIT = "limit";

/** 
* String name of the parameter 
*/
public static final String PAR_MINROUND = "minround";

//--------------------------------------------------------------------------
// Fields
//--------------------------------------------------------------------------

private String prefix; 
	
private int pid;

//--------------------------------------------------------------------------
// Static fields
//--------------------------------------------------------------------------

private static int[] req_sent;

private static int[] req_rcvd;

private static int[] movement;

private static int lastlimit;

private static int minround;

private static IncrementalStats totsent;

private static IncrementalStats totmov;

private static double[] limits = { 0.7, 0.8, 0.9, 0.95, 2.00 };

//--------------------------------------------------------------------------
// Constructor
//--------------------------------------------------------------------------

/**
 * 
 */
public SuperpeerObserver(String prefix)
{
	this.prefix = prefix;
	pid  = Configuration.getInt(prefix + "." + PAR_PROTOCOL);
	minround = Configuration.getInt(prefix + "." + PAR_MINROUND, 0);
}

//--------------------------------------------------------------------------
// Methods
//--------------------------------------------------------------------------

// Comment inherited from interface
@SuppressWarnings("unchecked")
public boolean analyze()
{
	// check();
	
	// Init data structure for message counts */
	int len = Network.size();
	if (movement == null || movement.length < len) {
		movement = new int[len];
		req_sent = new int[len];
		req_rcvd = new int[len];
	}

	// Init last limit
	int time = CommonState.getCycle();
	if (time == 0) {
		lastlimit = 0;
		totsent = new IncrementalStats();
		totmov = new IncrementalStats();
	}
	
	// Compute the number of superpeers, clients, and the ratio
	int superpeers = 0;
	int clients = 0;
	IncrementalStats degree = new IncrementalStats();
	IncrementalStats capacity = new IncrementalStats();
	for (int i=0; i < Network.size(); i++) {
		Superpeer spp = (Superpeer) Network.get(i).getProtocol(pid);
		if (spp.isSuperpeer()) { 
			superpeers++;
			degree.add(spp.degree());
			capacity.add(spp.getCapacity());
		} else {
			clients++;
		}
	}
	double ratio = degree.getSum()/capacity.getSum();
	
	boolean stop = false;
	if (ratio > 0.8) {
		Superpeer[] spps = new Superpeer[superpeers];
		int pos = 0;
		for (int i=0; i < Network.size(); i++) {
			Superpeer spp = (Superpeer) Network.get(i).getProtocol(pid);
			if (spp.isSuperpeer())
				spps[pos++] = spp;
		}
		Arrays.sort(spps, new CapacityComparator(-1));
		int tot = 0;
		for (int i=0; i< superpeers-1; i++) 
			tot += spps[i].getTarget();
		System.out.println(tot);
		stop = (degree.getSum() == clients) && (tot <= clients+1);
	}

	IncrementalStats sent = new IncrementalStats();
	IncrementalStats rcvd = new IncrementalStats();
	IncrementalStats mov = new IncrementalStats();
	IncrementalStats vsent = new IncrementalStats();
	IncrementalStats vrcvd = new IncrementalStats();
	IncrementalStats vmov = new IncrementalStats();
	len = Network.size();
	for (int i=0; i < len; i++) {
		Superpeer spp = (Superpeer) Network.get(i).getProtocol(pid);
		if (req_sent[i]>0) {
			sent.add(req_sent[i]);
			vsent.add(((double) req_sent[i])/spp.getCapacity());
		}
		if (req_rcvd[i]>0) {
			rcvd.add(req_rcvd[i]);
			vrcvd.add(((double) req_rcvd[i])/spp.getCapacity());
		}
		if (movement[i]>0) {
			mov.add(movement[i]);
			vmov.add(((double) movement[i])/spp.getCapacity());
		}
	}
	totsent.add(sent.getSum());
	totmov.add(mov.getSum());
	for (int i=0; i < len; i++) {
		movement[i] = 0;
		req_sent[i] = 0;
		req_rcvd[i] = 0;
	}
	
	// System.out.println("");
	Log.println(prefix, 
			" TIME " + time + 
			" SUPER " + superpeers + 
			" CLIENTS " + clients + 
			" DEGREE " + degree.getSum() +
			" RATIO " + ratio +
			" SENT_TOT " + totsent.getSum() +
			" MOV_TOT " + totmov.getSum() +
			" SENT_AVG " + sent.getAverage() +
			" SENT_MAX " + sent.getMax() +
			" RCVD_AVG " + rcvd.getAverage() +
			" RCVD_MAX " + rcvd.getMax() +
			" MOVEMENT " + mov.getMax() +
			" VSENT_AVG " + vsent.getAverage() +
			" VSENT_MAX " + vsent.getMax() +
			" VRCVD_AVG " + vrcvd.getAverage() +
			" VRCVD_MAX " + vrcvd.getMax() +
			" VMOVEMENT " + vmov.getMax()
	);

	while (ratio >= limits[lastlimit]) {
		Log.println(prefix, 
				" LIMIT " + limits[lastlimit] +
				" LIMITTIME " + time + 
				" SUPER " + superpeers + 
				" CLIENTS " + clients + 
				" DEGREE " + degree.getSum() +
				" RATIO " + ratio +
				" SENT_TOT " + totsent.getSum() +
				" MOV_TOT " + totmov.getSum() +
				" SENT_AVG " + sent.getAverage() +
				" SENT_MAX " + sent.getMax() +
				" RCVD_AVG " + rcvd.getAverage() +
				" RCVD_MAX " + rcvd.getMax() +
				" MOVEMENT " + mov.getMax() +
				" VSENT_AVG " + vsent.getAverage() +
				" VSENT_MAX " + vsent.getMax() +
				" VRCVD_AVG " + vrcvd.getAverage() +
				" VRCVD_MAX " + vrcvd.getMax() +
				" VMOVEMENT " + vmov.getMax()
		);
		lastlimit++;;
	}
	
	
	if (stop) {
		Log.println(prefix, 
				" ENDTIME " + time + 
				" SUPER " + superpeers + 
				" CLIENTS " + clients + 
				" DEGREE " + degree.getSum() +
				" RATIO " + ratio +
				" SENT_TOT " + totsent.getSum() +
				" MOV_TOT " + totmov.getSum() +
				" SENT_AVG " + sent.getAverage() +
				" SENT_MAX " + sent.getMax() +
				" RCVD_AVG " + rcvd.getAverage() +
				" RCVD_MAX " + rcvd.getMax() +
				" MOVEMENT " + mov.getMax() +
				" VSENT_AVG " + vsent.getAverage() +
				" VSENT_MAX " + vsent.getMax() +
				" VRCVD_AVG " + vrcvd.getAverage() +
				" VRCVD_MAX " + vrcvd.getMax() +
				" VMOVEMENT " + vmov.getMax()
		);
	}
	
	return time > minround && stop;
}

static int[] count;

void check()
{
	int len = Network.size();
	if (count == null || count.length < len)
		count = new int[len];
	for (int i=0; i < len; i++) {
		count[i] = 0;
	}

	for (int i=0; i < len; i++) {
		Node node = Network.get(i);
		Superpeer peer = (Superpeer) node.getProtocol(pid);
		if (peer.getSuperpeer() == null) {
			for (int j=0; j < peer.degree(); j++) {
				Node nclient = peer.getClient(j);
				if (nclient.isUp()) {
					count[nclient.getIndex()]++;
					if (nclient.isUp()) {
						Superpeer pclient = (Superpeer) nclient.getProtocol(pid);
						if (pclient.isSuperpeer()) 
							System.out.println("Warning: client that is a superpeer");
						if (pclient.degree() > 0)
							System.out.println("Warning: client with clients");
					}
				}
			}
		} else {
			if (peer.degree() > 0) {
				System.err.println("Warning: client with clients array");
			}
		}
	}	
	int errors = 0;
	for (int i=0; i < len; i++) {
		if (count[i] >= 2)
			errors++;
	}
	if (errors > 0) 
		System.out.println("Warning: " + errors + " nodes are listed in two or more superpeers");


}



//--------------------------------------------------------------------------
//Methods
//--------------------------------------------------------------------------

public static void addReqSent(int index)
{
	req_sent[index]++;
}

public static void addReqRcvd(int index)
{
	req_rcvd[index]++;
}

public static void addMovement(int index)
{
	movement[index]++;
}

}

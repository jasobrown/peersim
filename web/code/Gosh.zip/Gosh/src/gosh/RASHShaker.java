package gosh;

import peersim.core.*;
import java.lang.StrictMath;

public class RASHShaker 
{
  final double fdil;
  final double fcon;

  // Configuration class for RASH protocol
  RASHConfig conf;

  // Function dimensions
  //int n;

  // Current point and value
  double[] x;
  double current_value;

  // Difference vector for next point generation
  double[] delta;

  // 
  double[] y;

  // vector<vector<double>*> D, base[2], wtmp;
  double[][] D;
  double [][][] base;
  //double [][] wtmp;
  
  int bi;

  boolean firstFailure, firstRun;
  
  public double[] getX () {return x;} 
  
  //public double[] getDelta() {return delta;}
  
public RASHShaker (RASHConfig conf)
{
 this.conf = conf;
 fdil = 1 / conf.e;
 fcon = conf.e;
 int n = conf.f.d();
 double[] max = conf.f.getRangeMax();
 double[] min = conf.f.getRangeMin();
 delta = new double[n];
 x = new double[n];
 y = new double[n];
 D = new double[n][];
 base = new double[2][n][];
 
  for (int i = 0; i < n; i++) {
   x[i]=(max[i]-min[i])* CommonState.r.nextDouble() + min[i];
   delta[i]= 0.0;
   y[i]=0.0;
   D[i] = new double[n];
   base[0][i] =  new double[n];
   base[1][i] =  new double[n];
   for (int j=0;j<n;j++)
     D[i][j]=base[0][i][j]=base[1][i][j]=0.0;
  }

  bi = 0;
  firstFailure = false;
  firstRun = true;
}

//public void shrinkBox ()
//{
//  double minsize = 1;
//  int i, j;
//  for ( i = 0; i < n; i++ ) {
//    double size = 0.0;
//    for ( j = 0; j < n; j++ )
//      size += base[bi][i][j] * base[bi][i][j];
//    if ( size < minsize )
//      minsize = size;
//  }
//  minsize = StrictMath.sqrt (minsize);
//  for ( i = 0; i < n; i++ )
//    for ( j = 0; j < n; j++ )
//      base[bi][i][j] = (i == j) ? minsize : 0.0;
//}

public void restart(double[] x0, double[] eta)
{
  int i;
  int n = conf.f.d();
//  if (x0.length != eta.length)
//    return;
//
//  if ( n != x0.length ) {
//    n = x0.length;

    delta = new double[n];
    x = new double[n];
    y = new double[n];

    D = new double[n][];
    base[0] = new double[n][];
    base[1] = new double[n][];
    //wtmp.resize(n);

    for ( i = 0; i < n; ++i ) {
//     delta[i]= 0.0;
//     y[i]=0.0;
     D[i] = new double[n];
     base[0][i] =  new double[n];
     base[1][i] =  new double[n];
     for (int j=0;j<n;j++)
       D[i][j]=base[0][i][j]=base[1][i][j]=0.0;
    }

  for (i = 0; i < n; ++i) {
    for ( int j = 0; j < n; j++ )
      (base[0][i])[j] = (i == j) ? eta[i] : 0.0;
  }
  
  for (i = 0; i < n; ++i) 
    if (StrictMath.abs(eta[i]) == 0.0)
      return;

  //f = fun;
  System.arraycopy(x0,0,x,0,x0.length);
  current_value = conf.f.eval(x0);
  bi = 0;

  firstFailure = firstRun = false;
}


public double next()
{
  int i, j, k, n=conf.f.d();
  double fact, w;
  
  for ( j = 0; j < n; j++ )
    delta[j]  = 0.0;

  for ( i = 0; i < n; i++ ) {
    double r = 2*CommonState.r.nextDouble()-1.0;
    for ( j = 0; j < n; j++ )
      delta[j] += base[bi][i][j] * r;
  }

  for ( i = 0; i < n; i++ )
    y[i] = x[i] + delta[i];
  w = conf.f.eval(y);

  if ( w >= current_value ) {
    for ( i = 0; i < n; i++ )
      y[i] = x[i] - delta[i];
    w = conf.f.eval(y);  

    if ( w >= current_value )
      firstFailure = true;
  }

  double sumsq = 0.0;
  for ( i = 0; i < n; i++ )
    sumsq += delta[i] * delta[i];

  if (w >= current_value) {
    fact = (fcon - 1.0) / sumsq;
    //--vol;
  }
  else {
    fact = (fdil - 1.0) / sumsq;	
    //++vol;
  }

  if (w < current_value) {
    System.arraycopy(y,0,x,0,y.length);//x = y;
    current_value = w;
  }

  for (i = 0; i < n; ++i)
    for (j = 0; j < n; ++j)
      D[i][j] = firstFailure ? (((i==j)?1.0:0.0) + fact * delta[i] * delta[j]) 
                                : ((i==j)?(1.0+fact):0.0);

  for (i = 0; i < n; ++i)
    for (j = 0; j < n; ++j) {
      base[(1-bi)][i][j] = 0.0;
      for ( k = 0; k < n; k++ )
	base[(1-bi)][i][j] += D[j][k] * base[bi][i][k];
    }
  
  bi = 1-bi;

  return current_value;

}

}

package peersim.skipnet.messages;

public interface MessageStatisticData {
	
	public int getHopCount();
	public boolean isSuccesfullookup();

}

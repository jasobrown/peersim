/*
 * Created on Dec 9, 2004 by Spyros Voulgaris
 *
 */
package gossip.comparator;

import gossip.item.Item;
import java.util.Comparator;


/**
 * @author Spyros Voulgaris
 *
 */
public interface ItemComparator extends Comparator
{
  /**
   * Declare a reference item for comparators that compare
   * two items with respect to a reference item.
   * @param refItem The refItem to set.
   */
  public void setReference(Item refItem);
}

package leo.peersim.common;

import peersim.core.Node;

public class LogicalClock extends LamportEvent {
	
	private Node n;
	private long timestamp;

	public LogicalClock(Node n, long timestamp) {
		this.n = n;
		this.timestamp = timestamp;
	}

	@Override
	public long getLamportNodeID() {
		return this.n.getID();
	}

	@Override
	public long getLamportTimestamp() {
		return this.timestamp;
	}

}

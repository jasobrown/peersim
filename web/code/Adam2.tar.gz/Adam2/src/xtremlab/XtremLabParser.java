package xtremlab;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;


/**
 * A pull-based XML parser (StAX) for XtremLab trace files. 
 * More on XtremLab traces can be found here:
 * http://xtremlab.lri.fr/traces/
 * 
 * @author Jan Sacha
 */
public class XtremLabParser {

	protected BufferedReader reader;
	protected int lineCount;
	
	public XtremLabParser(String xtremLabTraceFile) throws FileNotFoundException {
		FileInputStream fileStream = new FileInputStream(xtremLabTraceFile);
		InputStreamReader streamReader = new InputStreamReader(fileStream);
		reader = new BufferedReader(streamReader);
		lineCount = 0;
	}

	public XtremLabHost readHost() throws ParseException, IOException {
		String line = reader.readLine();
		lineCount++;

		if (line == null) {
			// End of file
			return null;
		}
		
		// Parse the fields
		String[] fields = line.split("\", \"");
		if (fields.length != 34) {
			throw new ParseException("Invalid number of fields", lineCount);
		}

		// Create host object
		XtremLabHost host = new XtremLabHost();
		
		// Host properties
		try {
			// Remove " from the first field
			host.an = Integer.parseInt(fields[0].substring(1));
			host.nresults = Integer.parseInt(fields[1]);
			host.minTime = Long.parseLong(fields[2]);
			host.maxTime = Long.parseLong(fields[3]);
			host.rpc_seqno = Integer.parseInt(fields[4]);
			host.rpc_time = Long.parseLong(fields[5]);
			host.timezone = Integer.parseInt(fields[6]);
			host.nsame_ip_addr = Integer.parseInt(fields[7]);
			host.on_frac = Float.parseFloat(fields[8]);
			host.connected_frac = Float.parseFloat(fields[9]);
			host.active_frac = Float.parseFloat(fields[10]);
			host.cpu_efficiency = Float.parseFloat(fields[11]);
			host.duration_correction_factor = Float.parseFloat(fields[12]);
			host.ncpus = Integer.parseInt(fields[13]);
			host.p_vendor = fields[14];
			host.p_model = fields[15];
			host.p_fpops = Double.parseDouble(fields[16]);
			host.p_iops = Double.parseDouble(fields[17]);
			host.p_membw = Double.parseDouble(fields[18]);
			host.os_name = fields[19];
			host.os_version = fields[20];
			host.m_nbytes = Long.parseLong(fields[21]);
			// This appears to be a float in some records
			host.m_cache = (long)Double.parseDouble(fields[22]);
			host.m_swap = Long.parseLong(fields[23]);
			host.d_total = Long.parseLong(fields[24]);
			host.d_free = Long.parseLong(fields[25]);
			host.d_boinc_used_total = Long.parseLong(fields[26]);
			host.d_boinc_used_project = Long.parseLong(fields[27]);
			host.d_boinc_max = Long.parseLong(fields[28]);
			host.n_bwup = Double.parseDouble(fields[29]);
			host.n_bwdown = Double.parseDouble(fields[30]);
			host.credit_per_cpu_sec = Double.parseDouble(fields[31]);
			host.venue = fields[32];
		}
		catch (NumberFormatException e) {
			throw new ParseException(e.getMessage(), lineCount);
		}
		
		// Parse the last field
		if ("no\"".equals(fields[33])) { 
			host.ip_addr_nat = false;
		}
		else if ("yes\"".equals(fields[33])) {
			host.ip_addr_nat = true;
		}
		else {
			throw new ParseException("Invalid boolean: " + fields[33], lineCount);
		}

		return host;
	}

	public void close() throws IOException {
		reader.close();
	}
	
}

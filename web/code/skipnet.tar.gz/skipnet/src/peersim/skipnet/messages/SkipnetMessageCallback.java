package peersim.skipnet.messages;

public interface SkipnetMessageCallback {

	public void callback(SkipnetMessage msg);
	
}

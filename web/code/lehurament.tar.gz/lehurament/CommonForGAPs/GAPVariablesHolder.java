/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.CommonForGAPs;

import peersim.core.*;
import peersim.config.*;
import peersim.transport.Transport;
import java.util.HashMap;
import java.util.Iterator;
/**
 */
public class GAPVariablesHolder implements  Protocol
{

//--------------------------------------------------------------------------
//Fields
//--------------------------------------------------------------------------
	
protected static final String PAR_TABLEBROADCAST = "tableBroadcast";
private static final String PAR_TRANSPORTCONST = "transportConst"; 
public double value;
public GAPPacket vector;	
public HashMap<Long, row> table;
int nodePacketCount;
int nodeNEWFAILPacketCount;
long packetCount;
public int isTableBroadcast;
private int transpotConstPid;
//--------------------------------------------------------------------------
//Initialization
//--------------------------------------------------------------------------

/**
 */
public GAPVariablesHolder(String prefix)
{
	table=new HashMap<Long, row>();
	vector=new GAPPacket();
	nodePacketCount=0;
	nodeNEWFAILPacketCount=0;
	packetCount=0;
	isTableBroadcast =  Configuration.getInt(prefix + "." + PAR_TABLEBROADCAST);
	transpotConstPid = Configuration.getPid(prefix+"."+PAR_TRANSPORTCONST);
}

//--------------------------------------------------------------------------

/**
 * Clones the value holder.
 */
public Object clone()
{
	GAPVariablesHolder svh=null;
	try { svh=(GAPVariablesHolder)super.clone(); }
	catch( CloneNotSupportedException e ) {} // never happens
	 svh.table=new HashMap<Long, row>();
	 svh.vector=new GAPPacket();
	return svh;
}

//--------------------------------------------------------------------------
//methods
//--------------------------------------------------------------------------
public void setVector(GAPPacket vectorset)
{
	this.vector = vectorset;
}
public GAPPacket getVector()
{
	return this.vector;
}
public void setTable(HashMap<Long, row> tableset)
{
	this.table = tableset;
}
public HashMap<Long, row>  getTable()
{
	return this.table;
}
public double getValue()
{
	return value;
}
public void setValue(double value)
{
	this.value = value;
}
public long getPacketCount()
{
	return packetCount;
}
public void transportPacket( Node node, Node peern, int pid, GAPPacket p) {
	if (p.type==p.type.FAIL)
			((Transport)node.getProtocol(transpotConstPid)).
				send(
					node,
					peern,
					p,
					pid
					);
	else
			((Transport)node.getProtocol(FastConfig.getTransport(pid))).
				send(
					node,
					peern,
					p,
					pid
					);
}
public void tableBroadcast ( Node node, int pid, GAPPacket p) {
	for (Iterator<Long> i=table.keySet().iterator();i.hasNext();) {
		long key=(Long)i.next();
		row r=table.get(key);
		if (r.role==r.role.CHILD || r.role==r.role.PARENT || r.role==r.role.PEER) { 	
			Node peern = r.nodeFrom;
			if (peern==null) {continue;}
			if(!peern.isUp()) {continue;}
			if (p.type==p.type.UPDATE) nodePacketCount+=1;	
			if (p.type==p.type.FAIL || p.type==p.type.NEW) nodeNEWFAILPacketCount+=1;			
			p.nodePacketCount=this.nodePacketCount;
			p.nodeNEWFAILPacketCount=this.nodeNEWFAILPacketCount;
			p.nodeFrom=node;
			p.from=node.getID();
			transportPacket( node, peern, pid, p);
			globalPacketCount(pid,p);
		}
	}
}

public void broadcastPacket( Node node, int pid, GAPPacket p) {
	if (isTableBroadcast==1) 
	{ 
		tableBroadcast(node,pid,p);
	} else
	{
		Linkable linkable = (Linkable) node.getProtocol( FastConfig.getLinkable(pid) );
		if (linkable.degree() > 0) 	
		for (int j = 0; j < linkable.degree(); ++j) {
			Node peern = linkable.getNeighbor(j);
			if(!peern.isUp()) continue;
				if (p.type==p.type.UPDATE) nodePacketCount+=1;	
				if (p.type==p.type.FAIL || p.type==p.type.NEW) nodeNEWFAILPacketCount+=1;				
			p.nodePacketCount=this.nodePacketCount;
			p.nodeFrom=node;
			p.from=node.getID();
			transportPacket( node, peern, pid, p);
			globalPacketCount(pid,p);
		}
	}
}
public void broadcastPacketForFAIL( Node node, int pid, GAPPacket p) {
}
public void sendPacketToNode( Node node, Node nodeto, int pid, GAPPacket p) {
	if (!nodeto.isUp()) return;
	GAPVariablesHolder prot = (GAPVariablesHolder) node.getProtocol(pid);
	if (p.type==p.type.UPDATE) prot.nodePacketCount+=1;
	if (p.type==p.type.FAIL || p.type==p.type.NEW) prot.nodeNEWFAILPacketCount+=1;
	p.nodePacketCount=prot.nodePacketCount;
	p.nodeNEWFAILPacketCount=prot.nodeNEWFAILPacketCount;
	p.nodeFrom=node;
	p.from=node.getID();
	transportPacket( node, nodeto, pid, p);
	globalPacketCount(pid,p);
}		
/**
 * For GAP protocols 0 node is always present, thats why it will count the global packet summa.
 */
void globalPacketCount (int pid,GAPPacket p) {
		GAPVariablesHolder prot = (GAPVariablesHolder) Network.get(0).getProtocol(pid);
		if (p.type!=p.type.TIMEOUT && p.type!=p.type.UPDATELOCAL && p.type!=p.type.FAIL && p.type!=p.type.NEW) 
				prot.packetCount+=1;
}
public Node getNeighbourNodeFromID(long Id, int pid, Node node) {
	for (int j = 0; j < Network.size(); ++j) {
		Node peern = Network.get(j);
		if (peern.getID()==Id) return peern; 
	}
	return null;
}
//--------------------------------------------------------------------------
/**
 * Returns the value as a string.
 */
public String toString() { return ""+value; }
}

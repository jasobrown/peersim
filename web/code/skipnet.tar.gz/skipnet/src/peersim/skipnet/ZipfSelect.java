package peersim.skipnet;

import java.util.Random;

public class ZipfSelect {

	int numDataElements;

	double[] sums;

	boolean defaultSelectZipf = true;

	static Random r;

	public ZipfSelect(int numDataElements, Random random) {
		r = random;
		this.numDataElements = numDataElements;
		sums = new double[numDataElements];
		double sum = 0.0;

		for (int i = 0; i < sums.length; i++) {

			sum += 1.0 / ((double) (i + 2));

		}

		for (int i = 0; i < sums.length; i++) {

			if (i == 0)

				sums[i] = 1.0 / ((double) (i + 2)) / sum;

			else

				sums[i] = sums[i - 1] + 1.0 / ((double) (i + 2)) / sum;

		}

	}

	public static void setRandom(Random random) {
		r = random;
	}

	public void setDefaultToUniform() {
		this.defaultSelectZipf = false;
	}

	public int pick() {
		return pick(this.defaultSelectZipf);
	}

	public int pick(boolean zipfSelect) {
		int indx;
		if (zipfSelect) {
			double u = r.nextDouble();
			indx = 0;
			while (u > sums[indx])
				indx++;
		} else {
			indx = r.nextInt(this.numDataElements);
		}

		return indx;
	}

}

/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.AggregateEDggapRestart;

import peersim.core.*;
import java.util.HashMap;
/**
 * The task of this protocol is to store double values and make it
 * available through the {@link SingleValue} interface.
 *
 * @author Alberto Montresor
 * @version $Revision: 1.1.1.1 $
 */
public class VariableHolderGGap 

implements Protocol
{

//--------------------------------------------------------------------------
//Fields
//--------------------------------------------------------------------------
	
/** Value held by this protocol */
public double value;
public double realvalue;
public double showvalue;
public double weight;
public double showweight;

//--------------------------------------------------------------------------
//Initialization
//--------------------------------------------------------------------------

/**
 * Does nothing.
 */
public VariableHolderGGap(String prefix)
{
	value=0;
	realvalue=Double.NaN;
	showvalue=0;
	weight=0;
	showweight=0;
}

//--------------------------------------------------------------------------

/**
 * Clones the value holder.
 */
public Object clone()
{
	VariableHolderGGap svh=null;
	try { svh=(VariableHolderGGap)super.clone(); }
	catch( CloneNotSupportedException e ) {} // never happens
	return svh;
}

//--------------------------------------------------------------------------
//methods
//--------------------------------------------------------------------------

public double getRealValue()
{
	return realvalue;
}

public double getValue()
{
	return value;
}

public void setValue(double value)
{
	this.value = value;
}
//--------------------------------------------------------------------------

/**
 * Returns the value as a string.
 */
public String toString() { return ""+value; }

}

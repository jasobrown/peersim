package peersim.skipnet;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import peersim.core.CommonState;

/**
 * Class that represents the numeric id for a peersim.extras.am.skipnet node.
 */
public class NumericId implements Cloneable {

//	--------------------------------------------------------------------------
//	Internal classes
//	--------------------------------------------------------------------------
	private class Properties {
		public int b = 2; // number of faces on the random coin
		public int height; // number of random flips, size of address
	}
	
//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------
	static MessageDigest digest;

	private Properties properties;

	private int[] address;
	
//	--------------------------------------------------------------------------
//	Initialization
//	--------------------------------------------------------------------------
	public NumericId(int _height) {
		properties = new Properties();
		properties.b = 2;
		properties.height = _height;

		generateAddress();
	}

//	--------------------------------------------------------------------------
//	Methods
//	--------------------------------------------------------------------------
	
	public void generateAddress() {
		address = new int[properties.height];

		for (int i = 0; i < properties.height; i++)
			address[i] = CommonState.r.nextInt(properties.b);

	}
	
	public void generateAddressFromString(String string) {
		address = new int[properties.height];
		byte input[] = string.getBytes();
		
		try {
			digest = MessageDigest.getInstance("SHA");
            for( int i=0; i<properties.height; i+=16 ) {
            	digest.update(input);
                input = digest.digest();
                for(int j=0; j<16; j++ ) {
                    address[i+j] = Math.abs(input[j]) % properties.b;
                    if( i+j>=properties.height-1 )
                        return;
                }
            }
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public int commonPrefixLen(NumericId toCmp) {
		int len = 0;

		while (true) {
			if (len >= properties.height || len >= toCmp.properties.height)
				return len;

			if (this.address[len] != toCmp.address[len])
				return len;

			len++;
		}
	}

	public int getDigit(int n) {
		return address[n];

	}

	// Set the n'th digit
	public void setDigit(int n, int digit) {
		address[n] = digit;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		if (address != null) {
			for (int i = 0; i < address.length; i++)
				buffer.append(Integer.toString(address[i]));
		}
		return buffer.toString();
	}

	public int getB() {
		return properties.b;
	}

	public void setB(int b) {
		properties.b = b;
	}

	public int getHeight() {
		return properties.height;
	}

	public void setHeight(int height) {
		properties.height = height;
	}

	public Object clone() {
		NumericId result = null;
		try {
			result = (NumericId) super.clone();
		} catch (CloneNotSupportedException e) {
		} // never happens
		result.properties = this.properties;
		//result.generateAddress();

		return result;
	}
	
	public boolean equals(Object object) {
		if (object instanceof NumericId) {
			NumericId nid = (NumericId) object;
			
			if(nid.address.length == address.length) {
				for(int i=0; i<address.length; i++) 
					if(nid.address[i]!=address[i])
						return false;
			} else
				return false;
			
			return true;
			
		}
		else
			return false;
	}

	public int getNumericValue() {
		int n = 0;
		int p = 1;
		for(int i = 0; i<properties.height; i++) {
			n += p * address[i];
			p *= properties.b;
		}
		return n;
	}
	
}

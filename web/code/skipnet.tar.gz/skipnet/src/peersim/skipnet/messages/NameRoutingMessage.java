package peersim.skipnet.messages;

import peersim.core.Node;
import peersim.skipnet.*;

public class NameRoutingMessage extends SkipnetMessage implements MessageStatisticData {

	public SkipnetName destination;

	protected boolean succesfullookup;

	public NameRoutingMessage(Node source, Node nextHop, SkipnetName destination) {
		super(source, nextHop);
		this.destination = destination;
	}

	public void destinationReached(Skipnet skipnet) {
		succesfullookup = destination.equals(skipnet.getLocalname());
		/*if (!succesfullookup) {
			System.out.println("UNSUCCESFUL LOOKUP: message to " + destination
					+ " arrived to " + peersim.extras.am.skipnet.getLocalname());
			//System.out.println(trace.toString());
		}*/
		super.destinationReached(skipnet);
	}

	public void maxHopCountReached(Skipnet node) {
		succesfullookup = false;
		super.maxHopCountReached(node);
	}

	public boolean isSuccesfullookup() {
		return succesfullookup;
	}

}

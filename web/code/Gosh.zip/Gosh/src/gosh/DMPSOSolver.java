/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;

import peersim.config.*;
import peersim.core.*;
import peersim.edsim.*;


public class DMPSOSolver implements EDProtocol, Gosh
{
	//---------------------------------------------------------------------
	//Parameters
	//---------------------------------------------------------------------

	/**
	* @config
	*/
	private static final String PAR_INITPOINTS = "initPoints";
	
	/**
	* @config
	*/
	private static final String PAR_MAXPOINTS = "maxPoints";
	
	/**
	* @config
	*/
	private static final String PAR_PARTICLES = "particles";

	/**
	 * @config
	 */
	private static final String PAR_FUNCTION = "function";

	/**
	* @config
	*/
	private static final String PAR_MAXITER = "maxIter";
	
	/**
	* @config
	*/
	private static final String PAR_MTOFRATIO = "mToFRatio";

	/**
	 * @config
	 */
	private static final String PAR_W1 = "w1";

	/**
	 * @config
	 */
	private static final String PAR_W2 = "w2";

	/**
	 * @config
	 */
	private static final String PAR_C1 = "c1";

	/**
	 * @config
	 */
	private static final String PAR_C2 = "c2";

	/**
	 * @config
	 */
	private static final String MODEL_MAXNEWPOINTS = "modelMaxNew";	
	
	/**
	 * @config
	 */
	private static final String PAR_MTOFRATE = "mToFRate";

    double[] bestPosition;
    double bestValue;
	
    DMPSOConfig pc;
    
    DMPSOSwarm modelSwarm;
    
    DMPSOSwarm functionSwarm;
    
    DMPSOSwarm modOptSwarm;
    	
	BLWRModel model;
	
	double[] bestModel;
	

/**///	BufferedWriter modelOut; BufferedWriter modelIn;

public DMPSOSolver(String prefix)
{
	Function f = (Function) Configuration.getInstance(prefix + "." + PAR_FUNCTION);
	double w1 = Configuration.getDouble(prefix + "." + PAR_W1);
    double w2 = Configuration.getDouble(prefix + "." + PAR_W2);
	double c1 = Configuration.getDouble(prefix + "." + PAR_C1);
	double c2 = Configuration.getDouble(prefix + "." + PAR_C2);
//	double maxSpeed = Configuration.getDouble(prefix + "." + PAR_SPEED);
    int maxIter = Configuration.getInt(prefix + "." + PAR_MAXITER);
    int particles = Configuration.getInt(prefix + "." + PAR_PARTICLES);
    int initPoints = Configuration.getInt(prefix + "." + PAR_INITPOINTS);
    int modelMaxNew = Configuration.getInt(prefix + "." + MODEL_MAXNEWPOINTS);
    int maxPoints = Configuration.getInt(prefix + "." + PAR_MAXPOINTS);
    int mtfr = Configuration.getInt(prefix + "." + PAR_MTOFRATIO);
    int mtfra = Configuration.getInt(prefix + "." + PAR_MTOFRATE);
    init(new DMPSOConfig(f,w1,w2,c1,c2,maxIter,particles,
		  initPoints,modelMaxNew,maxPoints,mtfr,mtfra));

}

public void init(DMPSOConfig pc)
{
	this.pc = pc;
    bestValue = Double.MAX_VALUE;
	model = new BLWRModel(pc.maxPoints, pc.f);
	modelSwarm = new DMPSOSwarm(model,(pc.f.getRangeMax()[0]-pc.f.getRangeMin()[0])/pc.modelMaxNew);
	functionSwarm = new DMPSOSwarm(pc.f,(pc.f.getRangeMax()[0]-pc.f.getRangeMin()[0]));
	modOptSwarm = new DMPSOSwarm(pc.f,(pc.f.getRangeMax()[0]-pc.f.getRangeMin()[0])/(pc.initPoints+pc.modelMaxNew));
	
	bestPosition = new double[pc.f.d()];
	bestModel = new double[pc.f.d()];
	for(int i=0;i<pc.f.d();i++) {
		bestPosition[i]=Double.POSITIVE_INFINITY;
	}
	generateRandomPoint(bestModel);
	functionSwarm.init(this, bestModel);
	
	long delay = CommonState.r.nextLong(pc.f.getTime()+1);
    EDSimulator.add(delay, this, CommonState.getNode(), CommonState.getPid());

/**//*	try {
		if (modelOut!=null) modelOut.close();
		if (modelIn!=null) modelIn.close();
		modelOut=new BufferedWriter(new FileWriter(
				"modelOut"+CommonState.getNode().getID()+".log"));
	 	modelIn=new BufferedWriter(new FileWriter("modelIn"+
	 			CommonState.getNode().getID()+".log"));
    	}
		catch (IOException ioe) {}*/
}

private void generateRandomPoint(double[] x) {

    for (int i=0; i<pc.f.d(); i++)
      x[i]= (pc.f.getRangeMax()[i]- pc.f.getRangeMin()[i])*
              CommonState.r.nextDouble() + pc.f.getRangeMin()[i];
}

/*private double radius (double[] start) {
	double temp,rad=Double.MAX_VALUE;
	for (double s : start) {
		temp = s-f.getRangeMin()[0]<f.getRangeMax()[0]-s?
				s-f.getRangeMin()[0]:f.getRangeMax()[0]-s;
		rad = temp<rad?temp:rad; 
	}
	return rad;
}*/


public boolean addModelPoint(double[] x) {
 
//	System.out.println("New model point added: "+x[x.length-1]);
//	System.out.flush();
	return model.addSamplePoint(x, x[x.length-1], pc.initPoints);
};


public double[] lastAddedPoint () {
	if (model.nextPoint>=0) {
		double[] res = new double[pc.f.d()+1];
		System.arraycopy(model.getX(model.nextPoint),0,res,0,pc.f.d());
		res[res.length-1]=model.getY(model.nextPoint);
		return res;
	}
	else return null;
}


public void processEvent(Node node, int pid, Object event) {

	boolean initModel = (model.points>=1) && (model.points<pc.initPoints);
	boolean goModel = (model.points>=pc.initPoints) && (model.points<pc.modelMaxNew);
	functionSwarm.next();
	if (initModel) {
		modOptSwarm.next();
		if (modOptSwarm.bestValue<functionSwarm.bestValue) {
				setValue(modOptSwarm.bestValue);
				setBest(modOptSwarm.bestPosition);
//				System.out.println("YES, WE CAN!!!"); System.out.flush();
		}
		if (modOptSwarm.count%(pc.maxIter/pc.mToFRate)==0) {
			model.addSamplePoint(bestModel, modOptSwarm.bestValue,
					pc.initPoints);
			generateRandomPoint(bestModel);
			if (model.points==pc.initPoints) {
			//	model.nextPoint=-1;
				modelSwarm.init(this, bestModel);
				modOptSwarm.count = -1;
			}
			else {
				modOptSwarm.init(this, bestModel);
			}
		}	
	}
	else if (goModel) {
		// we found a good starting point from the model
		if (modOptSwarm.count!=-1) {
			modOptSwarm.next();
			if (modOptSwarm.bestValue<functionSwarm.bestValue) {
					setValue(modOptSwarm.bestValue);
					setBest(modOptSwarm.bestPosition);
//					System.out.println("YES, WE CAN!!!"); System.out.flush();
			}
			if (modOptSwarm.count%(pc.maxIter/pc.mToFRate)==0) {
				model.addSamplePoint(bestModel, modOptSwarm.bestValue,
					pc.initPoints);
				generateRandomPoint(bestModel);
				modelSwarm.init(this, bestModel);
				modOptSwarm.count = -1;
			}
		}
		// we're looking for a starting point in the model
		else {
			for (int i=0;i<pc.mToFRatio;i++)
				modelSwarm.next();
			if (modelSwarm.count%((pc.maxIter/pc.mToFRate)*pc.mToFRatio)==0) {
				System.arraycopy(modelSwarm.bestPosition, 0, bestModel, 0,
    			pc.f.d());
				modOptSwarm.init(this, bestModel);
			}
		}
	}
	else { // FUNCTIONSWARM.COUNT ????
		functionSwarm.next();
//		modelSwarm = null;
//		modOptSwarm = null;
	}
	// initial phase, when model has no point and we're waiting for the first
	if ((functionSwarm.count%((pc.maxIter/pc.mToFRate)*2)==0)&&(model.points==0)) {
		model.addSamplePoint(bestModel, functionSwarm.bestValue,
				pc.initPoints);
		generateRandomPoint(bestModel);
		modOptSwarm.init(this, bestModel);		
	}
	
	if ( functionSwarm.bestValue < bestValue ) {
    	System.arraycopy(functionSwarm.bestPosition, 0, bestPosition, 0,
    			pc.f.d());
    	bestValue = functionSwarm.bestValue;
    }
	
	long delay = pc.f.getTime();
//	if (model.points<=1 || initModel || goModel)
	EDSimulator.add(delay, this, CommonState.getNode(), CommonState.getPid());

//	System.out.print(""+modelSwarm.count+"; "+functionSwarm.count+'\n');	
/**//*		try {
			if (goModel && modOptSwarm.count==-1) {
			modelOut.write(model.getX(model.nextPoint)[0]+"	");
			modelOut.write(""+model.getY(model.nextPoint)+'\n'); modelOut.flush();
			}
			else if (initModel){
			modelIn.write(model.getX(model.nextPoint)[0]+"	");
			modelIn.write(""+model.getY(model.nextPoint)+'\n'); modelIn.flush();
			}
		} catch (IOException ioe) {}
*/	
}


public Object clone() 
{
	DMPSOSolver ret = null;
	try {
		ret = (DMPSOSolver) super.clone();
	} 
	catch (CloneNotSupportedException e) { e.printStackTrace();	}
	ret.init(pc);
	return ret;
}

public double getValue()
{
	return bestValue;
}

public double[] getBest()
{
	return bestPosition;
}

public void setValue(double value)
{
	this.bestValue = value;
	functionSwarm.bestValue = value;
}

public void setBest(double[] best)
{
	System.arraycopy(best,0,this.bestPosition,0,bestPosition.length);
	System.arraycopy(best,0,this.functionSwarm.bestPosition,0,
			this.functionSwarm.bestPosition.length);
	
}

}

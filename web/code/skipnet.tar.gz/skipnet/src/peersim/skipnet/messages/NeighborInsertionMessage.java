package peersim.skipnet.messages;

import peersim.core.Node;
import peersim.skipnet.SkipnetUtil.*;

public class NeighborInsertionMessage extends SkipnetMessage {

	public int level;

	public Direction direction;
	

	public NeighborInsertionMessage(Node source, Node nextHop,
			int level, Direction direction) {
		super(source, nextHop);
		this.level = level;
		this.direction = direction;
	}

}

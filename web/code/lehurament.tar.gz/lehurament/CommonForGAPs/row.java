/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.CommonForGAPs;
import peersim.core.Node;
public class row { //a row in the neighbor table			
	public enum roles {SELF, PARENT, PEER, CHILD, FAIL};
	public roles role;
	public int level;
	public int child;
	public double aggregate;
	public int nodePacketCount;
	public int nodeNEWFAILPacketCount;
	public Node nodeFrom;
public int getRow(){
	return this.level;
}
public double getAgg(){
	return this.aggregate;
}
public roles getRole(){
	return this.role;
}
	public row(){
	}	
}

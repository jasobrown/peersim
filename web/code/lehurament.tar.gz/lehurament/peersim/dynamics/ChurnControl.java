package lehurament.peersim.dynamics;

import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

import peersim.config.Configuration;
import peersim.core.*;

import peersim.dynamics.NodeInitializer;

/**
 * This control is responsible for modeling churn behavior which is provided in the following way:
 * <ul>
 * <li>First the control decreases the online session length of each node by one.</li>
 * <li>Then it turns off each node with negative or zero session length.</li>
 * <li>If the number of online nodes in the network is less than that of given in the <i>size</i> parameter of the control, 
 * it adjusts the number of online nodes by adding uniformly selected random offline nodes to the network with a lognormal
 * session length. Each of the newly added nodes is initialized by calling the init method provided by the Churnable @see p2pChurn.interfaces.Churnable 
 * interface.</li>
 * </ul>
 * 
 * @author Róbert Ormándi
 * @author Lehel Nyers
 * Adapred to Aggregation protocols
 * Added functionalities like putting all nodes online at the end of churn
 * 		- forDownNodes (calling end method for down nodes
 *		- forUpNodes (calling init method for nodes which are realy new nodes in network)
 * @navassoc - - - Churnable
 */
public class ChurnControl implements Control {
	/**
	 * Config parameter which gives the prefix of node initializers. An arbitrary
	 * number of node initializers can be specified (Along with their parameters).
	 * These will be applied
	 * on the newly created nodes. The initializers are ordered according to
	 * alphabetical order if their ID.
	 * Example:
	 * <pre>
	control.0 DynamicNetwork
	control.0.init.0 RandNI
	control.0.init.0.k 5
	control.0.init.0.protocol somelinkable
	...
	 * </pre>
	 * @config
	 */
	private static final String PAR_ONLINE = "putonline";
	private static final String PAR_INIT = "init";
	private static final String PAR_PID = "protocol";
	private final int pid;
	private static final String PAR_SIZE = "size";
	private final int size;
	public static final int INIT_SESSION_LENGTH = 0;
	private final long putonline;
	/** node initializers to apply on the newly added nodes */
	protected final NodeInitializer[] inits;
	private static Map<Long, Integer> nowDownNodes = new TreeMap<Long, Integer>();

	public static LogNormalRandom rand;

	public ChurnControl(String prefix) {
    pid = Configuration.getPid(prefix + "." + PAR_PID);
    size = Configuration.getInt(prefix + "." + PAR_SIZE);
    rand  = new LogNormalRandom(Configuration.getLong(prefix+".mu", 0), Configuration.getLong(prefix+".sigma", 1), Configuration.getLong("random.seed", System.currentTimeMillis()));
	Object[] tmp = Configuration.getInstanceArray(prefix + "." + PAR_INIT);
	putonline = Configuration.getLong(prefix+"."+PAR_ONLINE);
	inits = new NodeInitializer[tmp.length];
	for (int i = 0; i < tmp.length; ++i) {
//		System.out.println("Inits " + tmp[i]);
		inits[i] = (NodeInitializer) tmp[i];
	}
}


  public boolean execute() {
	/*
	 * One can put a point to the end of churn when everybody will come online.
	 */
	nowDownNodes.clear();
	if (CommonState.getTime()==putonline)
	{	
		 for (int i = 1; i < Network.size(); i ++) {
				
			 Node node = Network.get(i);
				if (!node.isUp()) 
				{	
		    	  	for (int h = 0; h < inits.length; ++h) {
			  			inits[h].initialize(node);
			  		}
		    	     for (int j = 0; j < node.protocolSize(); j++) {
		    	         Protocol prot = node.getProtocol(j);
		    	         if (prot instanceof Churnable) {
		    	        	 Churnable churnableProt = (Churnable) prot;
		    	        	 churnableProt.initSession(node, j);
		              	  	 churnableProt.forUpNodes(node, j);
		              }
				}
				node.setFailState(Fallible.OK);
		}
	}
	return(false);
	}
	/*
	 * 0. node is fix node thats why -> i=1 in for
	 */

    for (int i = 1; i < Network.size(); i ++) {
      Node node = Network.get(i);
      Protocol prot = node.getProtocol(pid);
      if (prot instanceof Churnable) {
        Churnable churnableProt = (Churnable) prot;
        churnableProt.setSessionLength(churnableProt.getSessionLength() - 1);
        if (churnableProt.getSessionLength() <= 0) {
        	if (node.isUp()) nowDownNodes.put((long) node.getID(),i); 	  
	        node.setFailState(Fallible.DOWN);
        }
      } else {
        throw new RuntimeException("Protocol with PID=" + pid + " does not support modeling churn!!!");
      }
    }

    adjustNumberOfOnlineSessions(size);
    forDownNodes();
    
    return false;
  }
  public void forDownNodes() {
    for (long id : offlineToOnline.keySet()) {
        Node node = Network.get(id2idx.get(id));
        nowDownNodes.remove(id);
        }
    for(Map.Entry<Long,Integer> entry : nowDownNodes.entrySet()) {
        Node node = Network.get(entry.getValue());
    	for (int j = 0; j < node.protocolSize(); j++) {
	    Protocol p = node.getProtocol(j);
   	  		if (p instanceof Churnable) {
   	  				Churnable churnableProtocol = (Churnable) p;
   	  				churnableProtocol.forDownNodes(node, j);
   	  		}
	    }
    }
  }
  public static long getOnlineSessionLength() {
    long len = Math.round(rand.nextDouble());
    while (len == 0) {
      len = Math.round(rand.nextDouble());
    }
    return len;
  }
  private static Map<Long, Integer> id2idx = new TreeMap<Long, Integer>();
  private static Vector<Node> downNodes = new Vector<Node>();
  private static Map<Long,Long> offlineToOnline = new TreeMap<Long,Long>();
  public void adjustNumberOfOnlineSessions(int size) {
    id2idx.clear();
    downNodes.clear();
    int onlineNodes = 0;
    for (int i = 0; i < Network.size(); i ++) {
      Node node = Network.get(i);
      if (node.getFailState() == Fallible.DOWN || node.getFailState() == Fallible.DEAD) {
        downNodes.add(node);
        id2idx.put(node.getID(), i);
      } else {
        onlineNodes ++;
      }
    }
    offlineToOnline.clear();
    while (onlineNodes + offlineToOnline.size() < size && onlineNodes + downNodes.size() >= size) {
      long id = downNodes.get(CommonState.r.nextInt(downNodes.size())).getID();
      if (!offlineToOnline.containsKey(id)) {
        long len = getOnlineSessionLength();
        offlineToOnline.put(id, len);
      }
    }
    for (long id : offlineToOnline.keySet()) {
      Node node = Network.get(id2idx.get(id));
      node.setFailState(Fallible.OK);
    }
    for (long id : offlineToOnline.keySet()) {
      Node node = Network.get(id2idx.get(id));
      if (!nowDownNodes.containsKey(id)) 
    	  	for (int h = 0; h < inits.length; ++h) {
	  			inits[h].initialize(node);
	  		}
      for (int j = 0; j < node.protocolSize(); j++) {
        Protocol prot = node.getProtocol(j);
        if (prot instanceof Churnable) {
          Churnable churnableProt = (Churnable) prot;
          churnableProt.setSessionLength(offlineToOnline.get(id));
          churnableProt.initSession(node, j);
          if (!nowDownNodes.containsKey(id)) 
        	  {	
        	  		churnableProt.forUpNodes(node, j);
        	  }
        }
      }
    }
  }
}


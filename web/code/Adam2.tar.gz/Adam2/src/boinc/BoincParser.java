package boinc;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.NoSuchElementException;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;


/**
 * A pull-based XML parser (StAX) for BOINC trace files. 
 * More on BOINC traces can be found here:
 * http://boinc.berkeley.edu/trac/wiki/XmlStats
 * 
 * Some BOINC trace files can be downloaded from
 * the SETI@home project:
 * http://setiathome.berkeley.edu/stats/
 * 
 * @author Jan Sacha
 */
public class BoincParser {

	protected XMLStreamReader reader;
	
	public BoincParser(String boincTraceFile) throws FileNotFoundException, XMLStreamException {
		this(new FileInputStream(boincTraceFile));
	}

	public BoincParser(InputStream stream) throws XMLStreamException {
		XMLInputFactory factory = XMLInputFactory.newInstance();
		reader = factory.createXMLStreamReader(stream);
	
		// Read in the root element
		readTag("hosts");
	}

	/**
	 * Parses the trace and retrieves the next host entry. 
	 * @return Next host in the trace or null if end of trace reached
	 * @throws XMLStreamException
	 */
	public BoincHost readHost() throws XMLStreamException {
		try {
			// Opening tag
			if (!tryReadTag("host")) {
				// End of file
				readTag("hosts");
				return null;
			}
			
			// Create host object
			BoincHost host = new BoincHost();

			// Host properties
			host.id = readIntProperty("id");
			// User id field seems to be skipped in some records
			host.userid = tryReadIntProperty("userid", -1);			
			host.total_credit = readDoubleProperty("total_credit");
			host.expavg_credit = readDoubleProperty("expavg_credit");
			host.expavg_time = readDoubleProperty("expavg_time");
			host.p_vendor = readProperty("p_vendor");
			host.p_model = readProperty("p_model");
			host.os_name = readProperty("os_name");
			host.os_version = readProperty("os_version");
			host.create_time = readLongProperty("create_time");
			host.rpc_time = readLongProperty("rpc_time");
			host.timezone = readIntProperty("timezone");
			host.ncpus = readIntProperty("ncpus");
			host.p_fpops = readDoubleProperty("p_fpops");
			host.p_iops = readDoubleProperty("p_iops");
			host.p_membw = readDoubleProperty("p_membw");
			// The five props below are encoded as double but should be long in fact
			host.m_nbytes = (long)readDoubleProperty("m_nbytes");
			host.m_cache = (long)readDoubleProperty("m_cache");
			host.m_swap = (long)readDoubleProperty("m_swap");
			host.d_total = (long)readDoubleProperty("d_total");
			host.d_free = (long)readDoubleProperty("d_free");
			host.n_bwup = readDoubleProperty("n_bwup");
			host.n_bwdown = readDoubleProperty("n_bwdown");
			host.avg_turnaround = readDoubleProperty("avg_turnaround");
			host.credit_per_cpu_sec = readDoubleProperty("credit_per_cpu_sec");
			host.host_cpid = readProperty("host_cpid");
			
			// Closing tag
			readTag("host");
	
			return host;
		}
		catch (NoSuchElementException e) {
			throw new XMLStreamException("Parse error: unexpected end of file");
		}
	}

	protected void readTag(String tagName) throws XMLStreamException {
		while (!reader.hasName()) {
			reader.next();
		}
		String tag = reader.getLocalName();
		if (!tag.equals(tagName)) {
			throw new XMLStreamException("Parse error: expecting tag " + tagName);
		}
		reader.next();
	}

	protected String readProperty(String propertyName) throws XMLStreamException {
		// Read the opening tag
		readTag(propertyName);
		// Read the tag contents
		String text = "";
		while (reader.hasText()) {
			//text += reader.getText(); <- This does not work...
			// We have to filter out illegal characters
			char[] characters = reader.getTextCharacters();
			int start = reader.getTextStart();
			int length = reader.getTextLength();
			int stop = start + length;
			for (int i = start; i < stop; i++) {
				//if (characters[i] > 127)  <- A softer version
				if (characters[i] < 32 || characters[i] > 126) {
					
					// Replace illegal characters with '?'
					//characters[i] = '?';
					
					// Ignore the whole string
					readTag(propertyName);
					return "";
				}
			}
			text += new String(characters, start, length);
			reader.next();
		}		
		// Read the closing tag
		readTag(propertyName);
		return text;
	}

	protected int readIntProperty(String propertyName) throws XMLStreamException {
		try {
			String propertyValue = readProperty(propertyName);
			int intValue = Integer.parseInt(propertyValue);
			return intValue;
		}
		catch (NumberFormatException e) {
			throw new XMLStreamException("Parse error: expecting integer type for " + propertyName);
		}
	}
	
	protected long readLongProperty(String propertyName) throws XMLStreamException {
		try {
			String propertyValue = readProperty(propertyName);
			long longValue = Long.parseLong(propertyValue);
			return longValue;
		}
		catch (NumberFormatException e) {
			throw new XMLStreamException("Parse error: expecting long type for " + propertyName);
		}
	}
	
	protected double readDoubleProperty(String propertyName) throws XMLStreamException {
		try {
			String propertyValue = readProperty(propertyName);
			double doubleValue = Double.parseDouble(propertyValue);
			return doubleValue;
		}
		catch (NumberFormatException e) {
			throw new XMLStreamException("Parse error: expecting double type for " + propertyName);
		}
	}

	protected boolean tryReadTag(String tagName) throws XMLStreamException {
		while (!reader.hasName()) {
			reader.next();
		}
		String tag = reader.getLocalName();
		if (tag.equals(tagName)) {
			reader.next();
			return true;
		}
		else {
			return false;
		}
	}

	protected int tryReadIntProperty(String propertyName, int defaultValue) throws XMLStreamException {
		try {
			if (tryReadTag(propertyName)) {
				if (!reader.hasText()) {
					throw new XMLStreamException("Parse error: empty tag " + propertyName);
				}
				String text = reader.getText();
				int propertyValue = Integer.parseInt(text);
				readTag(propertyName);
				return propertyValue;
			}
			else {
				return defaultValue;			
			}
		}
		catch (NumberFormatException e) {
			throw new XMLStreamException("Parse error: expecting integer type for " + propertyName);
		}
	}

	public void close() throws XMLStreamException {
		reader.close();
	}
	
}

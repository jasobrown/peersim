package superpeer;

import peersim.util.*;
import edu.cornell.lassp.houle.RngPack.*;

//
// RngPack 1.0 by Paul Houle
// http://www.msc.cornell.edu/~houle/rngpack 
//

/**
* CommonRandomElement is a wrapper for our CommonRandom number generator.
*
* @author <A HREF="http://www.msc.cornell.edu/~houle" TARGET="edu.cornell.lassp.houle.author"> Paul Houle </A> (E-mail: <A HREF="mailto:houle@msc.cornell.edu">houle@msc.cornell.edu</A>)
* @version 1.0
* @see Ranmar
* @see Ranlux
* @see Ranecu
*/

@SuppressWarnings("serial")
public class CommonRandomElement extends RandomElement {

/**
* Wrapper for <CODE>CommonRandom</CODE>
@see RandomElement#raw
*/
  public double raw() {
  	return CommonRandom.r.nextDouble();
  }  
}

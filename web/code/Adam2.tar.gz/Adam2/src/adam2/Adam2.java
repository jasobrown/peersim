package adam2;

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.TreeSet;

import javax.xml.stream.XMLStreamException;

import peersim.config.Configuration;
import peersim.config.IllegalParameterException;
import peersim.core.Cleanable;
import peersim.core.CommonState;
import peersim.core.Node;
import gossip.item.ItemSimAgeAttr;
import gossip.protocol.Gossip;


/**
 * This class implements the Adam2 protocol. For protocol description, see
 * Jan Sacha, Jeff Napper, Corina Strata, Guillaume Pierre 
 * "Adam2: Reliable Distribution Estimation in Decentralised Environments"
 * ICDCS 2010.
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class Adam2 extends Adam2Base implements Cleanable {
	
	// Interpolation point selection algorithms
	public enum PointSelection { Random, Linear, Neighbours, HCut, LCut, MinMax, BetweenX, BetweenY }

	// Config file parsing strings
	protected static final String PAR_IP = "interpolation.points";
	protected static final String PAR_VP = "verification.points";
	protected static final String PAR_IP_SEL = "ip.selection";
	protected static final String PAR_VP_SEL = "vp.selection";
	protected static final String PAR_CDIST = "distribution.constant";

	// Tuple components
	protected static final int T_MIN = 0;  // Attribute minimum
	protected static final int T_MAX = 1;  // Attribute maximum
	protected static final int T_AVG = 2;  // Attribute average
	protected static final int T_IPX = 3; // Interpolation points X coordinates
	protected static int T_IPY;  // Interpolation points Y coordinates
	protected static int T_VPX; // Verification points X coordinates
	protected static int T_VPY; // Verification points Y coordinates

	// Tuple size
	protected static int size; 

	// Number of interpolation points
	protected static int IP;	
	
	// Number of verification points
	protected static int VP;

	// Interpolation point selection algorithm
	protected static PointSelection ipSelection;

	// Verification point selection algorithm
	protected static PointSelection vpSelection;
		
	// Attribute calculator
	protected static AttributeCalculator ac;
	
	// If this is set, attribute distribution does not change 
	// during an experiment (despite churn) 
	protected static boolean constDist;

	// This node's attribute value
	protected int attr;
	
	// Current estimations of system properties:
	
	// Attribute minimum, maximum, and mean
	protected int min;
	protected int max;
	protected double avg;
	
	// Interpolation points (X and Y coordinates)
	protected int[] ipx;
	protected double[] ipy;

	// Verification points (X and Y coordinates)
	protected int[] vpx;
	protected double[] vpy;

	// CDF approximation
	protected Interpolation cdf;
	

	/**
	 * The constructor creates a "prototype" node that does not actually participate 
	 * in the system but is used later to create other nodes (through cloning)
	 */ 
	public Adam2(String prefix) throws FileNotFoundException, XMLStreamException {
		super(prefix);
		
		String selection = Configuration.getString(prefix + "." + PAR_IP_SEL, "MinMax");
		ipSelection = parsePointSelection(PAR_IP_SEL, selection);
		
		selection = Configuration.getString(prefix + "." + PAR_VP_SEL);
		vpSelection = parsePointSelection(PAR_VP_SEL, selection);
		
		ac = new AttributeCalculator(prefix);
		constDist = Configuration.getBoolean(prefix + "." + PAR_CDIST, false);

		IP = Configuration.getInt(prefix + "." + PAR_IP);
		if (IP < 2) {
			throw new IllegalParameterException(prefix + "." + PAR_IP, "Minimum value is 2!");
		}
		VP = Configuration.getInt(prefix + "." + PAR_VP, IP);

		// Calculate tuple size
		T_IPY = T_IPX + IP;
		T_VPX = T_IPY + IP;
		T_VPY = T_VPX + VP;
		
		size = T_VPY + VP;		
	}

	/**
	 * Individual nodes are created by cloning the "prototype" node.
	 */
	@Override
	public Object clone() {
		Adam2 clone = (Adam2)super.clone();
		
		// Allocate IP arrays
		// Add two slots for minimum and maximum
		clone.ipx = new int[IP + 2];
		clone.ipy = new double[IP + 2];
		
		// Allocate VP arrays
		clone.vpx = new int[VP];
		clone.vpy = new double[VP];

		// Set an attribute value
		if (constDist && !attributes.isEmpty()) {
			// Use the attribute cache
			clone.attr = attributes.remove();
		}
		else {
			// Get a new attribute value
			clone.attr = ac.getAttribute();
		}

		// Reset initial aggregates
		clone.min = clone.attr;
		clone.max = clone.attr;
		clone.avg = clone.attr;

		Arrays.fill(clone.ipx, clone.attr);
		Arrays.fill(clone.ipy, 1);

		clone.cdf = new LinearInterpolation(clone.ipx, clone.ipy);		

		return clone;
	}
	
	/*
	 * This method is called when an uninitialised node (updates == 0)
	 * gossips with an initialised node (updates > 0).
	 * @see adam2.Adam2Base#bootstrap(peersim.core.Node)
	 */
	@Override
	public void bootstrap(Node introducer) {		
		super.bootstrap(introducer);

		// Get a reference to Adam2
		Adam2 agg = (Adam2)introducer.getProtocol(adam2PID);
		assert agg.updates > 0;
		
		// Obtain initial aggregates
		this.min = agg.min;
		this.max = agg.max;
		this.avg = agg.avg;
		
		this.ipx = agg.ipx.clone();
		this.ipy = agg.ipy.clone();
		
		this.cdf = new LinearInterpolation(this.ipx, this.ipy); 
			
		this.vpx = agg.vpx.clone();
		this.vpy = agg.vpy.clone();
	}
	
	// This is a cache of node attribute values.
	// When a node is removed from the system, its attribute value is stored in the cache.
	// When a new node arrives, its attribute value is retrieved from the cache.
	// The purpose of this is to keep the attribute CDF constant.
	private static final LinkedList<Integer> attributes = new LinkedList<Integer>();

	/*
	 * Method called when this node leaves the system.
	 * @see peersim.core.Cleanable#onKill()
	 */
	public void onKill() {
		attributes.add(attr);
	}
	
	
	// *** AGGREGATING FUNCTIONS *** //

	/*
	 * Initialise an instance tuple when starting a new aggregation instance. 
	 */
	@Override
	protected double[] start() {
		double[] tuple = new double[size];

		// Min, max, and mean
		tuple[T_MIN] = attr;
		tuple[T_MAX] = attr;
		tuple[T_AVG] = attr;				

		// Select interpolation points X coordinates for this instance
		// All nodes will have to use the same coordinates
		int[] ipx = selectInterpolationPoints();
		System.out.println("Selected interpolation points: " + arrayToString(ipx));
		
		// Copy the X coordinates to the tuple and initialise 
		// the corresponding Y coordinates
		for (int i = IP - 1; i >= 0; i--) {
			tuple[T_IPX + i] = ipx[i];
			if (attr <= ipx[i]) {
				tuple[T_IPY + i] = 1.0;					
			}
		}

		if (VP > 0) {
			// Select verification points X coordinates for this instance.
			// Again, all nodes will use the same coordinates
			int[] vpx = selectVerificationPoints(ipx);
			System.out.println("Selected verfication points: " + arrayToString(vpx));
			
			// Copy the X coordinates to the tuple and initialise
			// the corresponding Y coordinates.
			for (int i = VP - 1; i >= 0; i--) {
				tuple[T_VPX + i] = vpx[i];
				if (attr <= vpx[i]) {
					tuple[T_VPY + i] = 1.0;					
				}
			}
		}
		return tuple;
	}

	
	/*
	 * Initialise an instance tuple when joining an aggregation instance.
	 * @see adam2.Adam2Base#join(double[])
	 */
	@Override
	protected double[] join(double[] a) {
		// Allocate a new tuple
		double[] tuple = new double[size];

		// Initialise min, max, and avg
		tuple[T_MIN] = attr;
		tuple[T_MAX] = attr;
		tuple[T_AVG] = attr;
		
		// Copy IPX
		System.arraycopy(a, T_IPX, tuple, T_IPX, IP);
		
		// Initialise IPY
		for (int i = IP - 1; i >= 0; i--) {
			if (attr <= tuple[T_IPX + i]) {
				tuple[T_IPY + i] = 1.0;					
			}
			else {
				break;
			}
		}

		// Copy VPX
		System.arraycopy(a, T_VPX, tuple, T_VPX, VP);
		
		// Initialise VPY
		for (int i = VP - 1; i >= 0; i--) {
			if (attr <= tuple[T_VPX + i]) {
				tuple[T_VPY + i] = 1.0;					
			}
			else {
				break;
			}
		}
		return tuple;
	}

	
	/*
	 * Merge two instance tuples.
	 * @see adam2.Adam2Base#merge(double[], double[])
	 */
	@Override
	protected void merge(double[] a, double[] b) {
		// Calculate min
		a[T_MIN] = (a[T_MIN] < b[T_MIN]) ? a[T_MIN] : b[T_MIN];
		b[T_MIN] = a[T_MIN];
		
		// Calculate max
		a[T_MAX] = (a[T_MAX] > b[T_MAX]) ? a[T_MAX] : b[T_MAX];
		b[T_MAX] = a[T_MAX];
		
		// Calculate avg
		a[T_AVG] = (a[T_AVG] + b[T_AVG]) / 2.0;
		b[T_AVG] = a[T_AVG];

		// Merge IPY values (assuming both nodes use the same IPX)
		for (int i = 0; i < IP; i++) {
			assert a[T_IPX + i] == b[T_IPX + i];
			a[T_IPY + i] = (a[T_IPY + i] + b[T_IPY + i]) / 2.0;
			b[T_IPY + i] = a[T_IPY + i];
		}
		// Merge VPY values (assuming both nodes use the same VPX)
		for (int i = 0; i < VP; i++) {
			assert a[T_VPX + i] == b[T_VPX + i];
			a[T_VPY + i] = (a[T_VPY + i] + b[T_VPY + i]) / 2.0;
			b[T_VPY + i] = a[T_VPY + i];
		}
	}

	
	/*
	 * Update current estimations of system properties when an instance ends.
	 * @see adam2.Adam2Base#update(double[])
	 */
	@Override
	protected void update(double[] a) {
		// Update min, max, and avg
		min = (int)Math.round(a[T_MIN]);
		max = (int)Math.round(a[T_MAX]);
		avg = a[T_AVG];

		// Update the set of interpolation points
		// Add minimum at the begining
		ipx[0] = min - 1;
		ipy[0] = 0;
		
		// Add maximum at the end
		ipx[IP + 1] = max;
		ipy[IP + 1] = 1;			

		// Copy the points in between
		// (removing all points outside the (min, max) interval)
		for (int i = 0; i < IP; i++) {
			if (a[T_IPX + i] < min) {
				// Point below attribute minimum
				ipx[i + 1] = min - 1;
				ipy[i + 1] = 0;
			}
			else if (a[T_IPX + i] > max) {
				// Point above attribute above maximum
				ipx[i + 1] = max;
				ipy[i + 1] = 1;
			}
			else {
				// This point is OK
				ipx[i + 1] = (int)a[T_IPX + i];
				ipy[i + 1] = a[T_IPY + i];
			}
		}
		
		// Copy the verification points
		for (int i = VP - 1; i >= 0; i--) {
			vpx[i] = (int)a[T_VPX + i];
			vpy[i] = a[T_VPY + i];
		}

		// Interpolate
		cdf = new LinearInterpolation(ipx, ipy);	
	}
		
	
	// *** POINT SELECTION *** ///
	
	// Select interpolation point X coordinates for the next instance
	protected int[] selectInterpolationPoints() {
		if (updates == 0) {
			// We have no current CDF estimation
			return neighbourBasedPoints(IP, false);
		}
		else {
			// Use the knowledge from the previous instance.
			// Always add the minimum attribute as one of the 
			// interpolation points in order to interpolate the 
			// whole (min, max) range. Maximum does not need to 
			// be here, since we know that ipy(max) == 1
			switch (ipSelection) {
				case Random:
					return randomPoints(IP, true);
				case Linear:
					return linearPoints(IP);
				case Neighbours:
					return neighbourBasedPoints(IP, true);
				case HCut:
					return hCut(IP);
				case LCut:
					return lCut(IP);
				case MinMax:
					return minMax(IP, false);
				default:
					throw new RuntimeException("Invalid interpolation point selection method: " + ipSelection);
			}
		}
	}
	
	// Select verification point X coordinates for the next instance.
	// The IPX argument is the selected interpolation point X coordinates.
	protected int[] selectVerificationPoints(int[] ipx) {
		if (updates == 0) {
			// There is no CDF approximation, but interpolation points
			// have been selected
			return betweenCurrentPoints(VP, ipx, false, true);
		}
		else {
			// Use the knowledge from the previous instance.
			switch (vpSelection) {
			case Random:
				return randomPoints(VP, false);
			case Linear:
				return linearPoints(VP);
			case Neighbours:
				return neighbourBasedPoints(VP, false);
			case BetweenX:
				return betweenCurrentPoints(VP, ipx, false, true);
			case BetweenY:
				return betweenCurrentPoints(VP, ipx, true, true);
			default:
				throw new RuntimeException("Invalid verification point selection method: " + vpSelection);
			}
		}
	}

	// Assign point X coordinates uniformly random between min and max
	protected int[] randomPoints(int resolution, boolean addMin) {
		int[] px = new int[resolution];
		int width = max - min;
		if (width == 0) {
			Arrays.fill(px, min);
		}
		else {
			for (int i = 0; i < resolution; i++) {
				px[i] = min + CommonState.r.nextInt(width);
			}
			if (addMin) {
				px[0] = min;
			}
		}
		Arrays.sort(px);
		return px;
	}

	// Assign point X coordinates in fixed intervals between min and max
	protected int[] linearPoints(int resolution) {
		int[] px = new int[resolution];
		for (int i = 0; i < resolution; i++) {			
			int threshold = min + ((max - min) * i) / resolution;
			px[i] = threshold;
		}
		return px;
	}

	// The HCut algorithm. Select IPX such that the corresponding IPY 
	// divide the CDF image into equal intervals (based on the current 
	// CDF estimation).
	protected int[] hCut(int resolution) {
		// Interpolate the current CDF points and reverse the function
		Interpolation revInterpolation = new LinearInterpolation(ipy, ipx);
		// Allocate ipx
		int[] ipx = new int[resolution];
		// Always add minimum
		ipx[0] = min;
		// Add the remaining points
		for (int i = 1; i < resolution; i++) {
			double fraction = (double)i / (double)resolution;
			ipx[i] = (int)Math.round(revInterpolation.interpolate(fraction));		
		}	
		return ipx;
	}

	// The LCut algorithm. Select points that divide the current CDF curve
	// into equal-length parts (based on Euclidean distance).
	protected int[] lCut(int resolution) {
		// Scale parameter for the x axis
		double scale = 1.0 / max;
		// Calculate the total curve length. 
		// Skip the first point since it's equal to (min-1, 0)
		double len = 0;
		double x = ipx[1];
		double y = ipy[1];
		for (int i = 1; i <= resolution; i++) {
			len += Math.sqrt(scale * (ipx[i] - x) * scale * (ipx[i] - x) + (ipy[i] - y) * (ipy[i] - y));
			x = ipx[i];
			y = ipy[i];
		}
		// Divide the CDF curve into equal parts.
		// Assume that the curve consists of line segments. 
		double section = len / (double)resolution;
		int[] newIPX = new int[resolution];
		// Add minimum
		newIPX[0] = min;
		// Current segment's endpoints
		double x1 = ipx[1];
		double y1 = ipy[1];
		double x2 = ipx[1];
		double y2 = ipy[1];
		// The length of the current part
		double pLen = 0;
		// Interpolation point index
		int ipIndex = 2;
		int newIndex = 1;
		// Find all points one by one
		while (newIndex < resolution) {
			// Current segment's length
			double curLen = Math.sqrt(scale * (x2 - x1) * scale * (x2 - x1) + (y2 - y1) * (y2 - y1));
			// Required length
			double reqLen = section - pLen;
			if (curLen > reqLen) {
				// Divide the current segment
				double x3 = x2 + (x1 - x2) * ((curLen - reqLen) / curLen);
				double y3 = y2 + (y1 - y2) * ((curLen - reqLen) / curLen);
				// Add the midpoint to the results
				newIPX[newIndex] = (int)Math.round(x3);
				newIndex++;
				// The remaining part becomes the current segment
				x1 = x3;
				y1 = y3;
				pLen = 0;
			}
			else {
				// Add a new segment
				if (ipIndex > resolution) {
					// There are no more segments. This should never happen.
					newIPX[newIndex] = max;
					newIndex++;
				}
				else {
					// Add the whole segment to the current part
					pLen += curLen; 
					x1 = x2;
					y1 = y2;
					// Go to the next interpolation point
					x2 = ipx[ipIndex];
					y2 = ipy[ipIndex];
					ipIndex++;
				}
			}
		}
		// Sort the points just in case
		Arrays.sort(newIPX);
		return newIPX;
	}

	// Selecte points based on the attribute values of the neighbours
	// in the P2P overlay. 
	protected int[] neighbourBasedPoints(int resolution, boolean addMin) {
		// Initialise results. Fill the array with MAX_VALUE so that 
		// the array can be sorted without mixing current results.
		int[] points = new int[resolution];
		Arrays.fill(points, Integer.MAX_VALUE);
				
		// Fist, add itself
		points[0] = attr;
		int count = 1;

		// Add minimum if needed
		if (addMin) {
			points[1] = min;
			count++;
		}
		// Next, add Cyclon neighbours
		Gossip gossip = (Gossip)CommonState.getNode().getProtocol(gossipPID);
		for (int i = 0; i < gossip.degree(); i++) {
			// Cyclon has to use items that carry attribute values
			assert gossip.items.get(i) instanceof ItemSimAgeAttr;
			ItemSimAgeAttr item = (ItemSimAgeAttr)gossip.items.get(i);
			points[count] = item.attr;
			count++;
			if (count == resolution) {
				break;
			}
		}
		if (count == 1) {
			// We have a problem... is the node isolated? 
			// Add a value of zero since we need to fill the array with something
			points[1] = 0;
			count++;
		}

		// If points are still needed, add new points between the current points
		while (count < resolution) {
			Arrays.sort(points);
			int oldCount = count;
			for (int b = 0; b < oldCount - 1; b++) {
				if (points[b + 1] - points[b] > 1) {
					// Add a new point between b and b+1
					points[count] = (points[b] + points[b + 1]) / 2;
					count++;
					if (count == resolution) {
						break;
					}
				}
			}
			if (count == oldCount) {
				// No new points can be added between the current points...
				break;
			}
		}
		// Sort the points and exit
		Arrays.sort(points);
		return points;
	}
		

	// This class represents an interpolation or verification point.
	// Points are sorted by their X coordinates.
	class Point implements Comparable<Point> {
		int attr;
		double value;
		
		public Point(int attr, double value) {
			this.attr = attr;
			this.value = value;
		}

		public int compareTo(Point that) {
			if (this.attr < that.attr) {
				return -1;
			}
			else if (this.attr > that.attr) {
				return +1;
			}
			else {
				// Make sure that points are not equal, unless they refer to the same object
				return this.hashCode() - that.hashCode();
			}
		}
	}
	

	// The MinMax algorithm. See the paper for a full description.
	protected int[] minMax(int resolution, boolean randomised) {
		assert ipx.length > 2;
		
		// Initialise point collections
		TreeSet<Point> oldPoints = new TreeSet<Point>();
		TreeSet<Point> newPoints = new TreeSet<Point>();
		// Add all current points to both collections
		for (int i = 1; i < ipx.length; i++) {
			Point b = new Point(ipx[i], ipy[i]);
			oldPoints.add(b);
			newPoints.add(b);
		}
		
		// Next, move some points to obtain a better CDF approximation
		for (;;) {
			// Find the closest three points in the old set in terms of vertical distances
			Point prev = null;
			Point prevPrev = null;
			double min = Double.POSITIVE_INFINITY;
			Point midPoint = null;
			for (Point p: oldPoints) {
				if (prevPrev != null) {
					double dist;
					if (p.attr - prevPrev.attr <= 1) {
						// The points must overlap. This is unnecessary 
						// and the midpoint should be moved.
						dist = 0;
					}
					else {
						// Vertical distance between the points
						dist = p.value - prevPrev.value;
					}
					if (dist < min) {
						// Store the minimum distance and midpoint
						min = dist;
						midPoint = prev;
					}					
				}
				prevPrev = prev;
				prev = p;				
			}

			// Find the furthest two points in the new set in terms of vertical distances
			prev = null;
			double max = Double.NEGATIVE_INFINITY;
			Point maxPoint1 = null;
			Point maxPoint2 = null;
			for (Point p: newPoints) {
				if (prev != null) {
					assert p.attr >= prev.attr;
					double dist;
					if (p.attr - prev.attr <= 1) {
						// The points are so close along the X axis 
						// that nothing can be put in between.
						dist = 0;
					}
					else {
						// Vertical distance between the points
						dist = p.value - prev.value;
					}
					if (dist > max) {
						// Store the maximum distance and both points
						max = dist;
						maxPoint1 = prev;
						maxPoint2 = p;
					}
				}
				prev = p;				
			}
			
			// Check if any points should be changed
			if (min > max) {
				// Nothing to do anymore
				break;
			}
			else {
				// Remove the midpoint from both collections 
				oldPoints.remove(midPoint);
				newPoints.remove(midPoint);
				// Add a new point to the new collection 
				int x;
				double y;
				if (randomised) {
					// Add the point randomly between maxPoint1 and maxPoint2
					double r = CommonState.r.nextDouble();
					x = maxPoint1.attr + (int)Math.floor((maxPoint2.attr - maxPoint1.attr) * r);
					y = maxPoint1.value + (maxPoint2.value - maxPoint1.value) * r;		
				}
				else {
					// Add the point in the middle of the gap between maxPoint1 and maxPoint2
					x = (maxPoint1.attr + maxPoint2.attr) / 2;
					y = (maxPoint1.value + maxPoint2.value) / 2;					
				}
				newPoints.add(new Point(x, y));
			}
		}
		// Allocate an array for the results
		int[] results = new int[resolution];
		int i = 0;
		// Take all the points from the new collection
		for (Point b: newPoints) {
			if (i == 0) {
				// Move the first point to min if needed
				b.attr = min;
			}
			// Store the X coordinates in the results array
			results[i] = b.attr;
			i++;
			if (i == resolution) {
				break;
			}
		}
		return results;
	}

	
	// This algorithm inserts verification points into the largest gaps
	// between the current interpolation points. 
	// Parameters: number of verification points, current interpolation 
	// points, distance metric (horizontal or vertical), and randomisation.
	protected int[] betweenCurrentPoints(int resolution, int[] ipx, boolean vertical, boolean randomised) {
		// Current interpolation points
		TreeSet<Point> points = new TreeSet<Point>();
		for (int i = 0; i < ipx.length; i++) {
			// Estimate IPY values using the current CDF approximation
			points.add(new Point(ipx[i], cdf.interpolate(ipx[i])));
		}
		// Add maximum
		points.add(new Point(max, 1));

		// Select verification points between current points
		int[] vpx = new int[resolution];
		for (int i = 0; i < resolution; i++) {
			// Find the largest vertical distance between existing points
			Point prev = null;
			double max = Double.NEGATIVE_INFINITY;
			Point maxPoint1 = null;
			Point maxPoint2 = null;
			for (Point p: points) {
				if (prev != null) {
					// Distance between p and prev
					double dist; 
					if (p.attr - prev.attr <= 1) {
						// No points can be put in between
						dist = 0;
					}
					else {
						if (vertical) {
							// Vertical distance
							dist = p.value - prev.value;
						}
						else {
							// Horizontal distance
							dist = p.attr - prev.attr;
						}
					}
					if (dist > max) {
						// Store the maximum distance and the endpoints
						max = dist;
						maxPoint1 = prev;
						maxPoint2 = p;
					}
				}
				prev = p;
			}
			// Add a new point between maxPoint1 and maxPoint2
			int x;
			double y;
			if (randomised) {
				// Add the new point randomly 
				double r = CommonState.r.nextDouble();
				x = maxPoint1.attr + (int)Math.floor((maxPoint2.attr - maxPoint1.attr) * r);
				y = maxPoint1.value + (maxPoint2.value - maxPoint1.value) * r;		
			}
			else {
				// Add the new point in the middle
				x = (maxPoint1.attr + maxPoint2.attr) / 2;
				y = (maxPoint1.value + maxPoint2.value) / 2;					
			}
			points.add(new Point(x, y));
			// Store the X coordinate in the results array
			vpx[i] = x;
		}
		// Sort the results and exit
		Arrays.sort(vpx);
		return vpx;
	}
	

	// *** PUBLIC INTERFACE *** //
	
	// Current node's attribute value
	public int getAttribute() {
		return attr;
	}
	
	// The time when the node joined the system
	public long getBirthTime() {
		return birthTime;
	}

	// The X coordinates of the current interpolation points
	public int[] getInterpolationPointsX() {
		if (updates > 0) {
			// We should have a valid CDF interpolation
			return ipx;
		}
		else {
			// Retrieve the results from a running aggregation instance
			Instance instance = getOldestInstance();
			if (instance == null) {
				// Nothing we can do...
				return null;
			}
			else {
				// Copy the points from the selected instance
				int[] ipx = new int[IP];
				for (int i = 0; i < IP; i++) {
					ipx[i] = (int)instance.props[T_IPX + i];
				}
				return ipx;
			}			
		}
	}

	// The Y coordinates of the current interpolation points
	public double[] getInterpolationPointsY() {
		if (updates > 0) {
			// We should have a valid CDF interpolation
			return ipy;			
		}
		else {
			// Retrieve the results from a running aggregation instance
			Instance instance = getOldestInstance();
			if (instance == null) {
				// Nothing we can do...
				return null;
			}
			else {
				// Copy the points from the selected instance
				double[] ipy = new double[IP];
				System.arraycopy(instance.props, T_IPY, ipy, 0, IP);
				return ipy;
			}
		}
	}
	
	// The current CDF approximation
	public Interpolation getCDF() {
		if (updates > 0) {
			// We should have a valid CDF approximation
			return cdf;
		}
		else {
			// Try to use partial results
			int[] ipx = getInterpolationPointsX();
			double[] ipy = getInterpolationPointsY();
			if (ipx != null && ipy != null) {
				return new LinearInterpolation(ipx, ipy);
			}
			else {
				return null;
			}
		}
	}

	// Estimated system size
	public double getN() {
		return N;
	}
	
	// Maximum attribute value
	public double getMax() {
		return max;
	}
	
	// Minimum attribute value
	public double getMin() {
		return min;
	}

	// Mean attribute value
	public double getAvg() {
		return avg;
	}

	// This node's rank
	public double getRank() {
		if (updates > 0) {
			return (1.0 - cdf.interpolate(attr)) * (double)N;
		}
		else {
			// No CDF estimation
			return Double.NaN;
		}
	}
	
	
	// The estimated average CDF interpolation error 
	public double getAvgError() {
		if (updates == 0) {
			// No CDF estimation
			return Double.NaN;
		}
		// Calculate the average interpolation error over all verification points
		double sum = 0;
		for (int i = 0; i < VP; i++) {
			double approx = cdf.interpolate(vpx[i]);
			double real = vpy[i];
			sum += real > approx ? real - approx : approx - real;
		}
		return sum / VP;
	}

	// The estimated maximum CDF interpolation error
	public double getMaxError() {
		if (updates == 0) {
			// No CDF estimation
			return Double.NaN;
		}
		// Calculate the maximum interpolation error over all verification points
		double max = 0;
		for (int i = 0; i < VP; i++) {
			double approx = cdf.interpolate(vpx[i]);
			double real = vpy[i];
			double dist = real > approx ? real - approx : approx - real;
			if (dist > max) {
				max = dist;
			}
		}
		return max;
	}


	// *** AUXILIARY *** //
	
	protected PointSelection parsePointSelection(String parameter, String value) {
		if ("Random".equals(value)) {
			return PointSelection.Random;
		}
		else if ("Linear".equals(value)) {
			return PointSelection.Linear;
		}
		else if ("Neighbours".equals(value)) {
			return PointSelection.Neighbours;
		}
		else if ("HCut".equals(value) && parameter.equalsIgnoreCase(PAR_IP_SEL)) {
			return PointSelection.HCut;
		}
		else if ("LCut".equals(value) && parameter.equalsIgnoreCase(PAR_IP_SEL)) {
			return PointSelection.LCut;
		}
		else if ("MinMax".equals(value) && parameter.equalsIgnoreCase(PAR_IP_SEL)) {
			return PointSelection.MinMax;
		}
		else if ("BetweenX".equals(value) && parameter.equalsIgnoreCase(PAR_VP_SEL)) {
			return PointSelection.BetweenX;
		}
		else if ("BetweenY".equals(value) && parameter.equalsIgnoreCase(PAR_VP_SEL)) {
			return PointSelection.BetweenY;
		}
		else {
			throw new IllegalParameterException(parameter, "Unknown point selection method: " + value);
		}
	}
	
	public static String arrayToString(double[] array) {
		String s = "";
		for (int i = 0; i < array.length; i++) {
			s += array[i] + " ";
//				s += (float)array[i] + " ";
		}
		return s;
	}

	public static String arrayToString(int[] array) {
		String s = "";
		for (int i = 0; i < array.length; i++) {
			s += array[i] + " ";
		}
		return s;
	}

}

/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.core.CommonState;
import peersim.config.*;

// d=? ; opt.=0.0 NEEDS conf. parameter seed (uns. long) and center_num (int)
public class RBFFunction extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;

// private static final String PAR_SEED = "seed";

// private long seed;  // must be positive

private static final String PAR_C = "c";

private int centers_num;
private double[][][] metric;
private double[][] center;
private double[] weight;
//private double	near_opt; b// a che serve???
//private double[]  wtmp;   b// a che serve???

public RBFFunction(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);

//        seed = Configuration.getLong(prefix + "." + PAR_SEED);
        centers_num = Configuration.getInt(prefix + "." + PAR_C);

        rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = 0.0;
    rangeMax[i] = 1.0;
  }

  int		h, k, i, j, niter;
  double	w1, w2, sin_theta, cos_theta;
  //java.util.Random rand= new java.util.Random(seed);

  weight = new double  [centers_num];
  center = new double [centers_num][];
  metric = new double [centers_num][][];
  for (i = 0; i < centers_num; ++i)
	  {
	    center[i] = new double[d];
	    metric[i] = new double[d][];
	    for (j = 0; j < d; ++j)
		    metric[i][j] = new double[d];
	  }

  for (k = 0; k < centers_num; ++k)
	  {
	    weight[k] = -100.0 * CommonState.r.nextDouble() - 10.0;
	    for (i = 0; i < d; ++i)
		    center[k][i] = CommonState.r.nextDouble();
	  }
  weight[0] = -400;

  for (k = 0; k < centers_num; ++k)
	  for (i = 0; i < d; ++i)
		  {
		    for (j = 0; j < d; ++j)
			    metric[k][i][j] = 0.0;
		    metric[k][i][i] = 8192.0 * CommonState.r.nextDouble();
		  }
  for (k = 0; k < centers_num; ++k)
	  {
	    niter = d * (d-1) / 2;
	    while (niter!=0)
		{
		  i = j = 1;
		  while (i == j)
			{
		  	  i = CommonState.r.nextInt(Integer.MAX_VALUE) % d;  // has to be positive !!!
		  	  j = CommonState.r.nextInt(Integer.MAX_VALUE) % d;  // has to be positive !!!
			}

		  cos_theta = StrictMath.cos (2.0 * StrictMath.PI * CommonState.r.nextDouble());
		  sin_theta = StrictMath.sqrt(1.0 - cos_theta * cos_theta);

		  for (h = 0; h < d; ++h)
			{
		  	  w1        	  = metric[k][i][h];
			  w2        	  = metric[k][j][h];
			  metric[k][i][h] = w1 * cos_theta - w2 * sin_theta;
			  metric[k][j][h] = w1 * sin_theta + w2 * cos_theta;
			}
		  for (h = 0; h < d; ++h)
			{
			  w1 	          = metric[k][h][i];
			  w2 	          = metric[k][h][j];
			  metric[k][h][i] = w1 * cos_theta - w2 * sin_theta;
			  metric[k][h][j] = w1 * sin_theta + w2 * cos_theta;
			}
                  niter--;
		}
	  }
//  wtmp= new double[d];
//  for (i = 0; i < d; ++i)
//	  {
//	    wtmp[i] = center[0][i];
//	  }
//  near_opt = (*this)(wtmp); b // ??
}

public double eval(double[] x)
{
  double	w;
  int 		i,j,k;

  double Result = 0.0;
  for (k = 0; k < centers_num; ++k)
  {
    w = 0.0;
    for (i = 0; i < d; ++i)
            for (j = 0; j < d; ++j)
                    w -= metric[k][i][j]*(x[i]-center[k][i])*(x[j]-center[k][j]);
    Result += weight[k] * StrictMath.exp(w/d);
  }
  return Result;
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;

};

}

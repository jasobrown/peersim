/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.CommonForGAPs;

import peersim.core.*;
import java.util.HashMap;

public class GAPPacket extends Packet {
	public static enum types {NEW, FAIL, UPDATE, UPDATENEW, UPDATELOCAL,TIMEOUT};
	public types type;	
	public Node nodeFrom;
	public int level;
	public int child;
	public long parent;
	public long from;
	public double aggregate;
	public double global;
	public int nodePacketCount;
	public int nodeNEWFAILPacketCount;
	public HashMap<Long, Double> listAgg;
	public HashMap<Long, Integer> listSum;
	
	public GAPPacket() {
		type=types.UPDATE;	
		level=-1;
		parent=-1;
		from=-1;
		aggregate=0;
		child=0;
		global=0;
		nodePacketCount=0;
		nodeNEWFAILPacketCount=0;
		listAgg=new HashMap<Long, Double>();
		listSum=new HashMap<Long, Integer>();
	}
		
	public GAPPacket(GAPPacket p) {
		type=p.type;
		from=p.from;
		level=p.level;
		parent=p.parent;
		aggregate=p.aggregate;
		global=p.global;
		nodePacketCount=p.nodePacketCount;
		nodeNEWFAILPacketCount=p.nodeNEWFAILPacketCount;
	}
	public boolean equals(GAPPacket p) {
		return (p.listAgg.equals(listAgg) && p.listSum.equals(listSum) &&
				p.child==child && p.from==from && p.level==level && p.parent==parent && p.aggregate==aggregate && p.global==global );
	}
	public boolean justGlobal(GAPPacket p) {
		return (p.child==child && p.from==from && p.level==level && p.parent==parent && p.aggregate==aggregate && p.global!=global );
	}
}
abstract class Packet {
	/**
	 * sorce of packet.
	 */
	int from;
	/**
	 * destination of packet.
	 */
	int to;
/**
 * set both to -1, the broadcast address
 *
 */
	Packet() {
		to = from = -1;
	}
}

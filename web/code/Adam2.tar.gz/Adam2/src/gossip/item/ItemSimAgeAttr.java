package gossip.item;

import adam2.Adam2;
import peersim.core.Node;


/**
 * An extended Cyclon item which contains a node attribute.
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class ItemSimAgeAttr extends ItemSimAge {
	
	private static int adam2PID = -1;
	
	public int attr;

	
	@Override
	public void init(Node node) {
		super.init(node);
		if (adam2PID < 0) {
			// Find the protocol ID for Adam2
			int protocols = node.protocolSize();
			for (int i = 0 ; i < protocols; i++) {
				if (node.getProtocol(i) instanceof Adam2) {
					adam2PID = i;
					break;
				}
			}
			if (adam2PID < 0) {
				throw new RuntimeException("ItemSimAgeAttr: Adam2 protocol not found!");	
			}
		}
		// Get the node's attribute value
		Adam2 adam2 = (Adam2)node.getProtocol(adam2PID);
		attr = adam2.getAttribute();
	}
	
}

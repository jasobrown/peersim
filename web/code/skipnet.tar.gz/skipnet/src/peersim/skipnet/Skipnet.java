package peersim.skipnet;


import edu.uci.ics.jung.graph.Vertex;
import peersim.config.Configuration;
import peersim.config.FastConfig;
import peersim.core.Fallible;
import peersim.core.Linkable;
import peersim.core.Node;
import peersim.edsim.EDProtocol;
import peersim.edsim.EDSimulator;
import peersim.skipnet.SkipnetUtil.*;
import peersim.skipnet.messages.*;
import peersim.transport.Transport;

/**
 * This class implements the peersim.extras.am.skipnet protocol functionality. It needs to be
 * initialized from a SkipnetInit instance. For protocol details see <a
 * href="http://research.microsoft.com/sn/Herald/papers/Usits_abstract.html">SkipNet:
 * A Scalable Overlay Network with Practical Locality Properties</a>
 * 
 * @author Rodolfo Cartas
 * 
 */
public class Skipnet implements EDProtocol, Linkable {
	// TODO fixup

//	--------------------------------------------------------------------------
//	Parameters
//	--------------------------------------------------------------------------
	
	/**
	 * This parameter defines the height of the routing table (length of the
	 * address).
	 * 
	 * @config
	 */
	private static final String PAR_HEIGHT = "height";

	/**
	 * This parameter defines the interval between successive pings.
	 * 
	 * @config
	 */
	private static final String PAR_PINGINTERVAL = "pinginterval";

	
	/**
	 * This parameter defines the interval between successive leafset
	 * construction messages.
	 * 
	 * @config
	 */
	private static final String PAR_LEAFSETCONSTRUCTIONINTERVAL = "leafsetconstructioninterval";

//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------

	private final int MAXHOPCOUNT;

	/** {@link #PAR_HEIGHT} */
	private static int height;
	
	/** {@link #PAR_PINGINTERVAL} */
	private static int pingInterval;

	/** {@link #PAR_LEAFSETCONSTRUCTIONINTERVAL} */
	private static int leafsetConstructionInterval;

	private static String prefix;

	private static int collisions = 0;

	protected int pid;

	protected NumericId localNumId;

	protected SkipnetName localname;

	protected Node localnode;

	protected SkipnetRoutingTable routingTable;

	protected Vertex vertex;

	Node seed;

//	--------------------------------------------------------------------------
//	Initialization
//	--------------------------------------------------------------------------

	/**
	 * @param prefix
	 *            string prefix for config properties
	 */
	public Skipnet(String prefix) {
		Skipnet.prefix = prefix;
		Skipnet.height = Configuration.getInt(prefix + "." + PAR_HEIGHT);
		Skipnet.pingInterval = Configuration.getInt(prefix + "."
				+ PAR_PINGINTERVAL);
		Skipnet.leafsetConstructionInterval = Configuration.getInt(prefix + "." + PAR_LEAFSETCONSTRUCTIONINTERVAL);
		MAXHOPCOUNT = 128;
		init();
	}

	private void init() {
		localnode = null;
		routingTable = null;
		localNumId = new NumericId(height);
		localname = new SkipnetName();
	}
	
//	--------------------------------------------------------------------------
//	Methods
//	--------------------------------------------------------------------------
	public void processEvent(Node localnode, int pid, Object event) {
		this.pid = pid;

		// this should be implemented by a transport protocol
		if (localnode.getFailState() == Fallible.DOWN) {
			return;
		}

		if (event instanceof SkipnetMessage) {
			// MESSAGES
			SkipnetMessage msg = (SkipnetMessage) event;
			if (msg.getHopCount() >= MAXHOPCOUNT) {
				msg.maxHopCountReached(this);
				return;
			}
			msg.arrivedAtHop(this);

			// Numeric Routing
			if (event instanceof NumericRoutingMessage)
				routeByNumericID((NumericRoutingMessage) event);
			else if (event instanceof NameRoutingMessage)
				routeByName((NameRoutingMessage) event);
			// Someone has just connected
			else if (event instanceof NeighborInsertionMessage)
				processNeighborInsertion((NeighborInsertionMessage) event);
			// ping from immediate neighbor
			else if (event instanceof Ping)
				processPing((Ping) event);
			// leafset construction
			else if (event instanceof LeafsetConstructionMessage)
				processLeafsetConstructionMessage((LeafsetConstructionMessage) event);
			// There's an error
			if (event instanceof ErrorMessage) {
				dealWithError((ErrorMessage) event);
			}
		} else {
			// INTERNAL EVENTS

			if (event instanceof SkipnetUtil.Events) {
				SkipnetUtil.Events ev = (SkipnetUtil.Events) event;
				if (ev.equals(SkipnetUtil.Events.JOIN))
					this.join(false);
				else if (ev.equals(SkipnetUtil.Events.PINGNEIGHBORS)) {
					this.pingNeighbors();
				} else if (ev.equals(SkipnetUtil.Events.LEAFSETCONSTRUCTION)) {
					this.buildLeafset();
				}
			}
		}

	}


	private void join(boolean regenerate) {
		if (seed != null && !seed.equals(localnode)) {
			if (regenerate) {
				collisions++;
				localNumId.generateAddress();
			}
			JoinRequest request = new JoinRequest(localname, localnode, seed);
			request.destination = localNumId;
			sendMessage(seed, request);
		}
	}

	public void routeByNumericID(NumericRoutingMessage msg) {
		// local node or final destination flag is on
		if (msg.destination.equals(localNumId) || msg.finalDestination) {
			deliver(msg);
			return;
		}

		// the message has circulated the ring
		if (msg.startNode != null
				&& localNumId.equals(SkipnetUtil.getNumericId(msg.startNode, pid))) {
			msg.finalDestination = true;
			this.sendMessage(msg.bestNode, msg);
			return;
		}

		// calculate the next hop
		int h = msg.destination.commonPrefixLen(localNumId);
		if (h > msg.ringLevel) {
			// found a higher level
			msg.ringLevel = h;
			msg.startNode = msg.bestNode = localnode;
		} else if (Math.abs(localNumId.getNumericValue()
				- msg.destination.getNumericValue()) < Math.abs(SkipnetUtil
				.getNumericId(msg.bestNode, pid).getNumericValue()
				- localNumId.getNumericValue())) {
			msg.bestNode = localnode;
		}

		// forward along current ring
		Node nbr = routingTable.getNeighbor(Direction.RIGHT, msg.ringLevel);
		this.sendMessage(nbr, msg);
	}

	public void routeByName(NameRoutingMessage msg) {
		
		if(msg.destination.equals(localname)) {
			deliver(msg);
			return;
		}
		
        //check if the destination is in the leaf set.
        Node nextHop = routingTable.tryRouteOneHop(msg.destination);
        if( nextHop!=null) {
             sendMessage(nextHop, msg);
             return;
        } 
        
        int cmp = msg.destination.compareTo(localname);
        if( cmp<0 ) {
            // Destination is to the left
            nextHop = routeByName(msg.destination, Direction.LEFT);
        } else if( cmp>0 ) {
            // Destination is to the right
            nextHop = routeByName(msg.destination, Direction.RIGHT);
        }
        
        if(localnode.equals(nextHop))
        	deliver(msg);
        else
        	sendMessage(nextHop, msg);
	}

	private Node routeByName(SkipnetName destination, Direction direction) {
		int h = height - 1;
		while (h >= 0) {
			Node nextHop = routingTable.getNeighbor(direction, h);

			if (!nextHop.equals(localnode)
					&& SkipnetName.liesBetween(localname, SkipnetUtil.getSkipnetName(
							nextHop, pid), destination, direction)) {
				return nextHop;
			}
			h--;
		}

		return localnode;
	}

	public void deliver(SkipnetMessage msg) {
		msg.destinationReached(this);
		if (msg instanceof JoinRequest) {
			JoinRequest req = (JoinRequest) msg;
			req.ringLevel = localNumId.commonPrefixLen(req.destination);
			if (req.ringNbrLeft == null && req.ringNbrRight == null) {
				req.ringNbrLeft = new Node[height];
				req.ringNbrRight = new Node[height];
				req.doInsertions = false;
			}

			// the numeric id collides with a node already in the ring
			if (!req.doInsertions && req.ringLevel == height) {
				ErrorMessage error = new ErrorMessage(
						SkipnetUtil.Errors.NUMERIC_ID_ALREADY_EXISTS, localnode,
						req.source);
				sendMessage(req.source, error);
				return;
			}
			collectRingInsertionNeighbors(req);
		}
	}

	private void collectRingInsertionNeighbors(JoinRequest msg) {
		if (msg.doInsertions) {
			routingTable.insertIntoRings(msg.ringNbrLeft, msg.ringNbrRight);
			// schedule neighbor pings
			scheduleEvent(SkipnetUtil.Events.PINGNEIGHBORS, pingInterval);
			// do the leafsetconstruction now
			scheduleEvent(SkipnetUtil.Events.LEAFSETCONSTRUCTION, 0);
			return;
		}

		while (msg.ringLevel >= 0) {
			Node nbr = routingTable.getNeighbor(Direction.RIGHT, msg.ringLevel);
			SkipnetName nbrId = ((Skipnet) nbr.getProtocol(pid)).localname;
			if (SkipnetName.liesBetween(localname, msg.nameid, nbrId,
					Direction.RIGHT)) {
				// found an iinsertion neighbor
				msg.ringNbrRight[msg.ringLevel] = nbr;
				msg.ringNbrLeft[msg.ringLevel] = localnode;
				msg.ringLevel--;
			} else {
				// keep looking
				sendMessage(nbr, msg);
				return;
			}
		}

		msg.doInsertions = true;
		sendMessage(msg.source, msg);
	}

	private void processLeafsetConstructionMessage(
			LeafsetConstructionMessage message) {
		if (message.source.equals(localnode)) {
			//the message has circled the ring or has been sent back
			routingTable.setLeafset(message.direction, message.getLeafset());
			//schedule the next time to rebuild the leafset
			scheduleEvent(SkipnetUtil.Events.LEAFSETCONSTRUCTION, leafsetConstructionInterval);
		} else {
			//sending to next neighbor
			message.addSkipnetNodeToLeafset(localnode);
			Node nextHop = routingTable.getNeighbor(message.direction, 0);
			if (message.isLeafSetFull() || nextHop.equals(localnode)) {
				//if the leafset is complete send it back
				sendMessage(message.source, message);
			} else {
				sendMessage(nextHop, message);
			}
		}

	}

	private void buildLeafset() {
		sendBuildLeafSetMessage(SkipnetUtil.Direction.LEFT);
		sendBuildLeafSetMessage(SkipnetUtil.Direction.RIGHT);
	}

	private void sendBuildLeafSetMessage(Direction direction) {
		// get our immediate neighbor in direction and send a build message to
		// it
		Node nextHop = routingTable.getNeighbor(direction, 0);
		SkipnetMessage msg = new LeafsetConstructionMessage(localnode, nextHop,
				direction);
		sendMessage(msg);
	}

	private void processPing(Ping ping) {
		routingTable.verifyPing(ping);
	}

	private void scheduleEvent(SkipnetUtil.Events event, int time) {
		EDSimulator.add(time, event, localnode, pid);
	}

	private void pingNeighbors() {
		routingTable.pingNeighbors();
		
		// schedule neighbor pings
		scheduleEvent(SkipnetUtil.Events.PINGNEIGHBORS, pingInterval);
	}

	private void dealWithError(ErrorMessage msg) {
		if (msg.error == SkipnetUtil.Errors.NUMERIC_ID_ALREADY_EXISTS) {
			this.join(true);
		}
	}

	private void processNeighborInsertion(NeighborInsertionMessage msg) {
		routingTable.changeRoutingTableElement(SkipnetUtil
				.inverseDirection(msg.direction), msg.level, msg.source);
	}

	public Object clone() {
		return new Skipnet(prefix);
	}

	protected void sendMessage(SkipnetMessage msg) {
		sendMessage(msg.nextHop, msg, pid);
	}

	protected void sendMessage(Node dest, SkipnetMessage msg) {
		sendMessage(dest, msg, pid);
	}

	protected void sendMessage(Node dest, SkipnetMessage msg, int pid) {
		((Transport) localnode.getProtocol(FastConfig.getTransport(pid))).send(
				localnode, dest, msg, pid);
	}

	public Node getSeed() {
		return seed;
	}

	public void setSeed(Node seed) {
		this.seed = seed;
	}

	public void sendData(SkipnetName destination, Object data,
			SkipnetMessageCallback callback) {
		NameRoutingMessage msg = new NameRoutingMessage(localnode, null,
				destination);
		msg.setCallback(callback);

		/*System.out.println("Sending message from " + localname + " " + " to "
				+ msg.destination);*/
		routeByName(msg);
	}

	public void sendData(NumericId destination, Object data, SkipnetMessageCallback callback) {
		NumericRoutingMessage msg = new NumericRoutingMessage(localnode, null);
		msg.destination = destination;
		msg.setCallback(callback);
		
		/*System.out.println("Sending message from " + localNumId + " " + " to "
				+ msg.destination);*/
		routeByNumericID(msg);
	}

	public boolean addNeighbor(Node neighbour) {
		throw new RuntimeException("Skipnet does not allow neighbor adding");
	}

	public boolean contains(Node neighbor) {
		return routingTable.getNeighbors().contains(neighbor);
	}

	public int degree() {
		if (routingTable == null)
			return 0;
		else
			return routingTable.getNeighbors().size();
	}

	public Node getNeighbor(int i) {
		return routingTable.getNeighbors().get(i);
	}

	public void pack() {
		throw new UnsupportedOperationException();
	}

	public void onKill() {
	}

	public NumericId getLocalNumId() {
		return localNumId;
	}

	public SkipnetName getLocalname() {
		return localname;
	}

	public Node getLocalnode() {
		return localnode;
	}

	public SkipnetRoutingTable getRoutingTable() {
		return routingTable;
	}

	public void setLocalnode(Node localnode) {
		this.localnode = localnode;
		this.routingTable = new SkipnetRoutingTable(localnode, height, pid);
	}

	public String toString() {
		return localname.getIdentifier() + " " + localNumId.toString();
	}

	public int getHeight() {
		return height;
	}

}

/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.AggregateObservers;

import peersim.core.*;
import peersim.config.*;
import peersim.vector.*;

/**
 * Serves as an abstract superclass for {@link Control}s that deal
 * with vectors.
 * It reads a {@link Setter} to be used by extending classes.
 */
public abstract class VectControlDouble implements Control {


// --------------------------------------------------------------------------
// Parameter names
// --------------------------------------------------------------------------

/**
 * The protocol to operate on.
 * @config
 */
protected static final String PAR_PROT = "protocol";
protected static final String PAR_STEP = "step";
/**
 * The setter method used to set values in the protocol instances. Defaults to
 * <code>setValue</code>
 * (for backward compatibility with previous implementation of this
 * class, that were based on the {@link SingleValue} interface). Refer to the
 * {@linkplain peersim.vector vector package description} for more
 * information about getters and setters.
 * @config
 */
protected static final String PAR_METHOD1 = "setter1";
protected static final String PAR_METHOD2 = "setter2";
protected static final String PAR_METHOD3 = "setter3";
/**
 * The getter method used to obtain the protocol values. 
 * Defaults to <code>getValue</code>
 * (for backward compatibility with previous 
 * implementation of this class, that were based on the 
 * {@link SingleValue} interface).
 * Refer to the {@linkplain peersim.vector vector package description} for more 
 * information about getters and setters.
 * @config
 */
protected static final String PAR_GETTER1 = "getter1";
protected static final String PAR_GETTER2 = "getter2";
protected static final String PAR_GETTER3 = "getter3";
// --------------------------------------------------------------------------
// Fields
// --------------------------------------------------------------------------

/** The setter to be used to write a vector. */
protected final Setter setter1;
protected final Setter setter2;
protected final Setter setter3;
/** The getter to be used to read a vector. */
protected final Getter getter1;
protected final Getter getter2;
protected final Getter getter3;
protected final int step;
protected final String ProtocolName;
// --------------------------------------------------------------------------
// Initialization
// --------------------------------------------------------------------------

/**
 * Standard constructor that reads the configuration parameters.
 * Invoked by the simulation engine.
 * @param prefix the configuration prefix for this class
 */
protected VectControlDouble(String prefix)
{
	setter1 = new Setter(prefix,PAR_PROT,PAR_METHOD1);
	setter2 = new Setter(prefix,PAR_PROT,PAR_METHOD2);
	setter3 = new Setter(prefix,PAR_PROT,PAR_METHOD3);
	getter1 = new Getter(prefix,PAR_PROT,PAR_GETTER1);
	getter2 = new Getter(prefix,PAR_PROT,PAR_GETTER2);
	getter3 = new Getter(prefix,PAR_PROT,PAR_GETTER3);
	step = Configuration.getInt(prefix + "." + PAR_STEP);
	ProtocolName = Configuration.getString(prefix+"."+PAR_PROT);
}
}


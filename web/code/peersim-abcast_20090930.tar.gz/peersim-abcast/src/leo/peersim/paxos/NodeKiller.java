package leo.peersim.paxos;

import org.apache.log4j.Logger;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Fallible;
import peersim.core.Network;
import peersim.core.Node;

public class NodeKiller implements Control {
	
	private static Logger logger = Logger.getLogger(NodeKiller.class.getName());
	
	private long protocolID;

	public NodeKiller(String prefix) {
		this.protocolID = Configuration.getPid(prefix + "." + "protocol");
	}

	@Override
	public boolean execute() {
		
		//int randomInt = CommonState.r.nextInt( Network.size() );
		int randomInt = 1;
		Node randomVictim = Network.get(randomInt);
		
		logger.info("_\t" + CommonState.getTime() + "\tkilling node[" + randomVictim.getID() + "]");
		randomVictim.setFailState(Fallible.DOWN);
		
		return false;
	}

}

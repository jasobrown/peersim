#!/bin/bash

java -Xmx1800m -ea -cp bin:lib/peersim-1.0.5.jar:lib/jep-2.3.0.jar:lib/djep-1.0.0.jar peersim.Simulator config.txt


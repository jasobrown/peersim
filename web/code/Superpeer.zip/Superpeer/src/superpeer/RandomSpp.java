/*
 * Copyright (c) 2003 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package superpeer;

import newscast.*;
import peersim.cdsim.*;
import peersim.config.*;
import peersim.core.*;
import peersim.util.*;
import peersim.vector.*;

/**
 * @author Alberto Montresor
 * @version $Revision: 1.1 $
 */
public class RandomSpp implements CDProtocol, Superpeer, SingleValue
{

//--------------------------------------------------------------------------
//Constants
//--------------------------------------------------------------------------
/**
 * String name of the parameter
 */
public static final String PAR_SUPERPEER = "reducedID";

/**
 * String name of the parameter
 */
public static final String PAR_ATTEMPTS = "attempts";

/**
 * String name of the parameter
 */
public static final String PAR_RATIO = "ratio";

//--------------------------------------------------------------------------
// Static fields
//--------------------------------------------------------------------------
/**
 *  
 */
private static int sppID;

/**
 *  
 */
private static int maxAttempts;

/**
 *  
 */
private static double ratio;

//--------------------------------------------------------------------------
//Fields
//--------------------------------------------------------------------------
/**
 * Current superpeer (or null if this node is connected to a superpeer)
 */
private Node supernode;

/**
 * Maximum capacity of the node
 */
private int capacity;

/**
 * Current number of clients
 */
private int size;

/**
 * Node clients
 */
private Node[] clients;

//--------------------------------------------------------------------------
// Constructor
//--------------------------------------------------------------------------
/**
 *  
 */
public RandomSpp(String prefix)
{
	sppID = Configuration.getInt(prefix + "." + PAR_SUPERPEER);
	maxAttempts = Configuration.getInt(prefix + "." + PAR_ATTEMPTS, Integer.MAX_VALUE);
	ratio = Configuration.getDouble(prefix + "." + PAR_RATIO, 1);
	supernode = null;
}

/**
 * Just clones the object by calling super's clone() method.
 */
public Object clone() throws CloneNotSupportedException
{
	Superpeer sp = (Superpeer) super.clone();
	return sp;
}

//--------------------------------------------------------------------------
// Methods
//--------------------------------------------------------------------------
public void nextCycle(Node node, int pid)
{
	//if (CommonState.getT() % 1 != 0)
	//	return;
	if (!node.isUp())
		return;
	ReducedNewscast spp = (ReducedNewscast) node.getProtocol(sppID);
	if (supernode == null) {
		doSuperpeer(node, pid, spp);
	} else {
		doClient(node, pid, spp);
	}
	boolean isActive = supernode == null && size < getTarget();
	//boolean isActive = supernode == null;
	spp.setActive(isActive);
}

private static Node[] set;

private void doSuperpeer(Node node, int pid, ReducedNewscast spp)
{
	// Search the neighbors that have larger or equal capacity of this
	// node. We assume that the capacity of a node is transmitted trough
	// reduced newscast.Here, we simply access its capacity value.
	int len = spp.degree();
	if (set == null || set.length < len)
		set = new Node[len];
	int pos = 0;
	for (int i = 0; i < len; i++) {
		set[pos] = spp.getNeighbor(i);
		RandomSpp rpeer = (RandomSpp) set[pos].getProtocol(pid);
		if (rpeer.capacity >= capacity)
			pos++;
	}
	len = pos;
	// Search a node from which to steal clients.
	int max = maxAttempts;
	boolean found = false;
	while (!found && len > 0 && max > 0) {
		max--;
		int r = CommonRandom.r.nextInt(len);
		Node rnode = set[r];
		RandomSpp rpeer = null;
		SuperpeerObserver.addReqSent(node.getIndex());
		if (rnode.isUp()) {
			rpeer = (RandomSpp) rnode.getProtocol(pid);
			SuperpeerObserver.addReqRcvd(rnode.getIndex());
			if (capacity < rpeer.capacity && rpeer.size < rpeer.getTarget()) {
				doTransfer(rnode, node, rpeer, this, pid);
				found = true;
			} else {
				if (size <= rpeer.size && rpeer.size < rpeer.getTarget()) {
					doTransfer(rnode, node, rpeer, this, pid);
					found = true;
				}
			}
		}
		// Remove the node from the list of nodes to be visited
		len--;
		set[r] = set[len];
		// Removes the node from the superpeer set, if it is ok
		// with the current value.
		if (rpeer == null || !rpeer.isSuperpeer() || rpeer.size >= rpeer.getTarget() || !rnode.isUp()) {
			spp.removeNeighbor(rnode);
		}
	}
	// Clean dead clients
	int i = 0;
	while (i < size) {
		if (!clients[i].isUp()) {
			size--;
			clients[i] = clients[size];
		} else {
			i++;
		}
	}
	/*
	 * if (size > 0) { ReducedNewscast cpeer = (ReducedNewscast)
	 * clients[CommonRandom.r.nextInt(size)].getProtocol(sppID);
	 * cpeer.copyFrom(spp); }
	 */
}

private void doClient(Node node, int pid, ReducedNewscast spp)
{
	// If down, do nothing
	if (!node.isUp())
		return;
	/*
	 * // We check whether there is a superpeer with smaller capacity // than
	 * this node int minCapacity = Integer.MAX_VALUE; RandomSpp minPeer = null;
	 * Node minNode = null; for (int i=0; i < spp.degree(); i++) { RandomSpp p =
	 * (RandomSpp) spp.getNeighbor(i).getProtocol(pid); if (p.capacity >
	 * minCapacity) { minCapacity = p.capacity; minPeer = p; minNode =
	 * spp.getNeighbor(i); } }
	 *  // If found, and if it is active and actually a superpeer, the // client
	 * steal all its clients and becomes a superpeer. if (capacity > minCapacity) {
	 * SppObserver.addReqSent(node.getIndex()); if (minNode.isUp()) {
	 * SppObserver.addReqRcvd(minNode.getIndex()); if (minPeer.isSuperpeer()) {
	 *  // Update clients clients = new Node[capacity]; if (minPeer.size > 0)
	 * System.arraycopy(minPeer.clients, 0, clients, 0, minPeer.size);
	 * minPeer.clients = null; size = minPeer.size; minPeer.size = 0;
	 *  // Update supernode minPeer.supernode = supernode; supernode = null;
	 *  // Substitute the client in the correct position RandomSpp superpeer =
	 * (RandomSpp) minPeer.supernode.getProtocol(pid); int i; for (i=0; i <
	 * superpeer.size; i++) { if (superpeer.clients[i] == node) {
	 * superpeer.clients[i] = minNode; break; } } if (i == superpeer.size)
	 * System.out.println("+" + size); return; } } }
	 */
	// If the superpeer is ok, stop
	if (supernode.isUp())
		return;
	// Create a neighbor set
	int len = spp.degree();
	if (set == null || set.length < len)
		set = new Node[len];
	int pos = 0;
	for (int i = 0; i < len; i++) {
		set[pos] = spp.getNeighbor(i);
	}
	boolean found = false;
	int max = 0;
	while (!found && len > 0 && max > 0) {
		max--;
		Node rnode = set[CommonRandom.r.nextInt(len)];
		SuperpeerObserver.addReqSent(node.getIndex());
		if (rnode.isUp()) {
			SuperpeerObserver.addReqRcvd(rnode.getIndex());
			RandomSpp rpeer = (RandomSpp) rnode.getProtocol(pid);
			if (rpeer.isSuperpeer() && rpeer.size < rpeer.capacity) {
				// Becomes a client of this superpeer
				rpeer.addClient(rnode, node, pid);
				found = true;
			}
		}
	}
	if (!found) {
		spp.reset(node);
		supernode = null;
		becomeSuperpeer(node, pid);
	}
}

private static void doTransfer(Node nlarge, Node nsmall, RandomSpp large, RandomSpp small, int pid)
{
	large.becomeSuperpeer(nlarge, pid);
	// Stores the old size to optimize search of the maximum; see later.
	int oldsize = large.size;
	// Transfers all nodes from small that can be contained in large
	while (large.size < large.getTarget() && small.size > 0) {
		SuperpeerObserver.addMovement(nlarge.getIndex());
		SuperpeerObserver.addMovement(nsmall.getIndex());
		Node client = small.removeClient();
		large.addClient(nlarge, client, pid);
		//System.out.println("Node " + client.getIndex() + " added to " +
		// nlarge.getIndex());
	}
	// If small is empty and there is still space, small becomes client
	if (small.size == 0 && large.size < large.getTarget()) {
		if (small.supernode == null) {
			large.addClient(nlarge, nsmall, pid);
			//System.out.println("Node " + nsmall.getIndex() + " becomes client;
			// added to " + nlarge.getIndex());
			return;
		}
	}
	// We check whether there exists a client that has a larger capacity
	// than the capacity of small
	int max = small.capacity;
	int imax = -1;
	for (int i = 0; i < oldsize; i++) {
		if (large.clients[i].isUp()) {
			RandomSpp c = (RandomSpp) large.clients[i].getProtocol(pid);
			if (c.capacity > max) {
				max = c.capacity;
				imax = i;
			}
		}
	}
	if (imax >= 0) {
		// Found a client with larger capacity
		// It becomes a new superpeer
		Node newnode = large.clients[imax];
		RandomSpp newpeer = (RandomSpp) newnode.getProtocol(pid);
		newpeer.becomeSuperpeer(newnode, pid);
		SuperpeerObserver.addReqSent(nlarge.getIndex());
		SuperpeerObserver.addReqRcvd(newnode.getIndex());
		while (small.size > 0) {
			SuperpeerObserver.addMovement(newnode.getIndex());
			SuperpeerObserver.addMovement(nsmall.getIndex());
			Node client = small.removeClient();
			newpeer.addClient(newnode, client, pid);
		}
		large.addClient(nlarge, nsmall, pid);
	}
}

private void becomeSuperpeer(Node node, int pid)
{
	if (supernode != null) {
		// Large should become a superpeer
		RandomSpp oldsp = (RandomSpp) supernode.getProtocol(pid);
		oldsp.removeClient(node);
		supernode = null;
		size = 0;
	}
}

private boolean addClient(Node lnode, Node client, int pid)
{
	if (client.isUp()) {
		if (clients == null)
			clients = new Node[capacity];
		clients[size] = client;
		size++;
		RandomSpp peer = (RandomSpp) client.getProtocol(pid);
		if (peer.size > 0)
			throw new RuntimeException();
		/*
		 * if (peer.superpeer != null) { RandomSpp oldsp = (RandomSpp)
		 * peer.superpeer.getProtocol(pid); oldsp.removeClient(client); }
		 */
		peer.supernode = lnode;
		peer.clients = null;
		peer.size = 0;
		return true;
	}
	return false;
}

private Node removeClient()
{
	size--;
	Node temp = clients[size];
	clients[size] = null;
	return temp;
}

private void removeClient(Node node)
{
	for (int i = 0; i < size; i++) {
		if (clients[i] == node) {
			size--;
			clients[i] = clients[size];
			return;
		}
	}
	System.out.println("not found!!!!!");
}

public boolean isSuperpeer()
{
	return supernode == null;
}

public Node getSuperpeer()
{
	return supernode;
}

public Node getClient(int j)
{
	return clients[j];
}

public int degree()
{
	return size;
}

public void setValue(double capacity)
{
	this.capacity = (int) capacity;
}

public double getValue()
{
	return capacity;
}

public void setCapacity(int capacity)
{
	this.capacity = capacity;
}

public int getCapacity()
{
	return capacity;
}

public int getTarget()
{
	return (int) (ratio * capacity);
}

public double ratio()
{
	return ((double) size) / capacity;
}
}
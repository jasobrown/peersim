package xtremlab;

/**
 * An object representing one host entry in an XtremLab trace file.
 * More on XtremLab traces can be found here:
 * http://xtremlab.lri.fr/traces/
 * 
 * @author Jan Sacha
 *
 */
public class XtremLabHost {
	
	public int an;
	public int nresults;
	public long minTime;
	public long maxTime;
	public int rpc_seqno;
	public long rpc_time;
	public int timezone;
	public int nsame_ip_addr;
	public float on_frac;
	public float connected_frac;
	public float active_frac;
	public float cpu_efficiency;
	public float duration_correction_factor;
	public int ncpus;
	public String p_vendor;
	public String p_model;
	public double p_fpops;
	public double p_iops;
	public double p_membw;
	public String os_name;
	public String os_version;
	public long m_nbytes;
	public long m_cache;
	public long m_swap;
	public long d_total;
	public long d_free;
	public long d_boinc_used_total;
	public long d_boinc_used_project;
	public long d_boinc_max;
	public double n_bwup;
	public double n_bwdown;
	public double credit_per_cpu_sec;
	public String venue;
	public boolean ip_addr_nat;

	
	public String toString() {
		return "\"" + an + 
			"\", \"" + nresults + 
			"\", \"" + minTime + 
			"\", \"" + maxTime + 
			"\", \"" + rpc_seqno + 
			"\", \"" + rpc_time + 
			"\", \"" + timezone + 
			"\", \"" + nsame_ip_addr + 
			"\", \"" + on_frac + 
			"\", \"" + connected_frac + 
			"\", \"" + active_frac + 
			"\", \"" + cpu_efficiency + 
			"\", \"" + duration_correction_factor +	
			"\", \"" + ncpus + 
			"\", \"" + p_vendor + 
			"\", \"" + p_model + 
			"\", \"" + p_fpops + 
			"\", \"" + p_iops + 
			"\", \"" + p_membw + 
			"\", \"" + os_name + 
			"\", \"" + os_version + 
			"\", \"" + m_nbytes + 
			"\", \"" + m_cache + 
			"\", \"" + m_swap + 
			"\", \"" + d_total + 
			"\", \"" + d_free + 
			"\", \"" + d_boinc_used_total + 
			"\", \"" + d_boinc_used_project + 
			"\", \"" + d_boinc_max + 
			"\", \"" + n_bwup + 
			"\", \"" + n_bwdown + 
			"\", \"" + credit_per_cpu_sec + 
			"\", \"" + venue + 
			"\", \"" + (ip_addr_nat ? "yes" : "no") + 
			"\"";
	}
	
	public double[] getNumericDimensions() {
		double[] dims = new double[28];
		int i = 0;
		dims[i++] = an;
		dims[i++] = nresults;
		dims[i++] = minTime;
		dims[i++] = maxTime;
		dims[i++] = rpc_seqno;
		dims[i++] = rpc_time;
		dims[i++] = timezone;
		dims[i++] = nsame_ip_addr;
		dims[i++] = on_frac;
		dims[i++] = connected_frac;
		dims[i++] = active_frac;
		dims[i++] = cpu_efficiency;
		dims[i++] = duration_correction_factor;
		dims[i++] = ncpus;
		dims[i++] = p_fpops;
		dims[i++] = p_iops;
		dims[i++] = p_membw;
		dims[i++] = m_nbytes;
		dims[i++] = m_cache;
		dims[i++] = m_swap;
		dims[i++] = d_total;
		dims[i++] = d_free;
		dims[i++] = d_boinc_used_total;
		dims[i++] = d_boinc_used_project;
		dims[i++] = d_boinc_max;
		dims[i++] = n_bwup;
		dims[i++] = n_bwdown;
		dims[i++] = credit_per_cpu_sec;
		return dims;
	}
}

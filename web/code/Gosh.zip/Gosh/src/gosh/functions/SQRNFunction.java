/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.config.*;

// d=4 opt.=? REQUIRE CONF PARAM (int) 'ord'
public class SQRNFunction extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;

private static final String PAR_ORD = "ord";

private int order;

private double[][] szego_table_a;

private double[] szego_table_c;

public SQRNFunction(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);
        
        order = Configuration.getInt(prefix + "." + PAR_ORD);
        if ((order!=7)&&(order!=10)) order=5;
        szego_table_a=createTableA();
        szego_table_c=createTableC();
        
        rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = 0.0;
    rangeMax[i] = 10.0;
  }	
}

public double eval(double[] x)
{
  double Result = 0.0;
  double w;
  int i, j;

  for (i = 0; i < order; ++i)
  {
    w = 0.0;
    for (j = 0; j < 4; ++j)
       w += StrictMath.pow(x[j]-szego_table_a[i][j],2);
    Result -= 1.0/(w + szego_table_c[i]);
  }
//  System.out.print(CommonState.getTime() + ": f(" + x[0]);
//  for (int i=1; i < d; i++) {
//  	System.out.print(", " + x[i]);
//  }
//  System.out.println(") = " + Result);
  return Result;
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;
	
}

private double[][] createTableA()
{
 double[][] a= //[10][4]
 {
          {4.0, 4.0, 4.0, 4.0},
          {1.0, 1.0, 1.0, 1.0},
          {8.0, 8.0, 8.0, 8.0},
          {6.0, 6.0, 6.0, 6.0},
          {3.0, 7.0, 3.0, 7.0},
          {2.0, 9.0, 2.0, 9.0},
          {5.0, 5.0, 3.0, 3.0},
          {8.0, 1.0, 8.0, 1.0},
          {6.0, 2.0, 6.0, 2.0},
          {7.0, 3.6, 7.0, 3.6}
 };
 return a;
};

private double[] createTableC()
{
 double[] c=  //[10] 
 {
          0.1, 0.2, 0.2, 0.4, 0.4, 0.6, 0.3, 0.7, 0.5, 0.5
 };
 return c;
}

}

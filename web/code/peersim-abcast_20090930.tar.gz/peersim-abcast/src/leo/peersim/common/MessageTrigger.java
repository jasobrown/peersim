package leo.peersim.common;

import java.util.LinkedList;


import org.apache.log4j.Logger;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.edsim.EDSimulator;

public class MessageTrigger implements Control {
	
	private Logger logger = Logger.getLogger(this.getClass().getName());
	
	private final int protocolID;
	
	private LinkedList<String> messageQueue = null;
	
	public MessageTrigger(String prefix) {
		this.protocolID = Configuration.getPid(prefix + "." + "protocol");
		
		this.messageQueue = new LinkedList<String>();
		this.messageQueue.offer("A");
		this.messageQueue.offer("B");
		this.messageQueue.offer("C");
		
	}

	/**
	 * 
	 * 
	 */
	@Override
	public boolean execute() {
		String command = this.messageQueue.poll();
		
		if (command==null) {
			return false;
		}
		
		int randomInt = CommonState.r.nextInt( Network.size() ); 
		Node randomLeader = Network.get(randomInt);
		
		logger.debug(CommonState.getTime() + "\ttriggering request _" + command + "_ to agent[" + randomLeader.getID() + "]...");
		
		FSMOperationRequest request = new FSMOperationRequest("pippo", command);
		
		EDSimulator.add(0, request, randomLeader, this.protocolID);
		
		return false;
	}
}


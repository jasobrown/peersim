package peersim.skipnet;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Hashtable;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JSlider;

import org.apache.commons.collections.Predicate;

import edu.uci.ics.jung.graph.Edge;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.Vertex;
import edu.uci.ics.jung.graph.decorators.StringLabeller;
import edu.uci.ics.jung.graph.decorators.StringLabeller.UniqueLabelException;
import edu.uci.ics.jung.graph.impl.DirectedSparseEdge;
import edu.uci.ics.jung.graph.impl.DirectedSparseVertex;
import edu.uci.ics.jung.graph.impl.SparseGraph;
import edu.uci.ics.jung.statistics.GraphStatistics;
import edu.uci.ics.jung.utils.UserData;
import edu.uci.ics.jung.utils.UserDataContainer;
import edu.uci.ics.jung.visualization.Layout;
import edu.uci.ics.jung.visualization.PluggableRenderer;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.contrib.CircleLayout;
import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.skipnet.SkipnetUtil.*;

public class SkipnetObserver implements Control {

//	--------------------------------------------------------------------------
//	Parameters
//	--------------------------------------------------------------------------
	
	/**
	 * The protocol to operate on.
	 * 
	 * @config
	 */
	private static final String PAR_PROT = "protocol";

	/**
	 * If present, displays a window containing the graph visualization
	 * 
	 * @config
	 */
	private static final String PAR_WINDOW = "window";

	/**
	 * If present, the gui doesn't display node labels
	 * 
	 * @config
	 */
	private static final String PAR_NOLABELS = "nolabels";

	
//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------

	/** {@link #PAR_WINDOW} */
	private final boolean window;

	/** {@link #PAR_NOLABELS} */
	private final boolean nolabels;

	/** Protocol identifier; obtained from config property {@link #PAR_PROT}. */
	private final int pid;

	/** Stores the graph used by JUNG. */
	private Graph graph;

	private StringLabeller labeller;

//	--------------------------------------------------------------------------
//	Initialization
//	--------------------------------------------------------------------------

	/**
	 * Creates a new observer reading configuration parameters.
	 */
	public SkipnetObserver(String name) {
		pid = Configuration.getPid(name + "." + PAR_PROT);
		int height = SkipnetUtil.getSkipnetProtocol(Network.get(0), pid)
				.getHeight();
		window = Configuration.contains(name + "." + PAR_WINDOW);
		nolabels = window ? Configuration.contains(name + "." + PAR_NOLABELS)
				: false;

		graph = new SparseGraph();
		labeller = StringLabeller.getLabeller(graph);

		for (int i = 0; i < Network.size(); i++) {
			Skipnet skipnet = SkipnetUtil.getSkipnetProtocol(Network.get(i),
					pid);
			skipnet.vertex = (Vertex) graph
					.addVertex(new DirectedSparseVertex());
			label(skipnet);
		}

		if (window)
			new GraphFrame(graph, height);
	}

	
//	--------------------------------------------------------------------------
//	Methods
//	--------------------------------------------------------------------------
	
	private void label(Skipnet skipnet) {
		try {
			if (!nolabels) {
				String label = skipnet.getLocalname().getIdentifier() + " / "
						+ skipnet.getLocalNumId().toString();
				if (label != null
						&& !label.equals(labeller.getLabel(skipnet.vertex))) {
					labeller.removeLabel(labeller.getLabel(skipnet.vertex));
					labeller.setLabel(skipnet.vertex, label);
				}
			}

		} catch (UniqueLabelException e) {
			e.printStackTrace();
		}
	}

	/** Calculates the graph diameter and refreshes the window.*/
	public boolean execute() {
		for (int i = 0; i < Network.size(); i++) {
			Skipnet skipnet = SkipnetUtil.getSkipnetProtocol(Network.get(i),
					pid);

			label(skipnet);
			removeEdges(skipnet);

			createEdges(skipnet, skipnet.getRoutingTable().getNeighbors(
					Direction.LEFT));
			createEdges(skipnet, skipnet.getRoutingTable().getNeighbors(
					Direction.RIGHT));

		}

		double diameter = GraphStatistics.diameter(graph);
		System.out.println("Diameter: " + diameter);
		return false;
	}

	private void createEdges(Skipnet skipnet, Node[] cnodes) {
		// Node node = peersim.extras.am.skipnet.getLocalnode();

		for (int j = 0; j < cnodes.length; j++) {
			Edge edge = new DirectedSparseEdge(skipnet.vertex, SkipnetUtil
					.getSkipnetProtocol(cnodes[j], pid).vertex);
			edge.setUserDatum("level", "l" + j, UserData.REMOVE);
			graph.addEdge(edge);
		}

	}

	private void removeEdges(Skipnet skipnet) {
		Iterator outEdges = (Iterator) (skipnet.vertex.getOutEdges())
				.iterator();
		while (outEdges.hasNext()) {
			graph.removeEdge((Edge) outEdges.next());
		}
	}

	private final static class LevelDisplayPredicate implements Predicate {
		protected int level;

		protected String levelstring;

		protected boolean enabled;

		public LevelDisplayPredicate(int level, boolean enabled) {
			this.enabled = enabled;
			setLevel(level);
		}

		public boolean evaluate(Object arg0) {
			if (!enabled)
				return true;

			if (arg0 instanceof UserDataContainer) {
				UserDataContainer container = (UserDataContainer) arg0;
				if (container.containsUserDatumKey("level"))
					if (container.getUserDatum("level").equals(levelstring))
						return true;
			}

			return false;
		}

		public int getLevel() {
			return level;
		}

		public void setLevel(int level) {
			this.level = level;
			this.levelstring = "l" + level;
		}

		public boolean isEnabled() {
			return enabled;
		}

		public void setEnabled(boolean enabled) {
			this.enabled = enabled;
		}
	}

	public class GraphFrame extends JFrame implements ActionListener {

		private AbstractAction saveAction;

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		private JCheckBox v_level;

		private LevelDisplayPredicate ldp;

		private VisualizationViewer vv;

		private int height;

		private JSlider slider;

		public GraphFrame(Graph graph, int height) {
			this.height = height;

			generateMenus();

			Layout l = new CircleLayout(graph);
			PluggableRenderer r = new PluggableRenderer();
			r.setVertexStringer(labeller);
			ldp = new LevelDisplayPredicate(0, false);
			r.setEdgeIncludePredicate(ldp);

			vv = new VisualizationViewer(l, r);
			JPanel jp = new JPanel();
			jp.setLayout(new BorderLayout());
			jp.add(vv);

			addBottomControls(jp);

			this.getContentPane().add(jp);
			this.setSize(1024, 728);
			this.setVisible(true);

			setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		}

		private void generateMenus() {
			saveAction = new AbstractAction("Save image...", null) {
				/**
				 * 
				 */
				private static final long serialVersionUID = 313445533111695700L;

				public void actionPerformed(ActionEvent e) {
					saveImage();
				}
			};

			JMenu menu = new JMenu();
			menu.setText("File");
			menu.setMnemonic('F');
			menu.add(saveAction);

			JMenuBar menubar = new JMenuBar();
			menubar.add(menu);
			setJMenuBar(menubar);
		}

		public void saveImage() {
			try {
				JFileChooser chooser = new JFileChooser();
				chooser.setDialogType(JFileChooser.SAVE_DIALOG);
				int returnVal = chooser.showSaveDialog(this);
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					saveImage(chooser.getSelectedFile());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		private void saveImage(File selectedFile) {
			int width = vv.getBounds().width;
			int height = vv.getBounds().height;
			Color bg = getBackground();

			BufferedImage bi = new BufferedImage(width, height,
					BufferedImage.TYPE_INT_BGR);
			Graphics2D graphics = bi.createGraphics();
			graphics.setColor(bg);
			graphics.fillRect(0, 0, width, height);
			vv.paint(graphics);

			try {
				ImageIO.write(bi, "jpeg", selectedFile);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		protected void addBottomControls(JPanel jp) {
			final JPanel control_panel = new JPanel();
			jp.add(control_panel, BorderLayout.SOUTH);
			control_panel.setLayout(new BorderLayout());
			final Box level_panel = Box.createHorizontalBox();
			level_panel.setBorder(BorderFactory
					.createTitledBorder("Ring edges"));

			control_panel.add(level_panel, BorderLayout.CENTER);

			v_level = new JCheckBox("Show level");
			v_level.addActionListener(this);

			slider = new JSlider(0, height - 1, 0);
			slider.setEnabled(v_level.isSelected());
			slider.setSnapToTicks(true);
			slider.addChangeListener(new javax.swing.event.ChangeListener() {
				public void stateChanged(javax.swing.event.ChangeEvent evt) {
					sliderChange();
				}
			});

			Hashtable<Integer, JLabel> labels = new Hashtable<Integer, JLabel>();
			for (int i = 0; i < height; i++) {
				labels.put(i, new JLabel(new Integer(i).toString()));
			}
			slider.setLabelTable(labels);
			slider.setPaintLabels(true);
			level_panel.add(v_level);
			level_panel.add(slider);

		}

		private void sliderChange() {
			ldp.setLevel(slider.getValue());
			vv.repaint();
		}

		public void actionPerformed(ActionEvent e) {
			AbstractButton source = (AbstractButton) e.getSource();
			if (source == v_level) {
				ldp.setEnabled(v_level.isSelected());
				slider.setEnabled(v_level.isSelected());
			}

			vv.repaint();
		}

	}
}

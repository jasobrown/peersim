package adam2;

/**
 * Interface for interpolation functions.
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public interface Interpolation {

	/*
	 * Get function value for a given argument x.
	 */
	public double interpolate(double x);
	
}

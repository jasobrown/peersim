/*
 * Copyright (c) 2014 project project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.CommonForGAPs;

import java.util.HashMap;
import peersim.config.*;
import peersim.core.*;
import lehurament.gap.*;


public class GAPTableInitializer implements Control {

    // ------------------------------------------------------------------------
    // Constants
    // ------------------------------------------------------------------------

	private static final String PAR_PROT = "protocol";
    // ------------------------------------------------------------------------
    // Fields
    // ------------------------------------------------------------------------

    /** Protocol identifier; obtained from config property {@link #PAR_PROT}. */
	private final int pid;
	private HashMap<Long, row> table;//the neighbor table
	private row r=new row();
	

    // ------------------------------------------------------------------------
    // Constructor
    // ------------------------------------------------------------------------

    /**
     * Creates a new instance and read parameters from the config file.
     */
	public GAPTableInitializer(String prefix) {
	pid = Configuration.getPid(prefix + "." + PAR_PROT);
	}

    // ------------------------------------------------------------------------
    // Methods
    // ------------------------------------------------------------------------
	
 	void newInitEntry(long id) {
		row r=new row();
		r.aggregate=0;
		r.level=-1;
		r.role=	r.role.SELF;
		r.nodePacketCount=0;
		table.put(id, r);
	}
	public boolean execute() {
        for (int i = 0; i < Network.size(); i++) {
	 		table=new HashMap<Long, row>();
	 		GAP prot = (GAP) Network.get(i).getProtocol(pid);
	 		newInitEntry(Network.get(i).getID());
	 		if (i==0) {
	 			r=new row();
	 			r.nodePacketCount=0;			
	 			r.aggregate=0;
	 			r.level=0;
	 			r.role=r.role.PARENT;
	 			long id = -2;
	 			table.put(id, r); //this virtual parent has an id of -2
	 		}
	 		prot.setTable(table);
			prot.setValue(0);
			prot.vector.from=Network.get(i).getID();
			prot.setVector(prot.updateVector(Network.get(i).getID()));
			prot.newVector=prot.vector;
			GAPPacket p=new GAPPacket();
			p.type=p.type.NEW;
			p.from=Network.get(i).getID();
			p.nodeFrom=Network.get(i);
			prot.broadcastPacket(Network.get(i), pid, p);
		}
        return false;
    }
}

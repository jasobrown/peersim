package xtremlab;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.ParseException;


/**
 * A tool for copying XtremLab trace files. 
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class Copy {

	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("Usage: java Copy <trace-file> <out-file>");
			return;
		}
		
		try {
			String traceFile = args[0];
			XtremLabParser parser = new XtremLabParser(traceFile); 
			
			String outFile = args[1];
			OutputStream outStream = new FileOutputStream(outFile);
			OutputStreamWriter writer = new OutputStreamWriter(outStream);

			System.out.println("Parsing...");
			int parsed = 0;
			for (;;) {
				XtremLabHost host = parser.readHost(); 	
				
				if (host == null) {
					// End of trace
					writer.close();
					parser.close();
					break;
				}
				else {
					parsed++;
					writer.write(host.toString());
					writer.write("\n");
					if (parsed % 1000 == 0) {
						System.out.print("*");
					}
				}
			}
			System.out.println();
			System.out.println("Copied " + parsed + " host entries");
		} 
		catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
		}
		catch (ParseException e) {
			System.out.println("Parse error: " + e.getMessage() + ", line " + e.getErrorOffset());
		} 
		catch (IOException e) {
			System.out.println("I/O error: " + e.getMessage());
		}
	}

}

/*
 * Copyright (c) 2003 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

package superpeer;

import peersim.config.*;
import peersim.core.*;
import peersim.vector.*;
import peersim.dynamics.*;
import cern.jet.random.*;

/**
 * 
 *
 * @author Alberto Montresor
 * @version $Revision: 1.1 $
 */
public class PowerlawDistribution 
implements Dynamics, NodeInitializer
{

	////////////////////////////////////////////////////////////////////////////
	// Static elements
	////////////////////////////////////////////////////////////////////////////

  private static CommonRandomElement rnd = new CommonRandomElement();

	////////////////////////////////////////////////////////////////////////////
	// Constants
	////////////////////////////////////////////////////////////////////////////

	/** 
	 *  String name of the parameter used to select the protocol to be 
	 *  initialized
	 */
	public static final String PAR_PROTOCOL = "protocol";

	/** 
	 *  String name of the parameter used to 
	 */
	public static final String PAR_MAXCAPACITY = "max";

	/** 
	 *  String name of the parameter used to 
	 */
	public static final String PAR_MINCAPACITY = "min";

	/** 
	 *  String name of the parameter used to 
	 */
	public static final String PAR_ALPHA = "alpha";


	////////////////////////////////////////////////////////////////////////////
	// Fields
	////////////////////////////////////////////////////////////////////////////

	/**
	 * The protocol we want to wire
	 */
	private int pid;
	

	/** 
	 * Min capacity (i.e., number of subpeers managed) to be considered
	 * a potential superpeer.
	 */
  private int minCapacity;

	/** 
	 * Max capacity (i.e., number of subpeers managed) to be considered
	 * a potential superpeer.
	 */
	private int maxCapacity;

  /**
   * Alpha parameter for the power law distribution used to initialize
   * the capacity parameter of superpeers.
   */
	private double alpha;

  
 
 
	////////////////////////////////////////////////////////////////////////////
	// Constructor
	////////////////////////////////////////////////////////////////////////////

  public PowerlawDistribution(String prefix)
  {
  	pid = Configuration.getPid(prefix + "." + PAR_PROTOCOL);
  	minCapacity = Configuration.getInt(prefix + "." + PAR_MINCAPACITY);
		maxCapacity = Configuration.getInt(prefix + "." + PAR_MAXCAPACITY);
  	alpha = Configuration.getDouble(prefix + "." + PAR_ALPHA);
  }

	////////////////////////////////////////////////////////////////////////////
	// Methods
	////////////////////////////////////////////////////////////////////////////

	// Comment inherited from interface
	public void initialize(Node node)
	{
		SingleValue peer = (SingleValue) node.getProtocol(pid);
		peer.setValue(generateCapacity(minCapacity, maxCapacity, alpha));
	}

	// Comment inherited from interface
	public void initialize()
	{
		modify();
	}
	
	// Comment inherited from interface
	public void modify()
	{
		
		int size = Network.size();
		// First, we decide the capacity of the initialization objects
		for (int i=0; i < size; i++) {
			Node node = Network.get(i);
			SingleValue peer = (SingleValue) node.getProtocol(pid);
			peer.setValue(generateCapacity(minCapacity, maxCapacity, alpha));
		}
	}
	
  private static int generateCapacity(int minCapacity, int maxCapacity, double alpha)
	{
  	int capacity;
  	do {
			capacity = 
				(int) (Distributions.nextPowLaw(-alpha, 1, rnd));
  	} while (capacity > maxCapacity || capacity < minCapacity);
  	return capacity;
	}
  
  
  public static void main(String[] args)
	{
  	int size = Integer.parseInt(args[0]);
  	int minCapacity = Integer.parseInt(args[1]);
  	int maxCapacity = Integer.parseInt(args[2]);
  	double alpha = Double.parseDouble(args[3]);
  	int[] dist = new int[maxCapacity+1];
  	
  	for (int i=0; i < size; i++) {
  		int cap = generateCapacity(minCapacity, maxCapacity, alpha);
  		dist[cap]++;
  	}
  	for (int i=minCapacity+1; i <= maxCapacity; i++) 
  		dist[i] = dist[i] + dist[i-1];
  	
  	for (int i=minCapacity; i <= maxCapacity; i++)
  		System.out.println(i + " " + dist[i]);
  		
	}
  
}

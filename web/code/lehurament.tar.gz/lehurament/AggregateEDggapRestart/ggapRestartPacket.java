/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.AggregateEDggapRestart;

import peersim.core.Node;

public class ggapRestartPacket extends Packet {
	public double weight;
	public double value;
	public Node from;
	public int epochFreqCount;
	public int restart;
	public int epochID;
	public static enum types {NEW, NEWSYNC, FAIL, UPDATE, UPDATELOCAL};
	public types type;	
	public ggapRestartPacket() {
		type=types.UPDATE;
		from=null;
		value=weight=0;
		restart=epochFreqCount=epochID=0;
	}
	public ggapRestartPacket(double valueIn, double weightIn, int epochIDIn, Node fromIn) {
		type=types.UPDATE;
		from=fromIn;
		value=valueIn;
		weight=weightIn;
		epochID=epochIDIn;
	}
	boolean equals(ggapRestartPacket p) {
		return (p.value==value && p.weight==weight);
	}
}

abstract class Packet {
	/**
	 * sorce of packet.
	 */
//	int from;
	/**
	 * destination of packet.
	 */
//	int to;
/**
 * set both to -1, the broadcast address
 *
 */
	Packet() {
//		to = from = -1;
	}
}

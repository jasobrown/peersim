package peersim.skipnet.reports;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.skipnet.messages.*;

public class SkipnetTransmitTrigger implements Control, SkipnetMessageCallback {

	//	 ===================== fields =======================================
	//	 ====================================================================

	/**
	 * The protocol to operate on.
	 * @config
	 */
	private static final String PAR_PROT = "protocol";

	/**
	 * The number of messages to emit.
	 * @config
	 */
	private static final String PAR_MESSAGES = "messages";

	private static final String PAR_NUMERICROUTINGENABLED = "numericroutingenabled";

	protected final int pid;

	protected final boolean numericroutingenabled;

	private final int messages;

	private int messagesent;

	private int unsuccesfulLookups;

	private int succesfulLookupsHopCount;

	private int succesfulLookupsHopCountSQ;

	private int unsuccesfulLookupsHopCount;

	private int unsuccesfulLookupsHopCountSQ;

	private int minHopCount;

	private int maxHopCount;

	public SkipnetTransmitTrigger(String n) {
		pid = Configuration.getPid(n + "." + PAR_PROT);
		messages = Configuration.getInt(n + "." + PAR_MESSAGES);

		numericroutingenabled = Configuration.contains(n + "."
				+ PAR_NUMERICROUTINGENABLED);
	}

	public boolean execute() {
		resetCounters();
		System.err.println("Sending messages... " + messages);
		sendMessage();
		// the next message will be emitted when this message reaches its
		// destination
		// when the destination is reached the callback method is called

		return false;
	}

	private void sendMessage() {
		int originindex = CommonState.r.nextInt(Network.size());
		int destinationindex = CommonState.r.nextInt(Network.size());
		if(originindex == destinationindex)
			destinationindex = CommonState.r.nextInt(Network.size());
		
		Node origin = Network.get(originindex);
		Node destination = Network.get(destinationindex);
		// Node destination = peersim.extras.am.skipnet.Util.getSkipnetProtocol(origin,
		// pid).getRoutingTable().getNeighbor(peersim.extras.am.skipnet.Util.Direction.LEFT, 0);

		if (numericroutingenabled) {
			peersim.skipnet.SkipnetUtil.getSkipnetProtocol(origin, pid).sendData(
					peersim.skipnet.SkipnetUtil.getSkipnetProtocol(destination, pid)
							.getLocalNumId(), null, this);
		} else {
			peersim.skipnet.SkipnetUtil.getSkipnetProtocol(origin, pid).sendData(
					peersim.skipnet.SkipnetUtil.getSkipnetProtocol(destination, pid)
							.getLocalname(), null, this);
		}

		messagesent++;
	}

	private void resetCounters() {
		messagesent = 0;
		unsuccesfulLookups = succesfulLookupsHopCount = unsuccesfulLookupsHopCount = 0;
		succesfulLookupsHopCountSQ = unsuccesfulLookupsHopCountSQ = 0;
		minHopCount = Integer.MAX_VALUE;
		maxHopCount = Integer.MIN_VALUE;
	}

	private void printStatistics() {
		double unsuccessfulPerc = (double) unsuccesfulLookups / messages;
		double avgHopCount = (double) (succesfulLookupsHopCount + unsuccesfulLookupsHopCount)
				/ messages;

		double avgHopCountSQ = (double) (succesfulLookupsHopCountSQ + unsuccesfulLookupsHopCountSQ)
				/ messages;

		double stdev = Math.sqrt(avgHopCountSQ - avgHopCount * avgHopCount);

		System.out.println("Skipnet statistics: " + unsuccessfulPerc + " " + avgHopCount + " " + stdev
				+ " " + minHopCount + " " + maxHopCount);
	}

	public void callback(SkipnetMessage msg) {
		//A message  was delivered
		collectMessageData(msg);
		//check if yet another message must be sent
		if (messagesent < messages)
			sendMessage();
		else
			printStatistics();
	}

	private void collectMessageData(SkipnetMessage msg) {
		if (msg instanceof MessageStatisticData) {
			MessageStatisticData nmsg = (MessageStatisticData) msg;

			if (nmsg.getHopCount() > maxHopCount)
				maxHopCount = nmsg.getHopCount();

			if (nmsg.getHopCount() < minHopCount)
				minHopCount = nmsg.getHopCount();

			if (nmsg.isSuccesfullookup()) {
				succesfulLookupsHopCount += msg.getHopCount();
				succesfulLookupsHopCountSQ += Math.pow(msg.getHopCount(), 2);
			} else {
				unsuccesfulLookups++;
				unsuccesfulLookupsHopCount += msg.getHopCount();
				unsuccesfulLookupsHopCountSQ += Math.pow(msg.getHopCount(), 2);
			}
		}
	}

}

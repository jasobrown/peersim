package peersim.symphony;

/**
 *
 * @author Andrea Esposito <and1989@gmail.com>
 */
public class RoutingException extends Exception {

    public RoutingException() {
    }

    public RoutingException(String msg) {
        super(msg);
    }
}

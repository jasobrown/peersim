/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;


public class DMPSOConfig
{

/** The w1 parameter (inertial constant) */
double w1;

/** The w2 parameter (inertial constant) */
double w2;

/** Parameter determining how much particles are attracted by 
 * local optima */
double c1;

/** Parameter determining how much particles are attracted by 
 * global optima */
double c2;

/** Maximum initial speed of each particle */
double maxv;

/** Maximum number of function evaluation performed by a swarm */
int maxIter;

//double radius;

int initPoints;

int maxPoints;

int particles;

int modelMaxNew;

int mToFRatio;

int mToFRate;

Function f;


DMPSOConfig(Function f,double w, double ww, double c, double cc, int maxIter,
		int particles,int initPoints,int modelMaxNew,int maxPoints,int mToFR,
		int mToFRa)
{
  this.f = f;
  this.w1 = w;
  this.w2 = ww;
  this.c1 = c;
  this.c2 = cc;
  this.maxv = 0.4 * f.getRangeMax()[0]-f.getRangeMin()[0];
  this.maxIter = maxIter;
  this.initPoints = initPoints;
  this.maxPoints = maxPoints;
  this.particles = particles;
  this.modelMaxNew = modelMaxNew;
  mToFRatio = mToFR;
  mToFRate = mToFRa;

}

}

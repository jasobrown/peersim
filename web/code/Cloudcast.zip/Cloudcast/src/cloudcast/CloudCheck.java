/*
 * Copyright (c) 2011 Alberto Montresor
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package cloudcast;

import peersim.config.*;
import peersim.core.*;

/** 
 * This control is a very simple observer the counts the number of references to the
 * cloud in the network (the cloud "in-degree").
 * <p>
 * The output string is a follows:
 * <pre>
 *   control.cloud: <range parameters> IN-DEGREE <cloud in-degree> SIZE <network size>
 * </pre>
 *
 * @author Alberto Montresor
 * @version $Revision$
 */
public class CloudCheck implements Control
{

private final static String PAR_PROTOCOL = "protocol";

private final int pid;
private final String prefix;

public CloudCheck(String prefix)
{
	this.pid = Configuration.getPid(prefix + "." + PAR_PROTOCOL);
	this.prefix = prefix;
}


public boolean execute()
{
	int count = 0;
	for (int i=0; i < Network.size(); i++) {
		Linkable l = (Linkable) Network.get(i).getProtocol(pid);
		for (int j=0; j < l.degree(); j++) {
			if (l.getNeighbor(j) == Cloud.cloud) {
				count++;
			}
		}
	}
	System.out.println(prefix + ": IN-DEGREE " + count + " SIZE " + Network.size());
	return false; //(Network.size()>1 && count==0);
}

}

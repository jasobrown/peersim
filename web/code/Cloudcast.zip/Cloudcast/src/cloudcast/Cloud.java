/*
 * Copyright (c) 2011 Alberto Montresor
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package cloudcast;

import peersim.config.*;
import peersim.core.*;
import peersim.dynamics.*;

/**
 * This class select a random node as the cloud. It also acts as initializer,
 * wiring the protocol selected by the "protocol" parameter with just one reference
 * to the Cloud.
 * 
 * @author Alberto Montresor
 * @version $Revision: 1.2 $
 */
public class Cloud implements Control, NodeInitializer
{

/**
 * The protocol to operate on.
 * @config
 */
private static final String PAR_PROT = "protocol";

/** This is the reference to the cloud node */
public static Node cloud;

/**
 * The protocol we want to wire
 */
private final int pid;

static {
	cloud = Network.get(0);
}

public Cloud(String prefix)
{
	pid = Configuration.getPid(prefix + "." + PAR_PROT);
}

public void initialize(Node n)
{
	Linkable l = (Linkable) n.getProtocol(pid);
	assert l.degree() == 0;
	l.addNeighbor(Cloud.cloud);
}

public boolean execute()
{
	for (int i = 0; i < Network.size(); i++) {
		if (Network.get(i) != Cloud.cloud) {
			initialize(Network.get(i));
		}
	}
	return false;
}

}

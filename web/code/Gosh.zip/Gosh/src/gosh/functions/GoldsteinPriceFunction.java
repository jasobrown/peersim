/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.config.*;

// d=2; opt.=3.0
public class GoldsteinPriceFunction extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;


public GoldsteinPriceFunction(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);
	rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = -2.048;
    rangeMax[i] = 2.048;
  }	
}

public double eval(double[] x)
{
  return (1.0+StrictMath.pow(x[0]+x[1]+1.0,2)*(19.0-14.0*x[0]+3.0*StrictMath.pow(x[0],2)-14.0*x[1]+6.0*x[0]*x[1]+3.0*StrictMath.pow(x[1],2)))*
	 (30.0+StrictMath.pow(2.0*x[0]-3.0*x[1],2)*(18.0-32.0*x[0]+12.0*StrictMath.pow(x[0],2)+48.0*x[1]-36.0*x[0]*x[1]+27.0*StrictMath.pow(x[1],2)));
//  System.out.print(CommonState.getTime() + ": f(" + x[0]);
//  for (int i=1; i < d; i++) {
//  	System.out.print(", " + x[i]);
//  }
//  System.out.println(") = " + Result);
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;
	
}
}

package adam2;

import java.util.Arrays;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;


/**
 * This control object monitors the CDF estimations at all nodes 
 * in the system and measures their approximation accuracy.
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class CDFVerifier implements Control {

	// Config file parsing prefixes
	protected static final String PAR_INTERVAL = "interval";
	protected static final String PAR_PEERS = "sample.peers";
	protected static final String PAR_IGNORE_JOINING = "ignore.joining";
	
	// Adam2 protocol ID
	protected int protocolID;	

	// Interval between measurements
	protected int interval;
	
	// The number of peers used for calculating the average protocol accuracy. 
	// This should be set to the system size to get a fully correct measurement.
	// For debugging, this variable can be lower to improve performance.
	protected int sampledPeers;
	
	// If this is set, all nodes that have joined during the experiment are ignored
	protected boolean ignoreJoining;
	
	
	public CDFVerifier(String prefix) {
		protocolID = -1;
		sampledPeers = Configuration.getInt(prefix + "." + PAR_PEERS, Network.size());
		interval = Configuration.getInt(prefix + "." + PAR_INTERVAL, 1);
		ignoreJoining = Configuration.getBoolean(prefix + "." + PAR_IGNORE_JOINING, false);
	}

	public boolean execute() {
		long time = CommonState.getTime();
		if (time % interval == 0) {
			int N = Network.size();
			assert N > 0;
			
			// Get CDFVerifier protocol ID
			if (protocolID < 0) {
				Node guineaPig = Network.get(0);
				for (int p = 0; p < guineaPig.protocolSize(); p++) {
					if (guineaPig.getProtocol(p) instanceof Adam2) {
						protocolID = p;
						break;
					}
				}
			}
			
			// Create an array containing all attribute values present in the system
			int[] attributes = new int[N];
			double sum = 0;
			for (int i = 0; i < N; i++) {
				Adam2 peer = (Adam2)Network.get(i).getProtocol(protocolID);
				attributes[i] = peer.getAttribute();
				sum += attributes[i];
			}
			
			// Sort the attributes 
			Arrays.sort(attributes);
			
			// Select unique attributes and generate a CDF
			int uniqueCount = countUnique(attributes);
			int[] unique = new int[uniqueCount];
			double[] cdf = new double[uniqueCount];
			getUniqueAndCDF(attributes, unique, cdf);
			
			// Convert the CDF into a set of flat intervals (since its 
			// discrete) and find all endpoints of these intervals.
			// This is used later to calculate the interpolation error.
			int cdfPointCount = countCDFPoints(unique);
			int[] cdfPoints = new int[cdfPointCount]; 
			double[] cdfValues = new double[cdfPointCount];
			getCDFPoints(unique, cdf, cdfPoints, cdfValues);
				
			// Approximation error at interpolation points
			double maxIP = 0;
			double avgIP = 0;
			// Approximation error over all attribute values
			double maxCDF = 0;
			double avgCDF = 0;
			// Accuracy estimation error
			double avgAccErr = 0;
			double maxAccErr = 0;
			double avgAccRelErr = 0;
			double maxAccRelErr = 0;

			// Iterate over all peers and calculate aggregation error
			double selectP = (double)sampledPeers / (double)N;
			int selectCount = 0;
			for (int i = 0; i < N; i++) {					
				// Get peer's aggregation protocol and current CDF approximation 
				Adam2 peer = (Adam2)Network.get(i).getProtocol(protocolID);
				
				// Check if this peer is going to be surveyed
				if (ignoreJoining && peer.getBirthTime() == CommonState.getTime()) {
					continue;
				}
				// Inspect only randomly selected peers (unless selectP  == 1)
				if (CommonState.r.nextDouble() < selectP) {
					selectCount++;
					
					// Get this peer's interpolation points
					int[] ipx = peer.getInterpolationPointsX();
					double[] ipy = peer.getInterpolationPointsY();
					
					// Interpolation point error
					double dist = maxIPDistance(ipx, ipy, attributes);
					if (dist > maxIP) {
						maxIP = dist;
					}
					avgIP += avgIPDistance(ipx, ipy, attributes);
					
					// Calculate approximation error over all attributes
					double[] result = distanceDiscrete(ipx, ipy, cdfPoints, cdfValues);
					
					// Update overall results
					avgCDF += result[1];
					if (result[0] > maxCDF) {
						maxCDF = result[0];
					}

					// Accuracy self-estimation average error
					double avgError = peer.getAvgError();
					avgAccErr += result[1] > avgError ? result[1] - avgError : avgError - result[1];
					avgAccRelErr += result[1] > avgError ? (result[1] - avgError) / result[1] : (avgError - result[1]) / result[1];

					// Accuracy self-estimation maximum error
					double maxError = peer.getMaxError();
					maxAccErr += result[0] > maxError ? result[0] - maxError : maxError - result[0];
					maxAccRelErr += result[0] > maxError ? (result[0] - maxError) / result[0] : (maxError - result[0]) / result[0];
				}
			}
			// Average errors over all inspected nodes
			avgIP /= selectCount;
			avgCDF /= selectCount;
			avgAccErr /= selectCount;
			maxAccErr /= selectCount;
			avgAccRelErr /= selectCount;
			maxAccRelErr /= selectCount;

			// Print the results
			System.out.println("MaxPointErr=" + (float)maxIP + "  AvgPointErr=" + (float)avgIP + "  MaxErr=" + (float)maxCDF + "  AvgErr=" + (float)avgCDF + "  MaxErrEstErr=" + (float)maxAccRelErr + "  AvgErrEstErr=" + (float)avgAccRelErr);
		}
		// If true is returned, the simulator stops the experiment
		return false;
	}
	
	
	// Returns the number of attributes in the sorted array that are 
	// lower or equal to attr (using bisection)
	protected int belowEqual(int attr, int[] sorted) {
		int from = 0;
		int to = sorted.length;
		assert from <= to;
		while (from < to) {
			int middle = (from + to) / 2;
			if (sorted[middle] <= attr) {
				from = middle + 1;
			}
			else {
				to = middle;
			}
		}
		return from;
	}

	// Get the number of unique attributes in the sorted array
	protected int countUnique(int[] sorted) {
		int uniqueCount = 0;
		int prev = sorted[sorted.length - 1] - 1;
		for (int i = sorted.length - 1; i >= 0; i--) {
			if (sorted[i] != prev) {
				uniqueCount++;
			}
			prev = sorted[i];
		}
		return uniqueCount;
	}
	
	// Get an array of unique attribute values and a corresponding CDF 
	protected void getUniqueAndCDF(int[] sorted, int[] unique, double[] cdf) {
		double N = sorted.length;
		int uniqueCount = unique.length;
		int uniquePos = uniqueCount - 1;
		int prev = sorted[sorted.length - 1] - 1;
		for (int i = sorted.length - 1; i >= 0; i--) {
			if (sorted[i] != prev) {
				cdf[uniquePos] = (double)(i + 1) / N;
				unique[uniquePos] = sorted[i];
				uniquePos--;
			}
			prev = sorted[i];
		}
	}
	
	// Convert the CDF into a set of flat intervals (since attributes are discrete)
	// and count all the endpoints of these intervals.
	// Basically, the function coverts every point x in the array into two 
	// points x and x-1 (unless x-1 already exists in the array).
	protected int countCDFPoints(int[] unique) {
		int N = unique.length;
		int result = N;
		for (int i = 1; i < N; i++) {
			if (unique[i] - 1 > unique[i - 1]) {
				result++;
			}
		}
		return result;
	}
	
	// Convert the CDF into a set of intervals (since attributes are discrete)
	// and obtain all the endpoints of these intervals and their corresponding
	// CDF values.
	protected void getCDFPoints(int[] unique, double[] cdf, int[] points, double[] cdfValues) {
		double N = unique.length;
		points[0] = unique[0];
		cdfValues[0] = cdf[0];
		int j = 1;
		for (int i = 1; i < N; i++) {
			if (unique[i] - 1 > unique[i - 1]) {
				points[j] = unique[i] - 1;
				cdfValues[j] = cdf[i - 1];
				j++;
			}
			points[j] = unique[i];
			cdfValues[j] = cdf[i];
			j++;
		}
	}
	

	// Calculate the average and maximum vertical distance between a real CDF 
	// and its approximation. Since both the CDF and its approximation consist
	// of line segments, the distance can be calculated by looking at the
	// segment endpoints only. This is much faster than iterating over all
	// possible attribute values.
	protected double[] distanceDiscrete(int[] ipx, double[] ipy, int[] cdfPoints, double[] cdfValues) {
		
		if (ipx == null || ipy == null || ipx.length <= 1) {
			// No CDF estimation. Return maximum distance of 1.
			double[] results = {1, 1};
			return results;
		}

		int res = ipx.length;
		int count = cdfPoints.length;
		
		assert ipx[0] <= cdfPoints[count - 1] && ipx[res - 1] >= cdfPoints[0] : "ipx[0]=" + ipx[0] + "  points[N-1]=" + cdfPoints[count - 1] + "  ipx[res-1]=" + ipx[res - 1] + "  cdfPoints[0]=" + cdfPoints[0]; 

		// Interpolation point counter
		int iIP = 0;
		// CDF point counter
		int iCDF = 1;
		
		// Go through all points from right to left, looking at
		// the current values of the CDF and interpolation curve.
		
		// Current X coordinate
		int rightX = cdfPoints[0];
		// Current CDF value
		double rightCDF = cdfValues[0];
		// Current interpolation value
		double rightInt;
		
		if (rightX <= ipx[0]) {
			// Extrapolate 
			rightInt = ipy[0];
		}
		else {
			// Project the first point onto the interpolation curve
			rightInt = ipy[0] + (ipy[1] - ipy[0]) * (rightX - ipx[0]) / (ipx[1] - ipx[0]);
			iIP++;
		}

		// Calculate the initial distance for the first data point
		double dist = rightCDF > rightInt ? rightCDF - rightInt : rightInt - rightCDF;

		// Maximum and total distance
		double max = dist;
		double sum = dist;
			
		// Check all points
		while (iCDF < count) {
			// Move on to the next point
			int leftX = rightX;
			double leftInt = rightInt;
			double leftCDF = rightCDF;
			rightCDF = cdfValues[iCDF]; 
			
			if (iIP >= res) {
				// Move to the next CDF point and extrapolate
				rightX = cdfPoints[iCDF];
				rightInt = ipy[res - 1];
				iCDF++;
			}
			else if (ipx[iIP] > cdfPoints[iCDF]) {
				// Move to the next CDF point
				// Project the CDF point onto the interpolation curve
				rightX = cdfPoints[iCDF];
				rightInt = leftInt + (ipy[iIP] - leftInt) * (rightX - leftX) / (ipx[iIP] - leftX);
				iCDF++;
			}
			else {
				// Move to the next interpolation point
				rightX = ipx[iIP];
				rightInt = ipy[iIP];
				iIP++;
			}

			if (rightX == leftX) {
				// This is possible if there are duplicated interpolation points
				continue;
			}

			// Calculate max distance
			double rightDist = rightCDF > rightInt ? rightCDF - rightInt : rightInt - rightCDF; 
			if (rightDist > max) {
				max = rightDist;
			}

			// Calculate integral (average) distance
			double area;
			if (rightX - leftX == 1) {
				// This may be a gap between two CDF segments
				area = rightDist;
			}
			else {
				// This must be within a CDF segment
				assert leftCDF == rightCDF;
				double leftInt1 = leftInt + (rightInt - leftInt) * (1.0 / (rightX - leftX));
				double leftDist = leftCDF > leftInt1 ? leftCDF - leftInt1 : leftInt1 - leftCDF; 
				if ((leftInt1 - leftCDF) * (rightInt - leftCDF) >= 0) {
					// Both points are above or below the CDF
					area = (rightX - leftX) * (leftDist + rightDist) / 2.0;
				}
				else {
					// One point is above the CDF, the other one is below
					// Find the intersection
					double midX = leftX + (rightX - leftX) * ((leftCDF - leftInt) / (rightInt - leftInt));
					area = leftDist * (midX - leftX) / 2.0 + rightDist * (rightX - midX) / 2.0;
				}
			}
			sum += area;
		}

		// Return the result
		double[] result = new double[2];
		result[0] = max;
		result[1] = sum / (cdfPoints[count - 1] - cdfPoints[0] + 1);
		return result;
	}

	
	// Calculate the average and maximum vertical distance between a CDF and 
	// its approximation by looking at each attribute value in the domain.
	protected double[] distanceBruteForce(int[] ipx, double[] ipy, int[] sorted) {
		
		if (ipx == null || ipy == null || ipx.length <= 1) {
			// No CDF estimation. Return maximum distance of 1.
			double[] results = {1, 1};
			return results;
		}

		LinearInterpolation interpolation = new LinearInterpolation(ipx, ipy);

		int min = sorted[0];
		int max = sorted[sorted.length - 1];
		int N = sorted.length;
		
		double maxDist = 0;
		double sumDist = 0;
		
		// Iterate over all data points
		for (int i = min; i <= max; i++) {
			double est = interpolation.interpolate(i);
			double cdf = ((double)belowEqual(i, sorted) / (double)N);
			double dist = est > cdf ? est - cdf : cdf - est;
			sumDist += dist;
			if (dist > maxDist) {
				maxDist = dist;
			}
		}

		// Return the result
		double[] result = new double[2];
		result[0] = maxDist;
		result[1] = sumDist / (max - min + 1);
		return result;
	}
	

	// Get the maximum (Kolmogorov-Smirnov) distance between interpolation
	// points and the CDF curve.
	protected double maxIPDistance(int[] ipx, double[] ipy, int[] sorted) {
		if (ipx == null || ipy == null || ipx.length <= 1) {
			return 1;
		}
		int N = sorted.length;
		double maxDist = 0;
		// For each interpolation point
		for (int b = 0; b < ipx.length;  b++) {
			int below = belowEqual(ipx[b], sorted);
			double fraction = (double)below / (double)N;
			// Find the vertical distance
			double dist = fraction > ipy[b] ? fraction - ipy[b] : ipy[b] - fraction;
			if (dist > maxDist) {
				maxDist = dist;
			}
		}
		return maxDist;
	}

	// Get the average distance between interpolation points and the CDF.
	protected double avgIPDistance(int[] ipx, double[] ipy, int[] sorted) {
		if (ipx == null || ipy == null || ipx.length <= 1) {
			return 1;
		}
		int N = sorted.length;
		double sumDist = 0;
		for (int b = 0; b < ipx.length;  b++) {
			int below = belowEqual(ipx[b], sorted);
			double fraction = (double)below / (double)N;
			sumDist += fraction > ipy[b] ? fraction - ipy[b] : ipy[b] - fraction;
		}
		return sumDist / (double)ipx.length;
	}
		
}

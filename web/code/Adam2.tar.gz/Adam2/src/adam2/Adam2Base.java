/*
 * Created on 19-Dec-2005
 */
package adam2;

import gossip.protocol.Gossip;
import peersim.cdsim.CDProtocol;
import peersim.config.Configuration;
import peersim.config.IllegalParameterException;
import peersim.core.CommonState;
import peersim.core.Network;
import peersim.core.Node;


/**
 * The base class for the Adam2 protocol. It implements
 * gossip exchange and instance management.
 * The actual CDF approximation (and other properties
 * estimation) is done in subclasses. 
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public abstract class Adam2Base implements CDProtocol {

	// Config file parsing strings:
	public static final String PAR_INSTANCE_TTL = "instance.ttl";
	public static final String PAR_MAX_INSTANCES = "instances.max";
	public static final String PAR_START_RANDOM =  "start.random";
	public static final String PAR_INSTANCE_FREQ = "instance.frequency";
	public static final String PAR_EXCHANGES = "exchanges";
	public static final String PAR_OVERLAY = "overlay";
	public static final String PAR_REQ = "req.fail";
	public static final String PAR_RESP = "resp.fail";
	
	
	// Configurable parameters:
	
	// Average interval between aggregation instances
	protected static int instanceFreq;

	// If set to true, nodes start instances probabilistically 
	protected static boolean startRandom;
	
	// Maximum number of concurrent instances
	protected static int maxInstances;
	
	// Instance duration
	protected static int instanceDuration;
	
	// Number of gossip exchanges per round
	protected static int exchanges;
	
	// Request message failure probability
	protected static double reqFail;
	
	// Response message failure probability
	protected static double respFail;
	
		
	// Per-node runtime variables:
	
	// The number of completed aggregation instances
	// If this is equal to zero, the node is uninitialised
	protected int updates;
	
	// System size estimation
	protected double N;
	
	// Running aggregation instances
	protected Instance[] instances;	
	protected int curInstances; 
	
	// The time when the node joined the system
	protected long birthTime;
	
	// Message counters
	protected int req;
	protected int resp;
	
	// P2P overlay
	// This implementation uses Cyclon, but any other highly-connected
	// overlay (e.g., DHT) should be suitable too
	protected Gossip overlay;
	
	// PeerSim protocol identifiers
	protected int adam2PID;
	protected int gossipPID;
	
	
	// The status of a running instance
	protected static class Instance implements Cloneable {
		// Unique instance identifier (to distinguish between concurrent instances)
		public long id;
		// Time-to-live (to terminate the instance)
		public double ttl;
		// Weight (to estimate the system size)
		public double weight;
		// Instance properties defined by subclasses (e.g., CDF points)
		public double[] props;
		
		public Instance(long id, double ttl, double weight, double[] props) {
			this.id = id;
			this.ttl = ttl;
			this.weight = weight;
			this.props = props;
		}

		@Override
		protected Instance clone() {
			try {
				Instance instance = (Instance)super.clone();
				instance.props = this.props.clone();
				return instance;
			} 
			catch (CloneNotSupportedException e) {
				throw new RuntimeException(e);
			}
		}
	}

	// Initialises an instance tuple when starting a new instance
	protected abstract double[] start();
	
	// Initialises an instance tuple when joining an instance
	protected abstract double[] join(double[] a);
	
	// Merges two instance tuples when two nodes gossip
	protected abstract void merge(double[] a, double[] b);
	
	// Updates current aggregates (system size, CDF, etc.) when an instance completes
	protected abstract void update(double[] a);

		
	/**
	 * The constructor creates a "prototype" node that does not actually 
	 * participate in the system but is used to generate all other nodes by cloning.
	 */ 
	public Adam2Base(String prefix) {
		this.adam2PID = CommonState.getPid();
		this.gossipPID = Configuration.getPid(prefix + "." + PAR_OVERLAY);	
		if (gossipPID < 0) {
			throw new IllegalParameterException(prefix + "." + PAR_OVERLAY, "Invalid protocol: " + 
					Configuration.getString(prefix + "." + PAR_OVERLAY));			
		}
		instanceDuration = Configuration.getInt(prefix + "." + PAR_INSTANCE_TTL, 30);
		maxInstances = Configuration.getInt(prefix + "." + PAR_MAX_INSTANCES, 5);
		startRandom = Configuration.getBoolean(prefix + "." + PAR_START_RANDOM, true);
		instanceFreq = Configuration.getInt(prefix + "." + PAR_INSTANCE_FREQ, instanceDuration);
		exchanges = Configuration.getInt(prefix + "." + PAR_EXCHANGES, 1);
		reqFail = Configuration.getDouble(prefix + "." + PAR_REQ, 0);
		if (reqFail < 0 || reqFail > 1) {
			throw new IllegalParameterException(prefix + "." + PAR_REQ, "Invalid probability");
		}
		respFail = Configuration.getDouble(prefix + "." + PAR_RESP, 0);
		if (respFail < 0 || respFail > 1) {
			throw new IllegalParameterException(prefix + "." + PAR_RESP, "Invalid probability");
		}
	}

	/**
	 * Individual nodes are instantiated by this clone function.
	 */
	public Object clone() {
		Adam2Base clone = null;
		try {
			clone = (Adam2Base)super.clone();
		} 
		catch (CloneNotSupportedException e) {
			e.printStackTrace();
			System.exit(1);
		}
		// The gossip object reference is initialised later
		clone.overlay = null;
		
		clone.instances = new Instance[maxInstances];
		clone.curInstances = 0;
		
		clone.birthTime = CommonState.getTime();
		clone.updates = 0;
		
		clone.req = 0;
		clone.resp = 0;

		// N contains the initial system size. If nodes join gradually, N can be set to 1.
		// If many nodes start at the same time (which is typical in Peersim), 
		// N should be larger to avoid an "instance explosion"  
		clone.N = Network.size();
		
		return clone;
	}

	/*
	 * Method called when an unitialised node gossips with an initialised node.
	 */
	public void bootstrap(Node introducer) {
		// Get an aggregation protocol
		Adam2Base agg = (Adam2Base)introducer.getProtocol(adam2PID); 

		// Obtain initial aggretates
		assert agg.updates > 0;
		this.N = agg.N;
		this.updates = agg.updates;
	}
	
	
	/*
	 * Performs one protocol round.
	 * @see peersim.cdsim.CDProtocol#nextCycle(peersim.core.Node, int)
	 */
	public void nextCycle(Node node, int protocolID) {
		// Finalise some aggregations and clean up
		cleanUp();

		// Check if a new aggregation instanace should be started.
		// Avoid running concurrent instances.
		if (startRandom && curInstances == 0) {
			// Uninitialised nodes should not start instances,
			// unless we are just bootstrapping the system
			if (updates > 0 || birthTime == 0) {
				double r = CommonState.r.nextDouble();
				double p = (1.0 / N) / instanceFreq;
				if (r < p) {
					// Start a new aggregation instance
					startNewInstance();
				}
			}
		}

		// Gossip
		int count = curInstances == 0 ? 1 : exchanges;
		for (int i = count - 1; i >= 0; i--) {
			// Get a handle to the P2P overlay
			if (overlay == null) {
				overlay = (Gossip)CommonState.getNode().getProtocol(gossipPID);
			}
			// Select a gossip partner
			Node neighbour = overlay.getRandomNeighbour();
			if (neighbour != null) {
				// Perform a gossip exchange
				gossip(neighbour);
			}
		}
	}

	/*
	 * Starts a new aggregation instance.
	 */
	public void startNewInstance() {
		// Generate and store an initial tuple
		long id = CommonState.r.nextLong(); 
		double[] props = start();
		Instance instance = new Instance(id, instanceDuration, 1.0, props);
		addInstance(instance);
	}
	
	
	// Performs one gossip exchange.
	private void gossip(Node n) {
		// Update message counters
		req++;
		
		// Check if request delivered
		if (!n.isUp() || CommonState.r.nextDouble() < reqFail) {
			// No gossip exchange
			return;
		}

		Adam2Base that = (Adam2Base)n.getProtocol(adam2PID);		

		// Update n's message counter
		that.resp++;

		// Check if response delivered
		if (CommonState.r.nextDouble() < respFail) {
			// Response lost. Perform a one-way exchange.
			brokenGossip(that);
			return;
		}
		
		// Gossip successful
		if (this.updates == 0 && that.updates > 0) {
			bootstrap(n);
		}

		// Send tuples from this to that
		for (int i = curInstances - 1; i >= 0; i--) {
			Instance instance = instances[i];
			Instance nInstance = that.getInstance(instance.id);
			if (nInstance == null) {
				if (that.canJoin(instance)) {
					// n joins this instance
					nInstance = that.joinAggregation(instance);
				}
				else {
					// Too late for n to join
					continue;
				}
			}
			// Merge instances
			merge(instance, nInstance);
		}			
		// Send tuples from that to this
		for (int i = that.curInstances - 1; i >= 0; i--) {
			Instance nInstance = that.instances[i];
			Instance instance = getInstance(nInstance.id); 
			if (instance == null) {
				if (canJoin(nInstance)) {
					// Join this instance
					instance = joinAggregation(nInstance);
					merge(instance, nInstance);
				}
			}
		}
	}
	
	// Determines if this node can join an aggregation instance.
	private boolean canJoin(Instance instance) {
		// Do not join the instance if:
		// - there are too many concurrent instances (which might happen if the system 
		//   size estimation is inaccurate and nodes start too many instances) 
		// - instance TTL is low (which might happen if the node has just joined the system 
		//   and encoutered an already running instance) 
		return (curInstances < maxInstances && instance.ttl > instanceDuration / 2.0);
	}
	
	
	// Joins an aggregation instance by creating a corresponding local tuple.
	private Instance joinAggregation(Instance instance) {
		// Create new (local) aggregation record
		long id = instance.id;
		double ttl = instance.ttl;
		double[] props = join(instance.props);
		
		// Store it
		Instance local = new Instance(id, ttl, 0.0, props);
		addInstance(local);			
		return local;
	}

	
	// Merge two instance tuples
	protected void merge(Instance a, Instance b) {
		assert a.id == b.id;
		
		// The TTLs fields might differ since nodes are not fully synchronized.
		// By averaging them, all nodes should finish the instance roughly at the same time.
		double avgTTL = (a.ttl + b.ttl) / 2.0;
		a.ttl = avgTTL;
		b.ttl = avgTTL;
		
		// Distribute the weight
		double avgWeight = (a.weight + b.weight) / 2.0;
		a.weight = avgWeight;
		b.weight = avgWeight;
		
		// Merge the remaining properties (CDF estimations, etc.)
		merge(a.props, b.props);
	}

	
	// Gossip scenario where the response message is lost
	private void brokenGossip(Adam2Base that) {
		// Instance tuples are only sent from this to that
		for (int i = curInstances - 1; i >= 0; i--) {
			Instance a = this.instances[i];
			Instance b = that.getInstance(a.id); 

			if (b == null) {
				// B tries to join this instance
				if (that.canJoin(a)) {
					that.joinAggregation(a);
				}
				else {
					// Too late to join
					continue;
				}
			}
			// Update b's values only!
			b.weight = (a.weight + b.weight) / 2.0;

			// Save tuple A
			double[] aProps = a.props.clone();
			// Merge A and B
			merge(a.props, b.props);
			// Make sure A is not changed
			a.props = aProps;
		}
	}
	
	
	// Method run at each round to remove old instances
	private void cleanUp() {
		for (int i = curInstances - 1; i >= 0; i--) {
			Instance instance = instances[i];
			
			// Decrease instance TTL
			instance.ttl--;
			
			// Retire instances with zero or negative TTL 
			if (instance.ttl <= 0) {
				updateAggregates(instance);
				removeInstance(i);
			}
		}
	}
	
	// Update current estimations (N, CDF, and so on)
	private void updateAggregates(Instance instance) {
		// Increase the total instance counter
		updates++;
		
		// Update N
		this.N = 1.0 / instance.weight;
		
		// Update other props
		update(instance.props);
	}
	
	
	protected void addInstance(Instance instance) {
		instances[curInstances] = instance;
		curInstances++;
	}
	
	protected Instance getInstance(long id) {
		for (int i = curInstances - 1; i >= 0; i--) {
			if (instances[i].id == id) {
				return instances[i];
			}
		}
		return null;
	}

	protected void removeInstance(int i) {
		curInstances--;
		instances[i] = instances[curInstances];
		instances[curInstances] = null;
	}

	// Retrieve the longest running instance from the current instances
	protected Instance getOldestInstance() {
		Instance result = null;
		double min = Double.POSITIVE_INFINITY;
		for (int i = curInstances - 1; i >= 0; i--) {
			if (instances[i].ttl < min) {
				result = instances[i];
				min = result.ttl;
			}
		}
		return result;
	}
	
	
	/* 
	 * Get current system size estimation
	 */
	public double getN() {
		return N;
	}
	
}

/*
 * Copyright (c) 2003 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
		
package superpeer;

import peersim.config.Configuration;
import peersim.util.CommonRandom;
import peersim.core.*;
import peersim.dynamics.*;

import java.util.*;

/**
* A network dynamics manager which can grow networks.
*/
public class SuperpeerKiller implements Dynamics {


//--------------------------------------------------------------------------
//Constants
//--------------------------------------------------------------------------


/** 
* String name of the parameter 
*/
public static final String PAR_PROTOCOL = "protocol";

/** 
* The number of superpeer to remove when nodes are scheduled for removal. 
* If less then 1, is interpreted as a percentage of nodes to be removed.
*/
public static final String PAR_REMOVE = "remove";


//--------------------------------------------------------------------------
//Fields
//--------------------------------------------------------------------------


protected final double remove;

protected final int sppID;


//--------------------------------------------------------------------------
//Static fields
//--------------------------------------------------------------------------

private static int[] indexes;


//--------------------------------------------------------------------------
//Initialization
//--------------------------------------------------------------------------

public SuperpeerKiller(String prefix) {

	remove = Configuration.getDouble(prefix+"."+PAR_REMOVE);
	sppID = Configuration.getInt(prefix+"."+PAR_PROTOCOL);
	
}


// ===================== public methods ==============================
// ===================================================================


/**
* Calls {@link #add} or {@link #remove} with the parameters defined by
* the configuration.
*/
public final void modify() {

	int len=0;
	if (indexes == null || Network.size() > indexes.length) {
		indexes = new int[Network.size()];
	}
	for (int i=0; i < Network.size(); i++) {
		RandomSpp spp = (RandomSpp) Network.get(i).getProtocol(sppID);
		if (spp.isSuperpeer()) 
			indexes[len++] = i;
	}

	int newlen;
	if (remove >= 1 ) {
		newlen = (int) remove;
	} else if (remove >= 0) {
		newlen = (int) (remove*len);
	} else {
		throw new IllegalArgumentException();
	}
	if (newlen < 0) 
		newlen = 0;
		
  
  
  while (len > newlen) {
  	int r = CommonRandom.r.nextInt(len);
  	len--;
  	indexes[r] = indexes[len];
  }
  Arrays.sort(indexes, 0, len);
  
	for (int i=len-1; i >= 0; i--) {
		Network.swap(
				Network.size()-1,
				indexes[i] );
			Network.remove();
	}
}

}

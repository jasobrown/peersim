package leo.peersim.common;

/**
 * Lamport's logical clocks
 * 
 * @author leo
 * @version 20090612
 */
public abstract class LamportEvent {
	
	public abstract long getLamportNodeID();
	public abstract long getLamportTimestamp();
	
	public String toString() {
		return "<" + this.getLamportNodeID() + "," + this.getLamportTimestamp() + ">";
	}

}

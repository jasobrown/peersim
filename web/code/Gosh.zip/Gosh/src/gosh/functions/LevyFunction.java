/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.config.*;

// d=30; opt.= 0.0
public class LevyFunction extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;

private double[] y;


public LevyFunction(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);
	rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = -10;
    rangeMax[i] = 10;
  }
  y= new double[d];
}

public double eval(double[] x)
{
  int i;
  double Result;
  for (i=0;i<d;++i)
	  y[i] = 1.0 + 0.25*(x[i]-1.0);
  double t1 = StrictMath.sin(StrictMath.PI*y[0]), t2 = y[d-1] - 1.0;
  Result = t1 * t1 + t2 * t2;
  for (i=1;i<(d-1);++i) {
    t1 = y[0]-1.0;
    t2 = StrictMath.sin(StrictMath.PI*y[i+1]);
    Result += t1 * t1 * (1.0 + 10.0 * t2 * t2);
  }
//  System.out.print(CommonState.getTime() + ": f(" + x[0]);
//  for (int i=1; i < d; i++) {
//  	System.out.print(", " + x[i]);
//  }
//  System.out.println(") = " + Result);
  return Result;
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;

}
}

/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.gap;

import java.util.HashMap;
import java.util.Iterator;
import java.io.*;
import peersim.vector.SingleValueHolder;
import peersim.config.*;
import peersim.core.*;
import peersim.cdsim.CDProtocol;
import peersim.edsim.EDProtocol;
import lehurament.peersim.dynamics.Churnable;
import lehurament.peersim.dynamics.ChurnControl;
import lehurament.CommonForGAPs.*;

/**
* GAP
*/
public class GAP extends GAPVariablesHolder
implements CDProtocol, EDProtocol, Cleanable, Churnable {

	private static final String PAR_STEP = "step";
	protected static final String PAR_SUM = "sum";
	private final int step;
	protected final boolean sumboolean;
	
	static final int updateFreq=1;
	static final int clearFailedFreq=201;
	/**
	 * globalization of a given parameters for onKill()
	 */
	long nodeID;
	int pid;
	Node node;
	
	int clearFailedFreqCount;
	int updateFreqCount;	
	int timeout=0; 
	int dropedPackets=0;
	static double sum=0; //used to compute the true value of the aggregate
	public GAPPacket newVector;
	int newNode = -1; 
	
	private long sessionLength = ChurnControl.INIT_SESSION_LENGTH;
//--------------------------------------------------------------------------
// Initialization
//--------------------------------------------------------------------------
/**
 * @param prefix string prefix for config properties
 */
public GAP(String prefix) { 
	super(prefix);
	step = Configuration.getInt(prefix + "." + PAR_STEP);
	sumboolean = Configuration.getBoolean(prefix + "." + PAR_SUM);
	updateFreqCount = 0;
}
//--------------------------------------------------------------------------
// methods
//--------------------------------------------------------------------------
public double getRealValue() {
	return self();
}
public void setRealValue(double value) {
	GAPPacket p=new GAPPacket();
	p.type=p.type.UPDATELOCAL;
	p.from=nodeID;
	p.aggregate=value;
	if (node!=null)
	sendPacketToNode(node,node, pid, p); 
}
public double getAverage() {
	GAP p = (GAP) Network.get(0).getProtocol(pid);
	if (sumboolean) 
	{
		return p.aggregate();
	}
		else{
			return p.aggregate()/p.child();
	}
}
double aggregate() {
	double res=0;
	boolean does=false;
	for (Iterator<row> i=table.values().iterator();i.hasNext();) {
		row curr=i.next();
		if (curr.role==curr.role.CHILD || curr.role==curr.role.SELF) {
			if (!Double.isNaN(curr.aggregate)) {
				res+=curr.aggregate;
				does=true;
			}
		}
	}
	value=res;
	if (does==true) return res; else return Double.NaN;
}
int child() {
	int res=0;
	for (Iterator<row> i=table.values().iterator();i.hasNext();) {
		row curr=i.next();
		if (curr.role==curr.role.CHILD) {
		res+=curr.child;
		}
	}
	return res+1;
}
double self() {
	double res=0;
	for (Iterator<row> i=table.values().iterator();i.hasNext();) {
		row curr=i.next();
		if (curr.role==curr.role.SELF) {
		res=curr.aggregate;
		}
	}
	return res;
}
	
long parent() {
	for (Iterator<Long> i=table.keySet().iterator();i.hasNext();) {
		Long n=i.next();
		if (table.get(n).role==table.get(n).role.PARENT) return n;
	}		
	return -1;//not found ... note that -2 is root and -1 is undefined
}
//public because peersim.dynamics.randNIforGAP
public GAPPacket updateVector(long id) {
	GAPPacket p=new GAPPacket();
	p.aggregate=aggregate();
	p.from=id;
	p.level=table.get(id).level;
	p.parent=parent();
	p.child=child();
	p.type=p.type.UPDATE;
	return p;
}
void newEntry(Node nodeFrom) {
	row r=new row();
	r.aggregate=Double.NaN;
	r.level=-1;
	r.role=r.role.PEER;
	r.nodePacketCount=0;
	r.nodeFrom=nodeFrom;
	table.put(nodeFrom.getID(), r);
}
void removeEntry(long id) {
	table.remove(id);
}
void failEntry(long id) {
	row r=table.get(id);
	r.aggregate=0; 
	r.level=-1;
	r.child=0;
	r.role=r.role.FAIL;
}
void clearFailed() {
	for (Iterator<Long> i=table.keySet().iterator();i.hasNext();) {
		Long n=i.next();
		if (table.get(n).role==table.get(n).role.FAIL ) i.remove();
	}		
}
void printTable() {
	System.out.println("TABLE-"+nodeID);
	for (Iterator<Long> i=table.keySet().iterator();i.hasNext();) {
		long key=(Long)i.next();
		row r=table.get(key);
		System.out.println("--row: "+key+"->"+"  Aggregat: "+r.aggregate+"  Level: "+r.level+"  Role: "+r.role+" Child: "+r.child);
		}
}
void updateTable(GAPPacket p, long id) {
	row r=table.get(p.from); //get the row that corresponds to the sender node.
	r.aggregate=p.aggregate; 
	r.level=p.level;
	r.child=p.child;
	if (p.parent==id) { r.role=r.role.CHILD;}
		else if (r.role==r.role.CHILD)
		r.role=r.role.PEER;
}
void restoreTableInvariant(long id) {
	//find the smallest non-negative level in the tabel and the id of the node associated with it 
	int minLevel=Integer.MAX_VALUE;//the level
	row minrow=null;//node with minimum row
	for (Iterator i=table.keySet().iterator();i.hasNext();) {
		long key=(Long)i.next();
		row r=table.get(key);
		if (r.level>=0 && r.level<minLevel && r.role!=r.role.SELF) {
			minLevel=r.level;
			minrow=r;			
		}
	}
	if (minLevel==Integer.MAX_VALUE) return;//nothing to do since we do not have a valid row
	long p=parent();
	if (p!=-1) {//if there is a parent, then it should have the smallest level
		if (table.get(p).level!=minrow.level) {
			minrow.role=minrow.role.PARENT;
			table.get(p).role=table.get(p).role.PEER;
		}
	} else minrow.role=minrow.role.PARENT;
	table.get(id).level=minrow.level+1;
}
void writeTopologyToFile() {
if ((node.getID()==0) && ((CommonState.getTime()/step)==5))
	try {
		File file = new File("/home/lehurament/agg/filename.txt");
		// if file doesnt exists, then create it
		if (!file.exists()) {
			file.createNewFile();
		}
		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
	for ( int ii = 0; ii < Network.size(); ++ii) {
		Linkable linkable = (Linkable) Network.get(ii).getProtocol(FastConfig.getLinkable(pid));
		Node peer=linkable.getNeighbor(0);
		for ( int i = 0; i < linkable.degree(); ++i) {
			peer = linkable.getNeighbor(i);
			//String content = "Network.get(ii).getID()+" "+peer.getID()";
			bw.write(Network.get(ii).getID()+" "+peer.getID()+"\n");
		}
	}
	bw.close();
	System.out.println("Done");
	} catch (IOException e) {
			e.printStackTrace();
	}
}
/**
 * This is the standard method the define periodic activity.
 * The frequency of execution of this method is defined by a
 * {@link peersim.edsim.CDScheduler} component in the configuration.
 */
public void nextCycle( Node node, int pid )
{	
writeTopologyToFile();
/**
 * Not part of the original GAP! Periodical broadcast to avoid an isue.
 */	
broadcastPacket(node, pid, updateVector(node.getID()));
//printTable();
/**
 * Not part of the original GAP! Clearing tables rows with FAIL status 
 */
clearFailedFreqCount+=1;
	if (clearFailedFreqCount==clearFailedFreq) {
		clearFailed();
		clearFailedFreqCount=0;
	}
}
/**
* This is the standard method to define to process incoming messages.
*/
public void processEvent( Node node, int pid, Object event ) {
this.node=node;
this.pid=pid;
this.nodeID= node.getID();
GAPPacket e = (GAPPacket)event;
/**
* Not part of the original GAP! 
* Packet order control. If the packet is older than we already got then drop it.
*/
if (e.type==e.type.UPDATE )	
	if (table.get(e.from)!=null )
		if ((e.nodePacketCount<table.get(e.from).nodePacketCount) ) {
			dropedPackets+=1;
			return;
		}
if (e.type==e.type.FAIL || e.type==e.type.NEW )	
if (table.get(e.from)!=null )
	if ((e.nodeNEWFAILPacketCount<table.get(e.from).nodeNEWFAILPacketCount) ) {
			dropedPackets+=1;
			return;
}
	if (e.type==e.type.NEW) {
		newNode = 0;
		if (table.get(e.from)!=null) if (table.get(e.from).role==table.get(e.from).role.FAIL) removeEntry(e.from);
		if (table.get(e.from)==null) newEntry(e.nodeFrom);
		};
	if (e.type==e.type.FAIL) {
		if (e.nodeFrom.isUp() && isTableBroadcast!=1) return;
		if (table.get(e.from)==null) newEntry(e.nodeFrom);
		if (table.get(e.from)!=null) failEntry(e.from);
			
	};	
	if (e.type==e.type.UPDATELOCAL) {
		{
		table.get(nodeID).aggregate=e.aggregate;
		}
	};	
	if (e.type==e.type.UPDATE) {
			if (table.get(e.from)==null) newEntry(e.nodeFrom);
			if (table.get(e.from).role!=table.get(e.from).role.FAIL) 
				updateTable(e,nodeID);
	};	
	if (e.type==e.type.TIMEOUT) {
		timeout=1;
	};
/**
* Not part of the original GAP! 
* Packet order control.
*/
if (table.get(e.from)!=null) if (e.type==e.type.UPDATE) table.get(e.from).nodePacketCount=e.nodePacketCount;		
if (table.get(e.from)!=null) if (e.type==e.type.FAIL || e.type==e.type.NEW) table.get(e.from).nodeNEWFAILPacketCount=e.nodeNEWFAILPacketCount;
restoreTableInvariant(nodeID);
newVector=updateVector(node.getID());
if (newNode!=-1) {
	newVector.type=newVector.type.UPDATE;
	sendPacketToNode(node,e.nodeFrom, pid, newVector);
	newNode=-1;
}
if (!vector.equals(newVector) && timeout==1){
	broadcastPacket(node, pid, newVector);
	vector=newVector;
	timeout=0;
	}
}
public void onKill() {
	GAPPacket p=new GAPPacket();
	p.type=p.type.FAIL;
	p.from=nodeID;
	broadcastPacket(node,pid, p);
}
public void initSession(Node node, int protocol) {
}
public void forUpNodes(Node node, int protocol) {
}
public void forDownNodes(Node node, int protocol) {
	onKill();
}
public long getSessionLength() {
	return sessionLength;
}
public void setSessionLength(long sessionLength) {
	this.sessionLength = sessionLength;
}
}




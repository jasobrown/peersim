/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.overlays;

import peersim.core.*;
import peersim.config.*;
//for GAP
import java.util.HashMap;
import lehurament.CommonForGAPs.*;
/**
 */
public class ChurnableNewscastGAPlose implements ChurnableNewscastNodeInitializer {


//--------------------------------------------------------------------------
//Parameters
//--------------------------------------------------------------------------

	
private static final String PAR_GAPPROT = "GAPprotocol";	

//--------------------------------------------------------------------------
//Fields
//--------------------------------------------------------------------------

private final int GAPpid;


//--------------------------------------------------------------------------
//Initialization
//--------------------------------------------------------------------------

/**
 * Standard constructor that reads the configuration parameters. Invoked by the
 * simulation engine.
 * @param prefix the configuration prefix for this class
 */
public ChurnableNewscastGAPlose(String prefix)
{
	GAPpid = Configuration.getPid(prefix + "." + PAR_GAPPROT);
}

//--------------------------------------------------------------------------
//Methods
//--------------------------------------------------------------------------

/**
 */

public void initialize(Node n, Node to)
{
	if (Network.size() == 0) return;
	GAPVariablesHolder prot = (GAPVariablesHolder) n.getProtocol(GAPpid);
	GAPPacket p=new GAPPacket();
	p.type=p.type.FAIL;
	p.from=n.getID();
	p.nodeFrom=n;
//	System.out.println("|| Node-"+to.getID()+" LOSE NEIGHOUR(FAIL): "+n.getID()+" ||");
	prot.sendPacketToNode(n,to, GAPpid, p);
	GAPVariablesHolder prot1 = (GAPVariablesHolder) to.getProtocol(GAPpid);
	GAPPacket p1=new GAPPacket();
	p1.type=p1.type.FAIL;
	p1.from=to.getID();
	p1.nodeFrom=to;
//	System.out.println("|| Node-"+n.getID()+" LOSE NEIGHOUR(FAIL): "+to.getID()+" ||");
	prot1.sendPacketToNode(to,n, GAPpid, p1);
}
}

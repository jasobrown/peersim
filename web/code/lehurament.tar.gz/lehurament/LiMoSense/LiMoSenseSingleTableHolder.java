/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.LiMoSense;

import peersim.core.*;
import peersim.config.*;
import peersim.transport.Transport;
import java.util.HashMap;
import java.util.Iterator;
/**
 * The task of this protocol is to store a single double value and make it
 * available through the {@link SingleValue} interface.
 *
 * @author Alberto Montresor
 * @version $Revision: 1.2 $
 */
public class LiMoSenseSingleTableHolder 

implements Protocol
{

//--------------------------------------------------------------------------
//Fields
//--------------------------------------------------------------------------
	
/** Value held by this protocol */
	protected static final String PAR_TABLEBROADCAST = "tableBroadcast";
	int isTableBroadcast;
	LiMoSensePair est;
	public double realvalue;
	public double prerealvalue;
	public double sum;
	public int nodeNEWFAILPacketCount;
	public HashMap<Long, LiMoSenseRow> table;

//--------------------------------------------------------------------------
//Initialization
//--------------------------------------------------------------------------

/**
 */
public LiMoSenseSingleTableHolder(String prefix)
{
	isTableBroadcast =  Configuration.getInt(prefix + "." + PAR_TABLEBROADCAST);
	table=new HashMap<Long, LiMoSenseRow>();
	est=new LiMoSensePair(0,0);
	nodeNEWFAILPacketCount=0;
	realvalue=0;
	prerealvalue=0;
	sum=0;
}

//--------------------------------------------------------------------------

/**
 * Clones the value holder.
 */
public Object clone()
{
	LiMoSenseSingleTableHolder svh=null;
	try { svh=(LiMoSenseSingleTableHolder)super.clone(); }
	catch( CloneNotSupportedException e ) {} // never happens
	svh.table=new HashMap<Long, LiMoSenseRow>();
	svh.est=new LiMoSensePair(0,0);
	return svh;
}

//--------------------------------------------------------------------------
//methods
//--------------------------------------------------------------------------
public void broadcastPacket( Node node, int pid, LiMoSensePacket p) {
	Linkable linkable = 
		(Linkable) node.getProtocol( FastConfig.getLinkable(pid) );
	if (linkable.degree() > 0) 
	for (int j = 0; j < linkable.degree(); ++j) {
		Node peern = linkable.getNeighbor(j);
		if(!peern.isUp()) continue;
		((Transport)node.getProtocol(FastConfig.getTransport(pid))).
		send(
				node,
				peern,
				p,
				pid);
		if (p.type!=p.type.UPDATELOCAL && p.type!=p.type.FAIL && p.type!=p.type.NEW) {
			LiMoSense.packetCount+=1;
        }
	}
}
public void sendPacketToNode( Node node, Node nodeto, int pid, LiMoSensePacket p) {
			LiMoSense prot = (LiMoSense) node.getProtocol(pid);
			if (p.type==p.type.FAIL || p.type==p.type.NEW) prot.nodeNEWFAILPacketCount+=1;			
			p.nodeNEWFAILPacketCount=prot.nodeNEWFAILPacketCount;
			((Transport)node.getProtocol(FastConfig.getTransport(pid))).
			send(
					node,
					nodeto,
					p,
					pid);
			if (p.type!=p.type.UPDATELOCAL && p.type!=p.type.FAIL && p.type!=p.type.NEW) {
				LiMoSense.packetCount+=1;
		}
}

void newEntry(Node peer) {
	LiMoSenseRow r=new LiMoSenseRow();
	r.nodeFrom=peer;
	table.put(peer.getID(), r);
}
void removeEntry(long id) {
	table.remove(id);
}
void printTable(long id) {
	System.out.println("TABLE-"+id);
	for (Iterator<Long> i=table.keySet().iterator();i.hasNext();) {
		long key=(Long)i.next();
		LiMoSenseRow r=table.get(key);
		System.out.println("--LiMoSenseRow: "+key+"->"+"  estSentvalue: "+r.estSent.value+"  estReceivedvalue: "+r.estReceived.value);
		System.out.println("--LiMoSenseRow: "+key+"->"+"  estSentweight: "+r.estSent.weight+"  estReceivedweight: "+r.estReceived.weight);
	}
}
void printWeight(Node node,int pid) {
	double weightsum=0;
	for ( int i = 0; i < Network.size(); ++i) {
	LiMoSense p = (LiMoSense) Network.get(i).getProtocol(pid);
		weightsum+=p.est.weight;
	}
	if (node.getID()==0) System.out.println("SUM.weight="+weightsum);
}
public void setTable(HashMap<Long, LiMoSenseRow> tableset)
{
	this.table = tableset;
}
public HashMap<Long, LiMoSenseRow>  getTable()
{
	return this.table;
}
public double getRealValue()
{
	return realvalue;
}
public double getValue()
{
	return est.value;
}

//--------------------------------------------------------------------------

/**
 * @inheritDoc
 */
public void setValue(double value)
{
	this.est.value = value;
}

//--------------------------------------------------------------------------

/**
 * Returns the value as a string.
 */
public String toString() { return ""+est.value; }

}

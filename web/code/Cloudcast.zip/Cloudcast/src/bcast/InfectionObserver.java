/*
 * Copyright (c) 2011 Alberto Montresor
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package bcast;

import peersim.config.*;
import peersim.core.*;
import peersim.util.*;
import cloudcast.*;

public class InfectionObserver implements Control
{

/**
 * 
 * @config
 */
private static final String PAR_PROTOCOL = "protocol";

/**
 * @config
 */
private static final String PAR_MESSAGES = "messages";

private final int pid;

private final int messages;

private final String prefix;

private final IncrementalStats[] stats;

public InfectionObserver(String prefix)
{
	this.prefix = prefix;
	pid = Configuration.getPid(prefix + "." + PAR_PROTOCOL);
	messages = Configuration.getInt(prefix + "." + PAR_MESSAGES);
	stats = new IncrementalStats[messages];
	for (int i=0; i < stats.length; i++) 
		stats[i] = new IncrementalStats();
}

public boolean execute()
{
	for (int j = 0; j < messages; j++) {
		int size = Network.size();
		for (int i = 0; i < size; i++) {
			if (Network.get(i) != Cloud.cloud) {
				Infectable in = (Infectable) Network.get(i).getProtocol(pid);
				try {
					if (in.isInfected(j)) {
						stats[j].add(in.getDelay(j));
					}
				} catch (UnsupportedOperationException e) {
					// Do nothing; the particular node on which the operation has been invoked
					// does not want to be counted
				}
			}
		}
		if (stats[j].getN() > 0) 
			System.out.println(prefix + ": MSG " + j + " " + stats[j].getN() + " " + Network.size() + " " + stats[j]);
	}
	return false;
}

}

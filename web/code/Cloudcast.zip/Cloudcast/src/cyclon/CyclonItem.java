/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package cyclon;

import peersim.core.*;

public class CyclonItem
{

private Node node = null;
private int age;

public CyclonItem(Node node)
{
	this.node = node;
  this.age = 0;
}

public CyclonItem(CyclonItem item)
{
	this.node = item.node;
  this.age = item.age;
}

public Node getNode() { return node; } 
public void setNode(Node node) { this.node = node; }
public int age() { return age; }
public void incAge() { age++; }
public void serAge(int age) { this.age = age; }
public void zeroAge() { age=0; }

public CyclonItem copy()
{
	return new CyclonItem(this);
}

/**
 * Default equality comparator for CyclonItem objects.
 * Two CyclonItem instances are equal iff they refer to
 * the same Node instance.
 */
public final boolean equals(Object obj)
{
  return node == ((CyclonItem)obj).node;
}

}

package boinc;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.util.Date;

import javax.xml.stream.XMLStreamException;

import cern.jet.random.Uniform;
import cern.jet.random.engine.MersenneTwister;


/**
 * A tool for plotting BOINC host properties. In takes one property as an input 
 * parameter.
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class RandPlotter {

	public static void main(String[] args) {
		if (args.length < 3 || args.length > 4) {
			System.out.println("Usage: java Plotter <trace-file> <output-name> <prop> [max-entries]");
			return;
		}
		
		try {
			String traceFile = args[0];
			BoincParser parser = new BoincParser(traceFile); 

			String outputName = args[1];

			String xProp = args[2];

			int limit = Integer.MAX_VALUE;
			if (args.length == 4) {
				limit = Integer.parseInt(args[3]);
			}

			Class hostClass = new BoincHost().getClass();
			Field xField = hostClass.getField(xProp);

			OutputStream dataStream = new FileOutputStream(outputName + ".txt");
			OutputStreamWriter dataWriter = new OutputStreamWriter(dataStream);

			Uniform uniform = new Uniform(new MersenneTwister(new Date()));	
			
			System.out.println("Parsing...");
			int i;
			for (i = 0; i < limit; i++) {
				BoincHost host = parser.readHost(); 	
				
				if (host == null) {
					// End of trace
					break;
				}
				else {
					double x = xField.getDouble(host);
					double y = uniform.nextDoubleFromTo(0, 1);
					
					dataWriter.write(x + " " + y + "\n");
					
					if (i % 10000 == 9999) {
						System.out.print("*");
					}
				}
			}
			parser.close();
			dataWriter.close();
			
			System.out.println();
			System.out.println("Parsed " + i + " host entries.");
			
			System.out.print("Generating gnuplot file...");
			OutputStream gnuplotStream = new FileOutputStream(outputName + ".gnuplot");
			OutputStreamWriter gnuplotWriter = new OutputStreamWriter(gnuplotStream);

			gnuplotWriter.write("set terminal postscript\n");
			gnuplotWriter.write("set output \"" + outputName + ".eps\"\n");
			gnuplotWriter.write("set xlabel \"" + xProp + "\"\n");
			gnuplotWriter.write("set ylabel \"random\"\n");
			gnuplotWriter.write("#set xrange [1:1e9]\n");
			gnuplotWriter.write("#set logscale x\n");
			gnuplotWriter.write("set yrange [0:1]\n");
			gnuplotWriter.write("plot \"" + outputName + ".txt\" using 1:2 title \"" + traceFile + "\" with points\n");
			gnuplotWriter.close();

			System.out.println(" done");
		} 
		catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
		}
		catch (XMLStreamException e) {
			System.out.println("Read error: " + e.getMessage());
		}
		catch (IOException e) {
			System.out.println("Write error: " + e.getMessage());
		}
		catch (NoSuchFieldException e) {
			System.out.println("Invalid host property: " + e.getMessage());
		}
		catch (IllegalArgumentException e) {
			System.out.println("Cannot convert host property to number");
		} 
		catch (IllegalAccessException e) {
			e.printStackTrace();
		} 
	}

}

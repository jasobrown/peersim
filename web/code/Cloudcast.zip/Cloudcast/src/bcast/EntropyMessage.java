/*
 * Copyright (c) 2011 Alberto Montresor
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package bcast;

import java.util.*;

import peersim.core.*;

/**
 * This container class represents an anti-entropy message, containing the
 * status for all potential messages and a sender field identifying the
 * sender of the message. If the sender is null, the message is a reply to
 * a previous message and no further reply is needed.
 */
public class EntropyMessage
{

/** Sender of this message */
Node sender;

/** Status for all potential messages */
byte[] status;

/** Maximum number occupied */
int maxmsg;

/** Buffer containing reusable messages to prevent garbage collection */
private static ArrayList<EntropyMessage> buffer = new ArrayList<EntropyMessage>();

/**
 * Private constructor; use getMessage instead
 */
private EntropyMessage()
{
}

/**
 * Factory method to get messages. Either it re-use an existing message, or
 * creates a new one if none is available.
 * 
 * @param source
 *          the content to be inserted in the message
 * @param sender
 *          the sender of this message
 * @return
 */
static EntropyMessage getMessage(byte[] source, int maxmsg, Node sender)
{
	EntropyMessage msg;
	if (buffer.isEmpty()) {
		msg = new EntropyMessage();
		msg.status = new byte[source.length];
	} else {
		msg = buffer.remove(buffer.size() - 1);
	}
	msg.maxmsg = maxmsg;
	for (int i=0; i <= maxmsg; i++)
		msg.status[i] = source[i];
	msg.sender = sender;
	return msg;
}

static void release(EntropyMessage msg)
{
	buffer.add(msg);
}

}

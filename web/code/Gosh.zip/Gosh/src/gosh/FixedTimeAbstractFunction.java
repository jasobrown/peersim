/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;

import peersim.config.*;

/**
 * This abstract class may be extended by an actual function evaluator.
 *
 * @author Alberto Montresor
 * @version $Revision: 1.1 $
 */
public abstract class FixedTimeAbstractFunction implements Function
{

/**
 * This configuration parameter describes the fixed time needed
 * to perform an eveluation. 
 * @config
 */
private static final String PAR_TIME = "time";

private long time;

public FixedTimeAbstractFunction(String prefix)
{
	time = Configuration.getLong(prefix+"."+PAR_TIME);
}

public long getTime()
{
	return time;
}

public void setTime(long time)
{
	this.time = time;
}

}

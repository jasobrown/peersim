package peersim.skipnet;

import org.apache.commons.lang.RandomStringUtils;

import peersim.config.Configuration;
import peersim.config.IllegalParameterException;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.dynamics.NodeInitializer;
import peersim.edsim.EDSimulator;
import peersim.skipnet.SkipnetUtil.*;
/**
 * This class initialize a set of peersim.extras.am.skipnet protocol instances.
 * 
 * @author Rodolfo Cartas
 *
 */
public class SkipnetInit implements Control, NodeInitializer {

//	--------------------------------------------------------------------------
//	Parameters
//	--------------------------------------------------------------------------

	/**
	 * This parameter defines the set of protocols to instantiate.
	 * 
	 * @config
	 */	
	private static final String PAR_PROTOCOL = "protocol";

	/**
	 * Defines the latest time for a node to join a peersim.extras.am.skipnet.
	 * 
	 * @config
	 */	
	private static final String PAR_MAXSTART = "maxstart";

	/**
	 * Number of organizations present in the peersim.extras.am.skipnet namespace.
	 * 
	 * @config
	 */	
	private static final String PAR_ORGANIZATIONS = "organizations";

	/**
	 * If present, only one node works as seed for the peersim.extras.am.skipnet.
	 * 
	 * @config
	 */	
	private static final String PAR_SINGLESEED = "singleseed";

//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------
	
	/** {@link #PAR_MAXSTART} */
	private static long maxstart;

	/** {@link #PAR_ORGANIZATIONS} */
	private static int numorg;

	/** {@link #PAR_SINGLESEED} */
	private static boolean singleseed;
	
	/** {@link #PAR_SINGLESEED} */
	private final int[] pid;
	
	private int seedarray[];
	
	private String organizations[];

//	--------------------------------------------------------------------------
//	Initialization
//	--------------------------------------------------------------------------
	public SkipnetInit(String n) {
		String[] prots = Configuration.getString(n + "." + PAR_PROTOCOL).split(
				"\\s");

		maxstart = Configuration.getLong(n + "." + PAR_MAXSTART);

		numorg = Configuration.getInt(n + "." + PAR_ORGANIZATIONS, 1);

		singleseed = Configuration.contains(n + "." + PAR_SINGLESEED);

		generateOrganizations();

		pid = new int[prots.length];
		for (int i = 0; i < prots.length; ++i) {
			pid[i] = Configuration.lookupPid(prots[i]);
			if (!(Network.prototype.getProtocol(pid[i]) instanceof Skipnet)) {
				throw new IllegalParameterException(n + "." + PAR_PROTOCOL,
						"Only Skipnet is accepted here");
			}
			if (Math.pow(2, ((Skipnet) Network.prototype.getProtocol(pid[i]))
					.getHeight()) < Network.size()) {
				throw new IllegalParameterException(
						n + "." + PAR_PROTOCOL,
						"The network size is bigger than peersim.extras.am.skipnet address space (check height parameter)");
			}
		}

	}

	private void generateOrganizations() {
		organizations = new String[numorg];

		for (int i = 0; i < numorg; i++) {
			organizations[i] = createName(5);
		}
	}

	
//	--------------------------------------------------------------------------
//	Methods
//	--------------------------------------------------------------------------
	
	public boolean execute() {
		int max = (int) (Math.log(Network.size()) / Math.log(2));
		if (singleseed || Network.size() <= 4) {
			seedarray = new int[1];
			seedarray[0] = CommonState.r.nextInt(Network.size());
			for (int i = 1; i < max; i++)
				CommonState.r.nextInt(Network.size());

		} else {
			seedarray = new int[max];
			for (int i = 0; i < max; i++)
				seedarray[i] = CommonState.r.nextInt(Network.size());
		}

		for (int i = 0; i < Network.size(); i++) {
			initialize(Network.get(i));
		}

		return false;
	}

	public void initialize(Node n) {
		int seedindex = 0;
		for (int i = 0; i < pid.length; i++) {
			Skipnet skipnet = (Skipnet) n.getProtocol(pid[i]);
			String name = new String();
			// name += (char)(n.getID()+65);
			name += organizations[CommonState.r.nextInt(numorg)];
			name += "." + createName(10);

			skipnet.getLocalname().setIdentifier(name);
			skipnet.getLocalNumId().generateAddressFromString(name);

			skipnet.setSeed(Network.get(seedarray[seedindex]));
			seedindex = (seedindex + 1) % seedarray.length;
			skipnet.setLocalnode(n);

			long delay = CommonState.r.nextLong(maxstart);
			EDSimulator.add(delay, Events.JOIN, (Node) n, pid[i]);
		}

	}

	private String createName(int len) {
		return RandomStringUtils.random(len, 65, 90, true, false, null,
				CommonState.r);
	}

}

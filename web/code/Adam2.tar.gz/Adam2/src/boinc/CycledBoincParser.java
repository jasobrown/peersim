package boinc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;


/**
 * A parser that processes a given BOINC file in an infinite loop.
 * When it reads all entries from the file, it re-opens the file and starts 
 * from the begining.
 * 
 * @author Jan Sacha
 */
public class CycledBoincParser extends BoincParser {

	private String traceFile;

	public CycledBoincParser(String boincTraceFile) throws FileNotFoundException, XMLStreamException {
		super(boincTraceFile);
		this.traceFile = boincTraceFile;
	}

	public BoincHost readHost() throws XMLStreamException { 
		BoincHost host = super.readHost();
		if (host == null) {
			// End of trace
			try {
				// Re-open the same trace file
				reader.close();				
				XMLInputFactory factory = XMLInputFactory.newInstance();
				reader = factory.createXMLStreamReader(new FileInputStream(traceFile));
				readTag("hosts");
			} 
			catch (FileNotFoundException e) {
				throw new XMLStreamException("File not found: " + traceFile);
			}
			host = super.readHost();
		}
		return host;
	}
	
}

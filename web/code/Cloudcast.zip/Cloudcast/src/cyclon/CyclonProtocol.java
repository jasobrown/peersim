/*
 * Copyright (c) 2011 Alberto Montresor
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package cyclon;

import peersim.config.*;
import peersim.core.*;
import peersim.edsim.*;
import peersim.transport.*;
import cloudcast.*;

/**
 * The protocol implementing the Cyclon protocol modified to work with the storage cloud.
 * 
 *
 * @author Alberto Montresor
 * @version $Revision$
 */
public class CyclonProtocol implements EDProtocol, Linkable
{

// --------------------------------------------------------------------------
// Configuration
// --------------------------------------------------------------------------

/**
 * Cache size of the protocol.
 * @config
 */
private static final String PAR_CACHESIZE = "cache";

/**
 * Number of items to gossip in each cycle.
 * @config
 */
private static final String PAR_GOSSIPLEN = "gossip";

/**
 * The identifier of the protocol that implements the Transport interface.
 * @config
 */
private static final String PAR_TRANSPORT = "transport";

/**
 * The length of a cycle
 */
private static final String PAR_PERIOD = "period";


/**
 * If a node has not heard about a cloud reference for PAR_SILENCE time units, 
 * we create a cloud reference out of nowhere with probability PAR_PROB. 
 */
private static final String PAR_SILENCE = "silence";


/**
 * If a node has not heard about a cloud reference for PAR_SILENCE time units, 
 * we create a cloud reference out of nowhere with probability PAR_PROB. 
 */
private static final String PAR_PROB = "prob";



class ConfigData
{

/** Size of the partial view */
final int cachesize;

/** Number of items to be gossiped */
final int gossip;

/** Transport protocol identifier */
final private int tid;

/** Length of a cycle in the protocol */
final private int period;

/** Length of the silence period after which we could create new Cloud descriptor */
final private int silence;

/** Probability of creating a Cloud descriptor */
final private double prob;


ConfigData(String prefix)
{
	cachesize = Configuration.getInt(prefix + "." + PAR_CACHESIZE);
	gossip = Configuration.getInt(prefix + "." + PAR_GOSSIPLEN);
	tid = Configuration.getPid(prefix + "." + PAR_TRANSPORT);
	period = Configuration.getInt(prefix + "." + PAR_PERIOD);
	silence = Configuration.getInt(prefix + "." + PAR_SILENCE);
	prob = Configuration.getDouble(prefix + "." + PAR_PROB);
}

}

//--------------------------------------------------------------------------
// Fields
//--------------------------------------------------------------------------

/** Partial view of the node */
private CyclonDescriptorArray view;

/** Items sent in the last active exchange */
private CyclonDescriptorArray sent;

/** Config data */
private ConfigData config;

/** The last time some of the nodes saw a cloud descriptor */
private long time;

/** True if the node has executed the first event */
private boolean started;

/** Timeout tag */
private static final Object TIMEOUT = new Object();

/** Read/write operation counters */
private int read;

private int write;


// --------------------------------------------------------------------------
// Static buffers used by all the instances
// --------------------------------------------------------------------------

/** Send buffer */
private static CyclonDescriptorArray buffer;

// --------------------------------------------------------------------------
// Constructors
// --------------------------------------------------------------------------

public CyclonProtocol(String prefix)
{
	config = new ConfigData(prefix);
	buffer = new CyclonDescriptorArray(config.cachesize);
}

public CyclonProtocol(ConfigData config)
{
	this.config = config;
	time = CommonState.getTime();
}

/**
 * Individual nodes are instantiated by means of the clone function.
 */
public Object clone()
{
	CyclonProtocol p = new CyclonProtocol(config);
	p.view = new CyclonDescriptorArray(config.cachesize);
	p.sent = new CyclonDescriptorArray(config.cachesize);
	int r = CommonState.r.nextInt(config.period);
	EDSimulator.add(r, TIMEOUT, CommonState.getNode(), CommonState.getPid());

	return p;
}

// --------------------------------------------------------------------------
// Methods
// --------------------------------------------------------------------------

public void processEvent(Node lnode, int pid, Object event)
{
	if (event == TIMEOUT) {
		activeThread(lnode, pid);
	} else {
		passiveThread(lnode, (CyclonMessage) event, pid);
	}
}

private void activeThread(Node lnode, int pid)
{
	/** The first time this executed, started becomes true */
	started = true;
	
	// Re-schedule next event
	EDSimulator.add(config.period, TIMEOUT, lnode, pid);

	// The cloud has no active part. It should not even locally
	// update the items' age, right?
	if (CommonState.getNode() == Cloud.cloud) {
		return;
	}

	// If the previous message has got no reply, re-insert
	// the items previously sent in the partial view.
	// In case of duplicate items, keep the most up-to-date
	// of them.
	if (sent.size > 0) {
		addWithoutDuplicates(view, sent, config.cachesize);
		sent.reset();
	}
	
	// Increase the age of each item in my cache by 1.
	for (int i = 0; i < view.size; i++) {
		view.items[i].incAge();
	}
	
	if (view.contains(Cloud.cloud)) {
		time = CommonState.getTime();
	}
	
	// Select a random peer; return if none has been selected
	Node rnode = selectPeer(lnode);

	/** 
	 * This code is used to recover from problematic situation, where
	 * all references to the cloud are lost. 
	 */
	int elapsed = (int) (CommonState.getTime() - time);
	if (rnode != Cloud.cloud && elapsed > config.silence*config.period && 
			CommonState.r.nextDouble() < config.prob /* * (elapsed/config.period)*/) {
		view.add(new CyclonDescriptor(Cloud.cloud));
	}

	if (rnode == null)
		return;

	// Create a message to be sent. If the destination is the cloud,
	// the message is as large as the cachesize, and is marked as a reply
	// to avoid replies from the cloud. Otherwise, the message size
	// is equal to 'gossip'. In both cases, the message is filled with
	// 'gossip'-1 items from the local view plus a fresh identifier of the local node.
	CyclonMessage msg = CyclonMessage.getMessage(rnode == Cloud.cloud ? config.cachesize : config.gossip);
	prepareRequest(msg, lnode, rnode);
	msg.setPid(pid);
	msg.setSender(lnode);

	if (rnode == Cloud.cloud) {

		// Read the cloud (at the moment, this is done atomically)
		// SIMULATION TRICK
		CyclonProtocol cp = (CyclonProtocol) Cloud.cloud.getProtocol(CommonState.getPid());
		buffer.reset();
		buffer.add(cp.view);
		
		/* Cloud read operation counter */
		cp.read++;
		
		// If this is not a new node, add a CyclonItem to emulate the active
		// thread of Cyclon		
		if (view.size > 0 || buffer.size <= config.gossip) {
			msg.setSender(lnode);
		  if ((CommonState.getTime()-cp.time) >= config.period/2) {
		  	view.add(new CyclonDescriptor(Cloud.cloud));
		  } else {
		  }
		  if ((CommonState.getTime()-cp.time) >= config.period*2) {
		  	view.add(new CyclonDescriptor(Cloud.cloud));
		  }
		} else {
			msg.setSender(null);
		}
		
		
		
		// Locally add items from the buffer containing the cloud copy
		addWithoutDuplicates(view, buffer, config.cachesize);

		// Fill the message completely
		addWithoutDuplicates(msg, buffer, config.cachesize);

		// Re-insert items contained in the sent buffer
		addWithoutDuplicates(view, sent, config.cachesize);
		sent.reset();

		// cloud message
		msg.setType(CyclonMessage.CLOUDWRITE);

	} else {
		// request message
		msg.setType(CyclonMessage.REQUEST);
		
	}
	msg.setTime(time);
	Transport tr = (Transport) lnode.getProtocol(config.tid);
	tr.send(lnode, rnode, msg, pid);
}

private void passiveThread(Node lnode, CyclonMessage msg, int pid)
{
	if (!started)
		return;
	
	if (msg.getType() == CyclonMessage.REQUEST) {
		CyclonMessage reply = receiveRequest(lnode, msg.getSender(), msg);
		reply.setPid(pid);
		reply.setType(CyclonMessage.REPLY);
		reply.setSender(lnode);
		reply.setTime(time);
		Transport tr = (Transport) lnode.getProtocol(config.tid);
		tr.send(lnode, msg.getSender(), reply, pid);
	} else if (msg.getType() == CyclonMessage.REPLY) {
		receiveReply(lnode, msg.getSender(), msg);
	} else if (msg.getType() == CyclonMessage.CLOUDWRITE) {
		receiveCloudWrite(lnode, msg.getSender(), msg);
	} else {
		assert false;
	}
	CyclonMessage.release(msg);
}

public void prepareRequest(CyclonMessage message, Node lnode, Node rnode)
{
	// Select up to gossip-1 elements (different from rnode) from
	// the current cache
	selectRandomItems(sent, config.gossip - 1, rnode);

	// Add a fresh identifier of myself
	message.add(new CyclonDescriptor(lnode));

	// Copy the sent buffer into the message
	message.add(sent);
}

public CyclonMessage receiveRequest(Node lnode, Node rnode, CyclonMessage request)
{

	// Select up to gossip elements (different from rnode) from
	// the current cache
	selectRandomItems(buffer, config.gossip, rnode);

	// Copy the buffer into a message
	CyclonMessage reply = CyclonMessage.getMessage(config.gossip);
	reply.add(buffer);

	// Merge the received message into the local view
	// If a request sent by this node is pending, consider
	// the corresponding positions not available.
	addWithoutDuplicates(view, request, config.cachesize - (sent.size > 0 ? sent.size + 1 : 0));

  addWithoutDuplicates(view, buffer, config.cachesize - (sent.size > 0 ? sent.size + 1 : 0));
	
	
	if (request.getTime() > time)
		time = request.getTime();
	
	return reply;
}

public void receiveReply(Node lnode, Node rnode, CyclonMessage reply)
{

	if (reply.getTime() > time)
		time = reply.getTime();

	// Merge the received message into the partial view
	addWithoutDuplicates(view, reply, config.cachesize);

	// If space permits, re-insert items in the sent buffer.
	addWithoutDuplicates(view, sent, config.cachesize);
	sent.reset();
}

public void receiveCloudWrite(Node lnode, Node rnode, CyclonMessage reply)
{
  view.reset();
  if (reply.sender != null) {
  	time = CommonState.getTime();
  }
  // Merge the received message into the partial view
  addWithoutDuplicates(view, reply, config.cachesize);
  
  // Cloud write operation counter
  write++;
}


public Node selectPeer(Node lnode)
{
	if (view.size == 0)
		return null;
	int index = 0;
	int max = view.items[0].age();
	for (int i = 1; i < view.size; i++) {
		if (view.items[i].age() > max) {
			index = i;
			max = view.items[i].age();
		}
	}
	// Remove the node and return it to the caller
	Node ret = view.items[index].getNode();
	view.remove(index);
	return ret;
}

private void addWithoutDuplicates(CyclonDescriptorArray dest, CyclonDescriptorArray source, int available)
{
	for (int i=0; i < source.size && dest.size < available; i++) {
		boolean found = false;
		Node node = source.items[i].getNode();
		for (int j = 0; j < dest.size && !found; j++) {
			if (node == dest.items[j].getNode()) {
				// Keep the most up-to-date
				found = true;
				if (source.items[i].age() > dest.items[j].age()) {
					dest.items[j] = source.items[i];
				}
			}
		}
		if (!found) {
			dest.add(source.items[i]);
		}
	}
}


private void selectRandomItems(CyclonDescriptorArray dest, int capacity, Node destination)
{
	dest.reset();
	CyclonDescriptor found = null;
	while (dest.size < capacity && view.size > 0) {
		int r = CommonState.r.nextInt(view.size);
		if (view.items[r].getNode() == destination) {
			found = view.items[r];
			// Found destination; this cannot be sent, so it is removed
			// temporally
			view.remove(r);
		} else {
			// Node different from destination; it is copied in the A array and
			// removed from the view
			dest.add(view.items[r].copy());
			view.remove(r);
		}
	}
	if (found != null) {
		view.add(found);
	}
}

public boolean addNeighbor(Node neighbour)
{
	if (contains(neighbour))
		return false;
//	if (view.size < view.items.length)
		view.add(new CyclonDescriptor(neighbour));
	return true;
}

public boolean contains(Node neighbor)
{
	for (int i = 0; i < view.size; i++) {
		if (view.items[i].getNode() == neighbor)
			return true;
	}
	return false;
}

public int degree()
{
  if (!started)
    return 0;
  else
	  return view.size;
}

public Node getNeighbor(int i)
{
	return view.items[i].getNode();
}

public void pack()
{
	// Do nothing
}

public void onKill()
{
	view = null;
}

/**
 * @return the read
 */
public int getRead()
{
	return read;
}


/**
 * @param read the read to set
 */
public void setRead(int read)
{
	this.read = read;
}


/**
 * @return the write
 */
public int getWrite()
{
	return write;
}


/**
 * @param write the write to set
 */
public void setWrite(int write)
{
	this.write = write;
}


}

package boinc;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Date;

import javax.xml.stream.XMLStreamException;

import cern.jet.random.Uniform;
import cern.jet.random.engine.MersenneTwister;

/**
 * A tool for random shuffling records in a BOINC trace file.
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class Shuffle {

	public static final int INIT_BUFFER_SIZE = 1000000;
	
	protected BoincHost[] buffer;

	protected int bufferSize;

	protected int hostCount;
	
	
	public static void main(String[] args) {
		if (args.length < 2 || args.length > 3) {
			System.out.println("Usage: java Shuffle <trace-file> <out-file> [max-entries]");
			return;
		}
		
		try {
			String traceFile = args[0];
			BoincParser parser = new BoincParser(traceFile); 
	
			String outFile = args[1];
			OutputStream outStream = new FileOutputStream(outFile);
			OutputStreamWriter writer = new OutputStreamWriter(outStream);

			int limit = Integer.MAX_VALUE;
			if (args.length == 3) {
				limit = Integer.parseInt(args[2]);
			}

			Shuffle shuffle = new Shuffle();
			
			// Read all hosts to an internal buffer
			shuffle.readHosts(parser);
			
			// Shuffle the hosts and write them to the output file
			shuffle.writeHosts(writer, limit);
		} 
		catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
		}
		catch (NumberFormatException e) {
			System.out.println("Invalid limit: " + args[2]);
		}
		catch (XMLStreamException e) {
			System.out.println("Read error: " + e.getMessage());
		}
		catch (IOException e) {
			System.out.println("Write error: " + e.getMessage());
		}
	}
	
	protected Shuffle() {
		buffer = new BoincHost[INIT_BUFFER_SIZE];
		bufferSize = INIT_BUFFER_SIZE;
		hostCount = 0;
	}
	
	protected void readHosts(BoincParser parser) throws XMLStreamException {
		System.out.println("Parsing trace...");
		for (;;) {
			BoincHost host = parser.readHost();
			if (host == null) {
				parser.close();
				System.out.println();
				System.out.println("Read " + hostCount + " host entries");
				return;
			}
			else {
				addHost(host);
			}
		}
	}
	
	protected void writeHosts(OutputStreamWriter writer, int limit) throws IOException {
		System.out.println("Shuffling entries...");
		
		// Header
		writer.write("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n");
		writer.write("<hosts>\n");
		
		Uniform uniform = new Uniform(new MersenneTwister(new Date()));		
		int rounds = (hostCount > limit) ? limit: hostCount;
		for (int i = 0; i < rounds; i++) {
			// Choose a random host entry
			int r = uniform.nextIntFromTo(0, hostCount - 1);
			BoincHost host = removeHost(r);
			
			// Write the host entry
			writer.write(host.toString());
			writer.write("\n");
		}
		
		// Finish the trace
		writer.write("</hosts>\n");
		writer.close();
		
		System.out.println();
		System.out.println("Wrote " + rounds + " host entries");

	}
	
	protected void addHost(BoincHost host) {
		if (hostCount == bufferSize) {
			// Array full: allocate a bigger array and copy the contents
			bufferSize *= 2;
			BoincHost[] newBuffer = new BoincHost[bufferSize];
			System.arraycopy(buffer, 0, newBuffer, 0, hostCount);
			buffer = newBuffer;
		}
		buffer[hostCount] = host;
		hostCount++;
		
		if (hostCount % 10000 == 0) {
			System.out.print("*");
		}
	}
	
	protected BoincHost removeHost(int i) {
		hostCount--;
		BoincHost host = buffer[i];
		buffer[i] = buffer[hostCount];
		
		if (hostCount % 10000 == 0) {
			System.out.print("*");
		}
		return host;
	}


}

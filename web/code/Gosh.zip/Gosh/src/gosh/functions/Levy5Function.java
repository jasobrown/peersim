/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.config.*;

// d=30; opt. = 0.0
public class Levy5Function extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;


public Levy5Function(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);
	rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = -5;
    rangeMax[i] = 5;
  }
}

public double eval(double[] x)
{
/* int i, j;
 double Result = 1.0;

  for ( j = 0; j < d; j++ ) {
    double sum = 0.0;
    for ( i = 1; i <= 5; i++ )
      sum += i * StrictMath.cos (((j%2!=0)?(i+1):(i-1)) * x[j] + i);
    Result *= sum;
  }
  double x1 = x[0] + 1.42513, x2 = x[1] + 0.80032;
  Result += x1 * x1 + x2 * x2;
//  System.out.print(CommonState.getTime() + ": f(" + x[0]);
//  for (int i=1; i < d; i++) {
//  	System.out.print(", " + x[i]);
//  }
//  System.out.println(") = " + Result);
  return Result;*/
	
	int j;
	double Result = 0.0;

	Result=Math.pow(Math.sin(Math.PI*3*x[0]),2.0);
	
	double sum = 0.0;
	for ( j = 0; j < d-1; j++ ) {
		sum=sum+(Math.pow(x[j]-1.0,2.0))*(1.0+Math.pow(Math.sin(Math.PI*3*x[j+1]),2.0));
	}
	
	Result = Result + sum + (x[d-1]-1.0)*(1.0+Math.pow(Math.sin(Math.PI*2*x[d-1]),2.0));
	return Result;
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;

}
}

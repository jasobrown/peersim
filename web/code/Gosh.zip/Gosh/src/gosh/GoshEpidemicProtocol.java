/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;

import peersim.config.*;
import peersim.core.*;
import peersim.extras.am.epidemic.*;


public class GoshEpidemicProtocol implements EpidemicProtocol
{

//---------------------------------------------------------------------
//CommonData
//---------------------------------------------------------------------

/**
 * @config
 */
private static final String PAR_LINKABLE = "linkable";

/**
 * @config
 */
private static final String PAR_GOSH = "gosh";

//---------------------------------------------------------------------
//Fields
//---------------------------------------------------------------------

/** Linkable id */
private final int lid;

/** Gosh id */
private final int gid;

//---------------------------------------------------------------------
//Initialization
//---------------------------------------------------------------------

public GoshEpidemicProtocol(String prefix)
{
	lid = Configuration.getPid(prefix + "." + PAR_LINKABLE);
	gid = Configuration.getPid(prefix + "." + PAR_GOSH);
}


public Object clone()
{
	GoshEpidemicProtocol ret = null;
	try {
		ret = (GoshEpidemicProtocol) super.clone();
	} catch (CloneNotSupportedException e) {
	}
	return ret;
}

//---------------------------------------------------------------------
//Methods
//---------------------------------------------------------------------

public Node selectPeer(Node lnode)
{
	Linkable link = (Linkable) CommonState.getNode().getProtocol(lid);
	int d = link.degree();
	if (d == 0)
		return null;
	int r = CommonState.r.nextInt(d);
	return link.getNeighbor(r);
}

public Message prepareRequest(Node lnode, Node rnode)
{
	Gosh gosh = (Gosh) CommonState.getNode().getProtocol(gid);
	return new RumorMessage(gosh.getBest(), gosh.getValue());
}

public Message prepareResponse(Node lnode, Node rnode, Message msg)
{
	Gosh gosh = (Gosh) CommonState.getNode().getProtocol(gid);
	double value = gosh.getValue();
	
	RumorMessage request = (RumorMessage) msg;
	if (request.best == null || value < request.value)
		return new RumorMessage(gosh.getBest(), value);
	else
		return null;
}

public void merge(Node lnode, Node rnode, Message message)
{
	Gosh gosh = (Gosh) CommonState.getNode().getProtocol(gid);
	RumorMessage msg = (RumorMessage) message;
	double value = gosh.getValue();
	if (msg.best != null && msg.value < value) {
	  gosh.setValue(msg.value);
		gosh.setBest(msg.best);
	}
}

private class RumorMessage extends AbstractMessage
{

  private double[] best;
  double value;

  RumorMessage(double[] best, double value)
  {
 		this.best = new double[best.length];
 		System.arraycopy(best, 0, this.best, 0, best.length);
  	this.value = value;
  }

}




}
/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;

import peersim.config.*;
import peersim.core.*;
import peersim.edsim.*;


public class RASHSolver implements EDProtocol, Gosh
{

//---------------------------------------------------------------------
//CommonData
//---------------------------------------------------------------------



/**
 * @config
 */
private static final String PAR_FUNCTION = "function";

/** 
 * @config
 */
private static final String PAR_SHAKERS = "shakers";

/**
 * @config
 */
private static final String PAR_E = "e";
/**
 * @config
 */
private static final String PAR_FRACTION = "fraction";


//---------------------------------------------------------------------
//Fields
//---------------------------------------------------------------------

/** Current best value */
private double[] best;

/** Current best value */
private double bestval;

/** Current shaker being evaluated */
private int current;

/** Box shrinking factors in each dimension */
private double[] eta;

/**  */
private double fraction;

/** For each solver, how many runs without improving the result */
private int[] stasis;

/** For each solver, the value found in the latest run */
private double[] latestValues;

/** Shakers used by this solver */
private RASHShaker[] shakers;

private RASHConfig r_conf;



//---------------------------------------------------------------------
//Constructor
//---------------------------------------------------------------------

public RASHSolver(String prefix)
{
 //   IllegalParameterException ex;
	Function f = (Function) Configuration.getInstance(prefix + "." + PAR_FUNCTION);
	double e = Configuration.getDouble(prefix + "." + PAR_E);
	fraction = Configuration.getDouble(prefix + "." + PAR_FRACTION);        
        if (e<=0.0 || e>=1.0) e = 0.8;
        if (fraction<=0.0 || fraction>0.1) fraction = 0.001;
        int size = Configuration.getInt(prefix + "." + PAR_SHAKERS);
	init(size, fraction, new RASHConfig(f,e));
}

public Object clone() 
{
	RASHSolver ret = null;
	try {
		ret = (RASHSolver) super.clone();
	} catch (CloneNotSupportedException e) {
	}
	ret.init(shakers.length, fraction, r_conf);
	return ret;
}

private void init(int size, double fraction, RASHConfig conf)
{
	r_conf = conf;
	bestval = Double.MAX_VALUE;
	best = new double[r_conf.f.d()];
	double[] max = conf.f.getRangeMax();
        double[] min = conf.f.getRangeMin();
        eta = new double[conf.f.d()];
        for (int i=0; i<conf.f.d(); i++)
          eta[i] = fraction * (max[i]-min[i]);
        latestValues = new double[size];
        shakers = new RASHShaker[size];
        stasis = new int[size];
	for (int i=0; i < size; i++) {
		shakers[i] = new RASHShaker(r_conf);
                stasis[i] = 0;
                latestValues[i]=Double.MAX_VALUE;
	}
	current = 0;
	
        long delay = conf.f.getTime();
	EDSimulator.add(delay, this, CommonState.getNode(), CommonState.getPid());
}


//---------------------------------------------------------------------
//Methods
//---------------------------------------------------------------------


public void processEvent(Node node, int pid, Object event)
{
        if (stasis[current]==5 || shakers[current].firstRun) {
          double[] x0 = new double[r_conf.f.d()];
          for (int i=0; i<r_conf.f.d(); i++)
            x0[i]= (r_conf.f.getRangeMax()[i]-r_conf.f.getRangeMin()[i])*
                    CommonState.r.nextDouble() + r_conf.f.getRangeMin()[i];
          shakers[current].restart(x0,eta);
          stasis[current]=0;
        }
        double v = shakers[current].next ();
        if ( v < bestval ) {
            final double[] p = shakers[current].getX();
            System.arraycopy(p, 0, best, 0, r_conf.f.d());
            bestval = v;
          }
        if (v>=latestValues[current])
          stasis[current]++;
        else stasis[current]=0;
        latestValues[current]=v;
        current = (current + 1) % shakers.length;
        
	long delay = r_conf.f.getTime();
	EDSimulator.add(delay, this, CommonState.getNode(), CommonState.getPid());
}


public double getValue()
{
	return bestval;
}

public double[] getBest()
{
	return best;
}

public void setValue(double value)
{
	this.bestval = value;
}

public void setBest(double[] best)
{
	this.best = best;
}

}

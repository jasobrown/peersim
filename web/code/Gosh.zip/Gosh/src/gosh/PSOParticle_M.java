/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;

import peersim.core.*;
//import java.io.*; 
  
public class PSOParticle_M
{
/*
double[] v;


double[] x;

double xval;
  
double[] lbest;

double lbestval;

*/
  PSOConfig_M pc;
//  int dimension;
  double[] position;
  double[] speed;
  double[] bestPosition;
//  double[] bestKnown; // optional.
  double currentValue;
  double bestValue;

  int outOfBound;
//  BufferedWriter out;
  
//  double bestKnownValue; // optional
//  double maxSpeed;
//  Function f;
//  double w1, w2, c1, c2;
//  int maxIter;
  //boolean active;

//public PSOParticle_M()
//{
//}
/*
public void update(PSOConfig_M pc, double[] best, double bestval)
{
	if (x == null) {
		// First evaluation
		
		double[] rmax = pc.f.getRangeMax();
		double[] rmin = pc.f.getRangeMin();
		int size = pc.f.d();
		
		// Init x and v
		x = new double[size];
		v = new double[size];
		for (int i=0; i < size; i++) {
			x[i] = rmin[i] + CommonState.r.nextDouble() * (rmax[i]-rmin[i]);
			v[i] = CommonState.r.nextDouble()*0.4-0.2;
		}
		
		// Perform first evaluation
		xval = pc.f.eval(x);

		// Copy the x into the best value found so far
		lbest = new double[size];
		System.arraycopy(x,0,lbest,0, size);
		lbestval = xval;

	} else {
		// Following evaluation

	  int size = pc.f.d();
		double r1 = CommonState.r.nextDouble();
	  double r2 = CommonState.r.nextDouble();

	  // Update x, evaluate
	  for (int i=0; i < size; i++) {
	  	x[i] = x[i] + v[i];
	  }
	  xval = pc.f.eval(x);
	  
	  // Update v
	  for (int i=0; i < size; i++) {
	  		v[i] = pc.w * v[i] + 
	  		pc.c1*r1*(lbest[i]-x[i]) + 
	  		pc.c2*r2*(best[i]-x[i]);
	  }
	  
	  // Update local best, if something better has been found
	  if (xval < lbestval) {
	  	lbestval = xval;
			System.arraycopy(x,0,lbest,0, size);
	  }
	}
}

*/
  
 public PSOParticle_M ( PSOConfig_M pc ) 
 {
//   try {
//	 out = new BufferedWriter(new FileWriter("PSOBounds.log"));
//   }
//   catch (IOException ioe) {}; 
	 this.pc=pc;
  double[] max = pc.f.getRangeMax();
  double[] min = pc.f.getRangeMin();
   
 // dimension = pc.f.d();
  position = new double[pc.f.d()];
  speed = new double[pc.f.d()];
  bestPosition = new double[pc.f.d()];
//  bestKnown = new double[dimension];
  double maxSpeed = pc.maxv;
//  f=pc.f;
//  w1=pc.w1;
//  w2=pc.w2;
//  c1=pc.c1;
//  c2=pc.c2;
//  maxIter=pc.maxIter;
  //active=true;

  for ( int i = 0; i < pc.f.d(); i++ ) {
      bestPosition[i] = position[i] = (max[i]-min[i])*CommonState.r.nextDouble()+min[i]; 
    speed[i] = 2*maxSpeed*CommonState.r.nextDouble()-maxSpeed; 
  }

    bestValue = currentValue = Double.NaN; //pc.f.eval(position);
    outOfBound = 0;
//    try
//    {
//      PrintWriter pout = new PrintWriter(new FileWriter("peersimStats.log",true));
//      for(int z=0;z<pc.f.d();z++)
//        pout.println("position["+z+"] = "+position[z]+"\tspeed["+z+"] = "+speed[z]);
//      pout.println("w1 = "+pc.w1+"\t\tw2 = "+pc.w2+"\t\tmaxv = "+pc.maxv);
//      pout.println("Iteration # 0;\tValue: "+currentValue);
//      pout.close();
//    } catch (IOException ex)
//    {
//      ex.printStackTrace();
//    }
    
}

//public double[] getPosition ()
//{
//  return position;
//}

public double getBestValue ()
{
  return bestValue;
}

public double[] getBest ()
{
  return bestPosition;
}

//public void setInertia (double w)
//{
//  w1 = w2 = w;
//}

//public double[] getBestKnown (double[] v)
//{
//  v = bestKnownValue;
//  return bestKnown;
//}

//public void setBestKnown (final double[] x, double v)
//{
//	System.arraycopy(x,0,bestKnown,0, dimension);
//	bestKnownValue = v;
//}

//boolean step ()
//{
//  return step (bestKnown, true);
//} 
 
boolean step (final double[] globalbest, int swarmPid)
{
  if (outOfBound==10) {
	for ( int i = 0; i < pc.f.d(); i++ ) {
      bestPosition[i] = position[i] = (pc.f.getRangeMax()[i]-pc.f.getRangeMin()[i])*
      							CommonState.r.nextDouble()+pc.f.getRangeMin()[i]; 
      speed[i] = 2*pc.maxv*CommonState.r.nextDouble()-pc.maxv; 
	}
	bestValue = currentValue = Double.NaN; //pc.f.eval(position);
	outOfBound = 0;
  }
  if (Double.valueOf(bestValue).isNaN()) {
	  bestValue=currentValue=pc.f.eval(position);
	  return false;
  }
  boolean out = false;
  int fevals = ((PSOSwarm_M)(CommonState.getNode().getProtocol(swarmPid))).getCount();
  double w = (pc.w1 - pc.w2) * ((double)(pc.maxIter - fevals) / (double)pc.maxIter) + pc.w2;
  double r1=0,r2=0;
//  try {
  for ( int i = 0; i < pc.f.d(); i++ ) {
    r1 = CommonState.r.nextDouble();
    r2 = CommonState.r.nextDouble();
    speed[i] = w * speed[i]
      + pc.c1 * r1 * (bestPosition[i] - position[i])
      + pc.c2 * r2 * (globalbest[i] - position[i]);
    if ( speed[i] > pc.maxv )
      speed[i] = pc.maxv;
    else if ( speed[i] < -pc.maxv )
      speed[i] = -pc.maxv;
    position[i] = position[i] + speed[i];
    if (position[i]<pc.f.getRangeMin()[i]) {
//    	out.write("ERROR IN DIMENSION "+i+" : "+position[i]+'\n');
//    	position[i]=pc.f.getRangeMin()[i];
    	out = true;
    }
    if (position[i]>pc.f.getRangeMax()[i]) {
//   	out.write("ERROR IN DIMENSION "+i+" : "+position[i]+'\n');
//    	position[i]=pc.f.getRangeMax()[i];
    	out = true;
    }
  }
/*  out.write("\n"); out.flush();
  }
  catch (IOException ioe) {};
*/  currentValue = pc.f.eval(position);
  //pc.f.inc_evals();
  
//  try
//    {
//      PrintWriter pout = new PrintWriter(new FileWriter("peersimStats.log",true));
//      for(int z=0;z<pc.f.d();z++)
//        pout.println("position["+z+"] = "+position[z]+"\tspeed["+z+"] = "+speed[z]);
//      pout.println("w1 = "+pc.w1+"\t\tw2 = "+pc.w2+"\t\tmaxv = "+pc.maxv+"w = "+w);
//      pout.println("Iteration # "+fevals+";\tr1= "+r1+"\tr2= "+r2+"\tValue: "+currentValue);
//      pout.close();
//    } catch (IOException ex)
//    {
//      ex.printStackTrace();
//    }
  if (out) outOfBound++;
  else { outOfBound=0;
	if ( currentValue < bestValue ) {
      bestValue = currentValue;
      bestPosition = position;
      return true;
	}
  }
  return false;
}
 

}
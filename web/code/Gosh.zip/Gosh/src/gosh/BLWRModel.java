package gosh;

//import java.io.*;


public class BLWRModel implements Function {

//	BufferedWriter modelOut;
	private int MAX_POINTS = 30;
	private double[][] memx;
	private double[] memy;
	int points; //no. of data points
	int nextPoint;
//	double minarg_WR;
//	double maxarg_WR;

	    
	private double[] beta; //coefficients to be estimated
//	private double[][] covar; //covariance matrix
	private double[][] covar_inv; //inverse covar
//	private double shape; //alpha for gamma dist.
//	private double scale; //beta for gamma dist.
	private double[][] weight; //weight matrix
	private double[][] X ; //input attribute matrix corresponding to model n X m
	private double[] Y;  //output matrix n X 1
	private double[][] x;   //input data points
	private double K;  //kernel width
	private int m ; //no. of model parameters
	private int d; //dimension
//	private double sigma; 
	
	private double[] rangeMin;
	private double[] rangeMax;


	public BLWRModel (int maxPoints, Function f)
	{
		super();
		d = f.d();
		MAX_POINTS = maxPoints;
		rangeMin = new double[d];
		rangeMax = new double[d];
//		try {
//			modelOut = new BufferedWriter(new FileWriter("modelOut.log"));
		
		for ( int i = 0; i < d; i++ ) {
	    rangeMin[i] = f.getRangeMin()[i];// modelOut.write("dim:"+i+" min:"+rangeMin[i]);
	    rangeMax[i] = f.getRangeMax()[i];// modelOut.write(" max:"+rangeMax[i]+'\n');
		}
//		}
//		catch (IOException ioe) {};
		K = 0; // model should never be evaluated if it has no point... (see this.eval(x))
//		prior = p;
		points = 0;
		nextPoint = -1;
		memx = new double[MAX_POINTS][d];
		memy = new double[MAX_POINTS];
		
		m=d+1;
		beta = new double[m];  //coefficient 1 X m 
//		sigma = new double[1];
//		var = new double[1];

//		covar = new double[m][m];  // m X m
//		for(int i=0; i < m ;i++)
//			covar[i] = new double[m];

		covar_inv = new double[m][m];  //inv_covariance m X m
//		for(int i=0; i < m ;i++)
//			covar_inv[i] = new double[m];

//		shape = 0.8;
//		scale = 0.001;
//		K = (double)(maxarg_WR-minarg_WR)/16;    //kernel = 2^(localness-7)*(inputrange)

//		for(int i=0;i<m;i++)
//			for(int j=0;j<m;j++)
//				if(i==j)
//					covar[i][j] = 20*20;
//				else
//					covar[i][j]=0;
		
	}	
		
	
	public int d() {
		return d;
	}

	public double[] getRangeMax() {
		return rangeMax;
	}

	public double[] getRangeMin() {
		return rangeMin;
	}
	
	// this method is a fake, just for interface compliance 
	public long getTime()
	{
		return 1000;
	}

/*	public void setDim(int dim) {
		d=dim;
	}

	double[][] getMemx() { return memx; };
*/	
	
	 void initializeModel()
	{

		double k0 = Math.sqrt(points);
		K = 20.0d/(Math.pow(2,k0));    //kernel = 2^(localness-7)*(inputrange)
//		K=4;

		weight = new double[points][points];  // weight n X n
//		for(int i=0; i < n ;i++)
//			weight[i] = new double[n];

		X = new double[points][m];   // input data n X m
//		for(int i=0; i < n ;i++)
//			X[i] = new double[m];

		for(int i=0;i<points;i++)
		{
			X[i][0] = 1;
			for(int j=0;j<d;j++)
				X[i][j+1] = memx[i][j];
		}

		Y = new double[points];   // output data n X 1
//		for(int i = 0; i < n ; i++)
//			Y[i] = new double[1];

		for(int i=0;i<points;i++)
			Y[i]=memy[i];

		x = new double[points][d];  // data n X d
//		for(int i = 0; i < n ; i++)
//				x[i] = new double[d];
		for(int i=0;i<points;i++)
			for(int j=0;j<d;j++)
				x[i][j] = memx[i][j];


	}


	public double eval(double[] x_q)
	{
		/****EVAL_WEIGHT********/
		double dist = 0.0;

		for(int i=0;i<points;i++)
			for(int j=0;j<points;j++)
				if(i==j)
				{
					dist=0.0;
					for(int k=0;k<d;k++)
						dist += (x[i][k]- x_q[k])*(x[i][k]- x_q[k]);
					weight[i][j] = Math.exp(-dist/K);
				}
				else
					weight[i][j]=0.0;
		/********END**********/

		/*****EVAL_Beta_Mean******/
//		for(int i=0;i<m;i++)
//			for(int j=0;j<m;j++)
//				covar_inv[i][j]=0.0;

//		for(int i=0;i<m;i++)
//			for(int j=0;j<m;j++)
//				if(i==j)
//					covar[i][j] = 20*20;
//				else
//					covar[i][j]=0;

		double[][] weight_temp = new double[points][points];

		for(int i=0;i<points;i++)
			for(int j=0;j<points;j++)
				weight_temp[i][j]=0.0;

		double[][] X_temp = new double[points][m]; //X n X m

		for(int i=0;i<points;i++)
			for(int j=0;j<m;j++)
				X_temp[i][j]=0.0;

		double[][] X_trans = new double[m][points]; //X n X m

		for(int i=0;i<m;i++)
			for(int j=0;j<points;j++)
				X_trans[i][j]=0.0;

		double[] Y_temp = new double[points];  //X n X 1

		for(int i=0;i<points;i++)
			Y_temp[i]=0.0;

		double[] Y_temp1 = new double[m] ;  //m X 1

		for(int i=0;i<m;i++)
			Y_temp1[i]=0.0;

		double[] b_final = new double[m];  //X mX 1

		for(int i=0;i<m;i++)
			b_final[i]=0.0;

		for(int i=0;i<m;i++)
			for(int j=0;j<points;j++)
				X_trans[i][j]=X[j][i];

		/*******STEP 1********/
		for(int i=0;i<m;i++)
			for(int j=0;j<m;j++)
				if(i==j)
					covar_inv[i][j] = 1.0d/400.0d;  // covar[i][j];   //\Sigma^-1
				else
					covar_inv[i][j]=0;

		for(int i=0;i<points;i++)      //W^2
			for(int j=0;j<points;j++)
				for(int k=0;k<points;k++)
					weight_temp[i][j] += weight[i][k]*weight[k][j];

		for(int i=0;i<points;i++)   //W^2X
			for(int j=0;j<m;j++)
				for(int k=0;k<points;k++)
					X_temp[i][j] += weight_temp[i][k]*X[k][j]; 

		for(int i=0;i<m;i++)  //covar^-1 + X^TW^2X  
			for(int j=0;j<m;j++)
				for(int k=0;k<points;k++)
					covar_inv[i][j] +=X_trans[i][k]*X_temp[k][j];

//			inverse of covar_inv   (covar^-1 + X^TW^2X)^-1
		/****INVERSE*****/

		double[] data = new double[m*m];

		for(int i=0;i<m;i++)
			for(int j=0;j<m;j++)
				data[i*m+j] = covar_inv[i][j];

		for (int i=1; i < m; i++) data[i] /= data[0]; // normalize row 0
		
		for (int i=1; i < m; i++)  { 
			for (int j=i; j < m; j++)  { // do a column of L
				double sum = 0.0;
				for (int k = 0; k < i; k++)  
					sum += data[j*m+k] * data[k*m+i];
				data[j*m+i] -= sum;
			}
			if (i == m-1) continue;
			for (int j=i+1; j < m; j++)  {  // do a row of U
				double sum = 0.0;
				for (int k = 0; k < i; k++)
					sum += data[i*m+k]*data[k*m+j];
				data[i*m+j] = 
					(data[i*m+j]-sum) / data[i*m+i];
			}
		}
		
		for ( int i = 0; i < m; i++ )  // invert L
			for ( int j = i; j < m; j++ )  {
				double x = 1.0;
				if ( i != j ) {
					x = 0.0;
					for ( int k = i; k < j; k++ ) 
						x -= data[j*m+k]*data[k*m+i];
				}
				data[j*m+i] = x / data[j*m+j];
			}
		
		for ( int i = 0; i < m; i++ )   // invert U
			for ( int j = i; j < m; j++ )  {
				if ( i == j ) continue;
				double sum = 0.0;
				for ( int k = i; k < j; k++ )
					sum += data[k*m+j]*( (i==k) ? 1.0 : data[i*m+k] );
				data[i*m+j] = -sum;
			}
		
		for ( int i = 0; i < m; i++ )   // final inversion
			for ( int j = 0; j < m; j++ )  {
				double sum = 0.0;
				for ( int k = ((i>j)?i:j); k < m; k++ )  
					sum += ((j==k)?1.0:data[j*m+k])*data[k*m+i];
				data[j*m+i] = sum;
			}

		for(int i=0;i<m;i++)
			for(int j=0;j<m;j++)
				covar_inv[i][j]=data[i*m+j];

		/***END_INVERSE****/

		/******STEP 2********/
		for(int i=0;i<points;i++)   //W^2Y
			for(int k=0;k<points;k++)
				Y_temp[i] += weight_temp[i][k]*Y[k];

		for(int i=0;i<m;i++)   //X^TW^2Y
			for(int k=0;k<points;k++)
				Y_temp1[i] += X_trans[i][k]*Y_temp[k];

		for(int i=0;i<m;i++)  //(covar^-1 + X^TW^2X)^-1(X^TW^2Y)
			for(int k=0;k<m;k++)
				b_final[i] +=covar_inv[i][k]*Y_temp1[k];

		for(int i=0;i<m;i++)
			beta[i]=b_final[i];

		/********BETA_MEAN*********/

		/***EVAL_SIGMA************/

//		for(int i=0;i<points;i++)
//			for(int j=0;j<points;j++)
//				weight_temp[i][j]=0.0;

//		for(int i=0;i<points;i++)
//			Y_temp[i]=0.0;   //n  X 1

//		double[] Y_temp2 = new double[points];  //Y 1 X n

//		for(int j=0;j<points;j++)
//			Y_temp2[j]=0.0;

///		double[] Y_trans = new double[points];  //Y 1 X n

//		for(int j=0;j<points;j++)
//			Y_trans[j]=Y[j];

//		for(int i=0;i<m;i++)
//			for(int j=0;j<points;j++)   //m X n
//				X_trans[i][j]=X[j][i];

//		double[] beta_trans = new double[m]; //beta_trans 1 X m

//		for(int j=0;j<m;j++)
//			beta_trans[j]=beta[j];

//		for(int i=0;i<points;i++)      //W^2
//			for(int j=0;j<points;j++)
//				for(int k=0;k<points;k++)
//					weight_temp[i][j] += weight[i][k]*weight[k][j]; 

//		for(int i=0;i<points;i++)   //W^2Y
//			for(int k=0;k<points;k++)
//				Y_temp[i] += weight_temp[i][k]*Y[k];

		//for(int i=0;i<1;i++)   //beta_trans X X_trans
//			for(int j=0;j<points;j++)
//				for(int k=0;k<m;k++)
//					Y_temp2[j] += beta/*_trans*/[k]*X_trans[k][j];

		//for(int i=0;i<1;i++)   //y_trans - beta_trans X X_trans
//			for(int j=0;j<points;j++)
//				Y_trans[j] = Y_trans[j] - Y_temp2[j];

//		double sigma1 = 0.0;

		//for(int i=0;i<1;i++)   //(y_trans - beta_trans X X_trans)*(W^2Y)
//			for(int k=0;k<points;k++)
//				sigma1 += Y_trans[k]*Y_temp[k];

//		sigma1 = sigma1 + 2*0.001;

//		double sum =0.0;
//		for(int i=0;i<points;i++)
//			for(int j=0;j<points;j++)
//				if(i==j)
//					sum +=weight[i][j]*weight[i][j];

//		sum = sum+2*0.8;

//		sigma1 = sigma1/sum;

//		sigma = sigma1;

		/****END_EVAL_SIGMA****/

		/****EVAL_COVAR********/
//		for(int i=0;i<m;i++)
//			for(int j=0;j<m;j++)
//				covar[i][j] = sigma*covar_inv[i][j];

		/******END_EVAL_COVAR**/

		/***EVAL_OUTPUT_VAR*****/
//		double[] q = new double[m];
//		double[] q_trans = new double[m];
//		double[] q_temp = new double[m];
//		double[] q_trans_temp = new double[m];

//		q[0]=1;
//		q_trans[0]=1;

//		for(int j=0;j<m;j++)
//			q_trans_temp[j] = 0.0;

//		for(int i=0;i<m;i++)
//			q_temp[i] = 0.0;

//		for(int i=1;i<m;i++)
//			q[i]=x_q[i-1];

//		for(int j=1;j<m;j++)
//			q_trans[j]=x_q[j-1];

//		for(int j=0;j<m;j++)
//			for(int k=0;k<m;k++)
//				q_trans_temp[j] += q_trans[k]*covar[k][j];

//		var[0] =0.0;
//		for(int k=0;k<m;k++)
//			var[0] += q_trans_temp[k]*q[k];

		/******END_EVAL_OUTPUT_VAR******/
//		var[0] = sqrt(var[0]);
		/******EVAL_MODEL*******/

		double result=0.0;
		double y = beta[0]*1;
		for(int i=1;i<m;i++)
			y +=beta[i]*x_q[i-1];

		result=y;
		
		
		
		return result;
		/****END*****/
		/*Determine value (if PMAX criterion) or upper bound (if IEMAX) based on point and model */

	}

	double[] getX(int index) {
		return memx[index];
	}

	double getY (int index) {
		return memy[index];
	}
	
	public boolean addSamplePoint (double[] x, double v, int initPoints)
	{		/*Use this function to insert a new point to the model*/
/*		boolean flag = true;
		for(int i=0;i<points;i++)
		{
			for(int j=0;j<d;j++)
			{
				if(Math.abs(x[j] - memx[i][j])<1e-10)
					flag = false;
				else
					flag=true;
			}
			if(!flag) {
				initializeModel();
				return false;
			}
		}
*/
		nextPoint=(++nextPoint)%MAX_POINTS;
	//	nextPoint=nextPoint==0?initPoints:nextPoint;
		System.arraycopy(x,0,memx[nextPoint],0,memx[nextPoint].length);
		memy[nextPoint]=v;
		
		if (initPoints<=nextPoint && points<MAX_POINTS)
			points++; 
		initializeModel();
		//	K = StrictMath.pow(points,1.0/d);
		//	System.err.println("Points = "+points+";   K= "+K);			

/*		double opt=1e30;
		for(int i=0;i<Ypoints.size();i++)
		{
			if(Ypoints.get(i)<opt)
				opt = Ypoints.get(i);
		}

		cout<<"The best is "<<opt<<endl;
*/
//		try {
			//	for (double v : x)
			//		modelOut.write(""+v+' ');
//				modelOut.write("At postion "+nextPoint+", value is "+v+'\n');
//				modelOut.flush();
//			} catch (IOException e) {
//				e.printStackTrace();
//			} 
		return true;

	}

}
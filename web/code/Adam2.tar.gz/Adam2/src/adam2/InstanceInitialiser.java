package adam2;

import peersim.config.Configuration;
import peersim.config.IllegalParameterException;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.core.Protocol;


/**
 * This control object periodically initiates aggregation instaces. 
 * It is used for experiments only. It makes protocol analysis easier
 * since it causes instance timing to be fully predictable. 
 * In the fully decentralised Adam2 version, nodes start instances 
 * probabilistically and independently.
 *  
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class InstanceInitialiser implements Control {

	public static final String PAR_PERIOD = "period";

	/*
	 * Interval between Adam2 instances (measured in simulation cycles)
	 */ 
	protected int interval;

	
	public InstanceInitialiser(String prefix) {
		interval = Configuration.getInt(prefix + "." + PAR_PERIOD);
		if (interval < 1) {
			throw new IllegalParameterException(prefix + "." + PAR_PERIOD, "Minimum value is 1!");
		}
	}
		
	public boolean execute() {
		if (CommonState.getTime() % interval == 0) {
			// Start a new instance
			int N = Network.size();
			if (N > 0) {			
				// Get a random node
				int r = CommonState.r.nextInt(N);
				Node node = Network.get(r);
				// Get a reference to Adam2 protocol at this node   
				for (int p = 0; p < node.protocolSize(); p++) {
					Protocol protocol = node.getProtocol(p);
					if (protocol instanceof Adam2) {
						Adam2 adam2 = (Adam2)protocol;
						// Start a new instance at this node
						adam2.startNewInstance();
						break;
					}
				}
			}
		}
		// Do not terminate the simulation
		return false;
	}

}

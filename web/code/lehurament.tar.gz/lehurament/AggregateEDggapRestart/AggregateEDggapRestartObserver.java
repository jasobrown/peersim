/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.AggregateEDggapRestart;
import java.lang.Math;
import peersim.config.*;
import peersim.core.*;
import peersim.vector.*;
import peersim.util.IncrementalStats;
import peersim.transport.Transport;

/**
 * Print statistics for an average aggregation computation. Statistics printed
 * are defined by {@link IncrementalStats#toString}
 * 
 * @author Alberto Montresor
 * @version $Revision: 1.1.1.1 $
 */
public class AggregateEDggapRestartObserver implements Control {

    // /////////////////////////////////////////////////////////////////////
    // Constants
    // /////////////////////////////////////////////////////////////////////

    /**
     * Config parameter that determines the accuracy for standard deviation
     * before stopping the simulation. If not defined, a negative value is used
     * which makes sure the observer does not stop the simulation
     * 
     * @config
     */
    private static final String PAR_ACCURACY = "accuracy";

    /**
     * The protocol to operate on.
     * 
     * @config
     */
    private static final String PAR_PROT = "protocol";
private static final String PAR_STEP = "step";
private static final String PAR_CYCLES = "cycles";

private static final String PAR_INITSTEP = "initstep";

    // /////////////////////////////////////////////////////////////////////
    // Fields
    // /////////////////////////////////////////////////////////////////////

    /**
     * The name of this observer in the configuration. Initialized by the
     * constructor parameter.
     */
    private final String name;

    /**
     * Accuracy for standard deviation used to stop the simulation; obtained
     * from config property {@link #PAR_ACCURACY}.
     */
    private final double accuracy;

    /** Protocol identifier; obtained from config property {@link #PAR_PROT}. */
    private final int pid;

private final int step;
private final int cycles;
private final int initstep;
private	int odd=1;
private IncrementalStats isAverageEstError;
private IncrementalStats isAverageRealSum;

    // /////////////////////////////////////////////////////////////////////
    // Constructor
    // /////////////////////////////////////////////////////////////////////

    /**
     * Creates a new observer reading configuration parameters.
     */
    public AggregateEDggapRestartObserver(String name) {
        this.name = name;
        accuracy = Configuration.getDouble(name + "." + PAR_ACCURACY, -1);
        pid = Configuration.getPid(name + "." + PAR_PROT);
        step = Configuration.getInt(name + "." + PAR_STEP);
        initstep = Configuration.getInt(name + "." + PAR_INITSTEP);
        cycles = Configuration.getInt(name + "." + PAR_CYCLES);
        isAverageEstError = new IncrementalStats();
        isAverageRealSum = new IncrementalStats();
    }

    // /////////////////////////////////////////////////////////////////////
    // Methods
    // /////////////////////////////////////////////////////////////////////

    void Observe( int pid )
    {
    			//System.out.println("nextcicle= "+node.getID()+"> value="+this.value+" weight="+this.weight+" fall "+node.getFailState());
    			double weightsum =0;
    			double valuesum=0;
    			double realvaluesum=0;
    		    for (int i = 0; i < Network.size(); i++) {
    		 		AggregateEDggapRestart prot = (AggregateEDggapRestart) Network.get(i).getProtocol(pid);
    		 		realvaluesum+=prot.realvalue;
    		 		valuesum+=prot.value;
    		 		weightsum+=prot.weight;
//    		 	   System.out.println("VALUE "+i+" "+prot.value);
//    		       System.out.println("WEIGHT "+i+" "+prot.weight);
//    		       System.out.println("SYNC "+i+" "+prot.sync);
    		    }
 			   System.out.println("realVALUESUM "+realvaluesum);  		  
    			   System.out.println("VALUESUM "+valuesum);
    		      System.out.println("WEIGHTSUM "+weightsum);
    		   
    }
    /**
     * Print statistics for an average aggregation computation. Statistics
     * printed are defined by {@link IncrementalStats#toString}. The current
     * timestamp is also printed as a first field.
     * 
     * @return if the standard deviation is less than the given
     *         {@value #PAR_ACCURACY}.
     */
    public boolean execute() {
        long time = peersim.core.CommonState.getTime();
        long inittime = step*initstep;
        int packetCountSum=0;
//        IncrementalStats isEstimateValue = new IncrementalStats();
//        IncrementalStats isRealValue = new IncrementalStats();   
//        IncrementalStats isEstError = new IncrementalStats();
//
//// ########################################## allways get AVARAGE from all up nodes  ####################################################
////		if ((CommonState.getTime()/step == initstep) ) {esterrsum=0;SumSum=0; count=0;}
//		    for (int i = 0; i < Network.size(); i++) {
//				AggregateEDggapRestart protocol = (AggregateEDggapRestart) Network.get(i).getProtocol(pid);
//				// UJ a restart GGAP nel a sum miatt
////				if ((protocol.sync)  & (Network.get(i).isUp()) )   
//				/**
//				 * Kulonbseg a ggap-plushoz hogy csak a sync nodokat szamoljuk az esztimacioban!
//				 * lesz tobb NaN es Infinity ertek mivel az elozo epochban erkezo nodoknak nincs ertekuk a kov epoch ideje alatt. 
//				 */
//				isRealValue.add(protocol.getRealValue());
//				if ((protocol.sync)
//						& (Network.get(i).isUp()) & (!Double.isNaN(protocol.getAverage())) & (!Double.isInfinite(protocol.getAverage()))
//						) {  
//			    isEstimateValue.add(protocol.getAverage());
////			    System.out.println(Network.get(i).getID()+ " Avarage "+ protocol.getAverage());
//				packetCountSum+=protocol.packetCount;	
//				}
//			}
////############################ Estimation from ALL nodes will be averaged##################################
//        for (int i = 0; i < Network.size(); i++) {
//            AggregateEDggapRestart protocol = (AggregateEDggapRestart) Network.get(i).getProtocol(pid);
//		if ((protocol.sync)  
//				& 	(Network.get(i).isUp()) & (!Double.isNaN(protocol.getAverage())) & (!Double.isInfinite(protocol.getAverage()))
//				) { 
//			isEstError.add(Math.abs(protocol.getAverage()-isRealValue.getSum()));
//		}
//	}
//        if (!Double.isNaN(isEstError.getAverage()))
//        {
//            isAverageEstError.add(isEstError.getAverage());
//            isAverageRealSum.add(isRealValue.getSum());
//        }
//		//		if (CommonState.getTime()/step==1) {esterrsum=0; SumSum = 0; count=0;}
////		if (CommonState.getTime()/step>initstep) {
////		count+=1;			
////		SumSum+=realsum;
//////		double temp=esterr/sum;
//////		System.out.println(esterr+" /  "+sum+" = "+temp+" sum "+esterrsum);
////		if (sum!=0) esterrsum=esterrsum+esterr/sum;
//////		System.out.println(esterr+" /  "+sum+" = "+temp+" sum "+esterrsum);
////		averageSumSum=SumSum/count;
////		averageEstErr=esterrsum/count;
////		}
//
////	AggregateEDggapRestart protocol = (AggregateEDggapRestart) Network.get(2).getProtocol(pid);
////	aggregateAverage=protocol.getAverage();
//        /* Printing statistics */
////        System.out.println("Node" + ": " +sum+"t: "+ time/step + " " +"(pCnt)> " + packetCountSum+" "+ is);
////       System.out.println("Nodepakets" + ": " +packetCountSum+"t: "+ time/step + " "+ is+" "+realsum+" "+aggregateAverage+" "+esterrsum);
		Observe(pid);
//    	System.out.println((CommonState.getTime()/step)+" "+isRealValue.getSum()+" "+isEstimateValue.getAverage()+" "+isEstimateValue.getVar()+" "+isAverageEstError.getAverage()+" "+isAverageEstError.getAverage()*100/isAverageRealSum.getAverage()+" PacketCount: "+AggregateEDggapRestart.packetCount);    
//		System.out.println("-------------------GAP-RESTART--------S-U-M----------------------------");
		/* Terminate if accuracy target is reached */
        return (false);
    }
}

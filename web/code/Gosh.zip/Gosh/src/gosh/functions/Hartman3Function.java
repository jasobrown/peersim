/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.config.*;

// d=3; opt.=-3.8627821478207557959
public class Hartman3Function extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;

private double[][] szego_table_a;

private double[] szego_table_c;

private double[][] szego_table_p;

public Hartman3Function(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);
        
        createTables();
        
        rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = 0.0;
    rangeMax[i] = 1.0;
  }	
}

public double eval(double[] x)
{
  int	i, j;
  double w, Result = 0.0;
  for (i = 0; i < 4; ++i)
  {
    w = 0.0;
    for (j = 0; j < 3; ++j)
       w -= szego_table_a[i][j] * StrictMath.pow(x[j] - szego_table_p[i][j],2);
    Result -= szego_table_c[i] * StrictMath.exp(w);
  }
  return Result;
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;
	
}

private void createTables()
{
 //int i,j;
 double[][] a =
 {
  {3.0, 10.0, 30.0},
  {0.1, 10.0, 35.0},
  {3.0, 10.0, 30.0},
  {0.1, 10.0, 35.0}
 };
 double[] c =
 {
  1.0, 1.2, 3.0, 3.2
 };
 double[][] p =
 {
  {0.3689, 0.1170, 0.2673},
  {0.4699, 0.4387, 0.7470},
  {0.1091, 0.8732, 0.5547},
  {0.03815,0.5743, 0.8828}
 }; 
 
 szego_table_a = a;
 szego_table_c = c;
 szego_table_p = p;
}

}

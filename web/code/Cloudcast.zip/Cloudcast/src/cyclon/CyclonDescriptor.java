/*
 * Copyright (c) 2011 Alberto Montresor
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package cyclon;

import peersim.core.*;

/**
 * A cyclon descriptor contains a node identifier (represented by a node reference inside Peersim) 
 * and a numeric age.
 * 
 *
 * @author Alberto Montresor, Spyros Voulgaris
 * @version $Revision$
 */
public class CyclonDescriptor
{

private Node node = null;
private int age;

public CyclonDescriptor(Node node)
{
	this.node = node;
  this.age = 0;
}

public CyclonDescriptor(CyclonDescriptor desc)
{
	this.node = desc.node;
  this.age = desc.age;
}

public Node getNode() { return node; } 
public void setNode(Node node) { this.node = node; }
public int age() { return age; }
public void incAge() { age++; }
public void setAge(int age) { this.age = age; }
public void zeroAge() { age=0; }

public CyclonDescriptor copy()
{
	return new CyclonDescriptor(this);
}

/**
 * Default equality comparator for CyclonDescriptor objects.
 * Two CyclonDescriptor instances are equal iff they refer to
 * the same Node instance.
 */
public final boolean equals(Object obj)
{
  return node == ((CyclonDescriptor)obj).node;
}

}

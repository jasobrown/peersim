/*
 * Created on Apr 4, 2005 by Spyros Voulgaris
 *
 */
package gossip.item;

/**
 * @author Spyros Voulgaris
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface ItemAge
{
  public int age();

  public void incAge();
  
  public void zeroAge();
}

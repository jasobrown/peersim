/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package cyclon;

import peersim.core.*;

public class CyclonItemArray 
{

int size;
CyclonItem[] items;

public CyclonItemArray(int size)
{
	items = new CyclonItem[size];
}

public final void addItem(CyclonItem item)
{
	items[size++] = item;
}

public void addItems(CyclonItemArray toadd)
{
	for (int i=0; i < toadd.size; i++) {
	  addItem(toadd.items[i]);;
	}
}

public void remove(int i)
{
	items[i] = items[--size];
}	

public void reset()
{
	size = 0;
}

public boolean isFull()
{
	return size == items.length;
}

public boolean contains(Node node)
{
	for (int i=0; i < size; i++) {
		if (items[i].getNode() == node)
			return true;
	}
	return false;
}

}
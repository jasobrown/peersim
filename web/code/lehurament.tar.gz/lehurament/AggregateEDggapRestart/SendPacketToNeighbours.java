/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.AggregateEDggapRestart;

import peersim.core.*;
import peersim.config.*;
import peersim.transport.Transport;

public class SendPacketToNeighbours
{
	int count=0;
public SendPacketToNeighbours()
{
}	
public static void broadcastPacket( Node node, int pid, ggapRestartPacket p) {
		Linkable linkable = 
			(Linkable) node.getProtocol( FastConfig.getLinkable(pid) );
		if (linkable.degree() > 0) 
		for (int j = 0; j < linkable.degree(); ++j) {
			Node peern = linkable.getNeighbor(j);
			if(!peern.isUp()) continue;
//System.out.println("from: "+(int) node.getID()+" "+p.type+" to:"+(int) peern.getID());
			((Transport)node.getProtocol(FastConfig.getTransport(pid))).
			send(
					node,
					peern,
					p,
					pid);
			if (p.type!=p.type.UPDATELOCAL && p.type!=p.type.FAIL && p.type!=p.type.NEW)	AggregateEDggapRestart.packetCount+=1;
		}
}
public static void sendPacketToNode( Node node, Node nodeto, int pid, ggapRestartPacket p) {
//	System.out.println("from: "+(int) node.getID()+" "+p.type+" to:"+(int) nodeto.getID());
	if(!nodeto.isUp()) return;
			((Transport)node.getProtocol(FastConfig.getTransport(pid))).
			send(
					node,
					nodeto,
					p,
					pid);
			if (p.type!=p.type.UPDATELOCAL && p.type!=p.type.FAIL && p.type!=p.type.NEW)		AggregateEDggapRestart.packetCount+=1;
	}	
}


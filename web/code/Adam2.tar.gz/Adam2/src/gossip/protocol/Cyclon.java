/*
 * Created on Oct 10, 2004 by Spyros Voulgaris
 *
 */
package gossip.protocol;

import gossip.comparator.Random;
import gossip.item.Item;
import gossip.item.ItemAge;
import gossip.item.ItemSim;
import java.util.Collections;
import java.util.Vector;
import peersim.core.*;

/**
 * @author Spyros Voulgaris
 * 
 * Cyclon implements the basic shuffling protocol. Depending on the Item
 * instance used, it runs either basic shuffling (Item) or Cyclon (ItemAge).
 * 
 */
public class Cyclon extends Gossip {
	// ------------------------------------------------------------
	// ----------------- Initialization methods -------------------
	// ------------------------------------------------------------

	/**
	 * Default constructor. Called only once for a new protocol class instance.
	 */
	public Cyclon(String name) {
		super(name);
	}

	private Vector selectItemsToSend(Item destItem, Vector receivedItems,
			int howmany) {
		Vector itemsToSend = new Vector(gossipConfig.gossipLen);

		// If I want to send ALL items, there's no need to sort them.
		// Otherwise shuffle them, to select random 'howmany' of them.
		if (howmany < items.size()) {
			// Sort based on the selectComparator...
			Collections.shuffle(items, CommonState.r);
			if (!(gossipConfig.selectComparator instanceof Random))
				Collections.sort(items, gossipConfig.selectComparator);
		}

		// And now select the 'howmany' first of my sorted cache.
		for (int i = 0; i < items.size(); i++) {
			ItemSim item = (ItemSim) items.elementAt(i);

			// Check if the selected item is the destination node,
			// which should obviously be excluded.
			if (!item.equals(destItem)) {
				items.remove(i--);
				itemsToSend.add(item);
				if (--howmany == 0)
					break;
			}
		}

		return itemsToSend;
	}

	public void nextCycle(Node nodeA, int protocolID) {
		assert !contains(nodeA);

		if ((items.size() == 0) || (gossipConfig.gossipLen == 0))
			return;

		// Sort based on the selectComparator...
		Collections.shuffle(items, CommonState.r);
		Collections.sort(items, Collections
				.reverseOrder(gossipConfig.selectComparator));

		// ...and select from the end.
		int peerIndex = items.size() - 1;
		ItemSim itemB = (ItemSim) items.remove(peerIndex);
		Cyclon protB = (Cyclon) itemB.node.getProtocol(protocolID);

		// PAOLO
		if (itemB.node.isUp()) {

			Item itemA = newItemInstance(nodeA);

			// Initially select 'gossipLen'-1 items from A to send to B.
			// Of course, exclude B itself.
			Vector sendA2B = selectItemsToSend(itemB, null,
					gossipConfig.gossipLen - 1);

			// Add my own item to the list to send to B.
			sendA2B.add(itemA);

			// And now select 'gossipLen' items of B to send to A.
			// This time exclude possible pointers to A.
			Vector sendB2A = protB.selectItemsToSend(itemA, sendA2B,
					gossipConfig.gossipLen);

			// Insert the selected items to each other's cache
			insertReceivedItems(sendB2A, sendA2B, nodeA);
			protB.insertReceivedItems(sendA2B, sendB2A, itemB.node);

			// If using ages, increase the age of each item in my cache by 1.
			if (ItemAge.class.isAssignableFrom(gossipConfig.itemClass))
				for (int i = items.size() - 1; i >= 0; i--)
					((ItemAge) items.elementAt(i)).incAge();

			// PAOLO
		}
	    else {
	    	items.remove(itemB);
	    }

	}

	private void insertReceivedItems(Vector received, Vector sent, Node sender) {
		for (int i = 0; i < received.size(); i++)
			insertItem((ItemSim) received.elementAt(i));

		assert items.size() <= gossipConfig.cacheSize;

		// Now try filling up empty slots with items I sent to the other peer.
		int index = 0;
		for (int i = gossipConfig.cacheSize - items.size(); i > 0; i--) {
			if (index >= sent.size())
				break;

			// Now add the sent item back to the sender's cache, of course
			// making sure it's not the sender itself.
			ItemSim sentItem = (ItemSim) sent.elementAt(index);
			if (sentItem.node != sender)
				insertItem(sentItem);

			index++;
		}

		assert items.size() <= gossipConfig.cacheSize;
	}

	private final void insertItem(ItemSim newItem) {
		int foundAt;
		
		// If the 'newItem' is not in the list already, simply put it.
		if ((foundAt = items.indexOf(newItem)) == -1)
			items.add(newItem);

		// Else, we have a duplicate. Keep the prefered one, based
		// on the ItemSim class' criterion.
		else {
			// contained already, at position 'foundAt'
			ItemSim existingItem = (ItemSim) items.elementAt(foundAt);

			// XXX gossipConfig.duplComparator.setReference(refItem);
			if (gossipConfig.duplComparator.compare(newItem, existingItem) < 0)
				items.setElementAt(newItem, foundAt);
		}
	}
}

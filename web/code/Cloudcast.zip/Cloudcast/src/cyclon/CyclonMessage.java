/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package cyclon;

import java.util.*;

import peersim.core.*;

public class CyclonMessage extends CyclonItemArray
{

//---------------------------------------------------------------------
//Static factory
//---------------------------------------------------------------------

static final short CLOUDWRITE = 3;

static final short REPLY = 2;

static final short REQUEST = 1;

//---------------------------------------------------------------------
//Fields
//---------------------------------------------------------------------


protected Node sender;

protected short type;

protected short pid;

protected long time;


// ---------------------------------------------------------------------
// Static factory
// ---------------------------------------------------------------------

/** Buffer containing reusable messages to prevent garbage collection */
private static ArrayList<CyclonMessage>[] buffer = new ArrayList[100];

/**
 * Factory method to get messages. Either it re-use an existing message, or
 * creates a new one if none is available.
 * 
 * @param source
 *          the content to be inserted in the message
 * @param sender
 *          the sender of this message
 * @return
 */
static CyclonMessage getMessage(int capacity)
{
	CyclonMessage msg;
	if (buffer[capacity] == null) 
		buffer[capacity] = new ArrayList<CyclonMessage>();
	if (buffer[capacity].isEmpty()) {
		msg = new CyclonMessage(capacity);
	} else {
		msg = buffer[capacity].remove(buffer[capacity].size() - 1);
		msg.reset();
	}
	return msg;
}

static void release(CyclonMessage msg)
{
	buffer[msg.items.length].add(msg);
}


// ---------------------------------------------------------------------
// Constructor
// ---------------------------------------------------------------------

CyclonMessage(int capacity)
{
	super(capacity);
}

// ---------------------------------------------------------------------
// Methods
// ---------------------------------------------------------------------

/**
 * @return the time
 */
public long getTime()
{
	return time;
}

/**
 * @param time
 *          the time to set
 */
public void setTime(long time)
{
	this.time = time;
}

public Node getSender()
{
	return sender;
}

public void setSender(Node sender)
{
	this.sender = sender;
}

// Comment inherited from interface
public int getType()
{
	return type;
}

// Comment inherited from interface
public void setType(short type)
{
	this.type = type;
}

// Comment inherited from interface
public int getPid()
{
	return pid;
}

// Comment inherited from interface
public void setPid(int pid)
{
	this.pid = (short) pid;
}
}

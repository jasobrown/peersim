package boinc;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Date;

import javax.xml.stream.XMLStreamException;

import cern.jet.random.Uniform;
import cern.jet.random.engine.MersenneTwister;

/**
 * A tool for random shuffling records in a BOINC trace file.
 * Works in a finite amount of memory (RAM).
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class ShuffleConstMem {

	public static final int BUFFER_SIZE = 500000;
	
	public static void main(String[] args) {
		if (args.length < 2 || args.length > 4) {
			System.out.println("Usage: java ShuffleConstMem <trace-file> <out-file> [buffer-size] [max-entries]");
			return;
		}
		
		try {
			String traceFile = args[0];
			BoincParser parser = new BoincParser(traceFile); 
	
			String outFile = args[1];
			OutputStream outStream = new FileOutputStream(outFile);
			OutputStreamWriter writer = new OutputStreamWriter(outStream);

			int bufSize = BUFFER_SIZE;
			if (args.length > 2) {
				bufSize = Integer.parseInt(args[2]);
			}

			int limit = Integer.MAX_VALUE;
			if (args.length > 3) {
				limit = Integer.parseInt(args[3]);
			}

			BoincHost[] buffer = new BoincHost[bufSize];
			
			System.out.println("Counting records...");
			int count = 0;
			for (;;) {
				BoincHost host = parser.readHost();
				if (host == null) {
					break;
				}
				else {
					count++;
				}
				if (count % 10000 == 0) {
					System.out.print("*");
				}
			}

			System.out.println();
			System.out.println("Parsed " + count + " host entries");
			
			System.out.print("Generating random order...");
			int[] order = new int[count];
			for (int i = 0; i < count; i++) {
				order[i] = i;
			}
			Uniform uniform = new Uniform(new MersenneTwister(new Date()));
			for (int i = 0; i < count - 1; i++) {
				int r = uniform.nextIntFromTo(i, count - 1);
				// Swap i with r
				int tmp = order[i];
				order[i] = order[r];
				order[r] = tmp;
			}
			System.out.println(" done");

			int from = 0;
			int to = 0;
			int writeCount = 0;
			do {
				from = to;
				to = from + bufSize;
				if (to > count) to = count;
				if (to > limit) to = limit;
				
				System.out.println("Searching entries from " + from + " to " + to + "...");
				parser = new BoincParser(traceFile);
				
				for (int i = 0; i < count; i++) {
					BoincHost host = parser.readHost();
					
					if (from <= order[i] && order[i] < to) {
						buffer[order[i] - from] = host;
					}
					if (i % 10000 == 9999) {
						System.out.print("*");
					}
				}

				System.out.println();
				System.out.println("Writting entries from " + from + " to " + to + "...");
				
				if (from == 0) {
					writer.write("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n");
					writer.write("<hosts>\n");
				}

				for (int i = from; i < to; i++) {
					writer.write(buffer[i - from].toString());
					writer.write("\n");
					writeCount++;
					
					if (i % 10000 == 9999) {
						System.out.print("*");
					}
				}
				System.out.println();
			}
			while (to < count && to < limit);
			
			parser.close();
			writer.write("</hosts>\n");
			writer.close();
			System.out.println("Finished. Shuffled " + writeCount + " host entries");
		} 
		catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
		}
		catch (NumberFormatException e) {
			System.out.println("Invalid limit: " + args[2]);
		}
		catch (XMLStreamException e) {
			System.out.println("Read error: " + e.getMessage());
		}
		catch (IOException e) {
			System.out.println("Write error: " + e.getMessage());
		}
	}

}

package peersim.skipnet;

import peersim.core.Node;

public final class SkipnetUtil {

	public enum Direction {LEFT, RIGHT}
	
	public enum Events {JOIN, PINGNEIGHBORS, FIXUP, LEAFSETCONSTRUCTION}
	
	public enum Errors {NUMERIC_ID_ALREADY_EXISTS}
	
	public static Direction inverseDirection(Direction dir) {
		return dir==Direction.LEFT?Direction.RIGHT:Direction.LEFT;
	}
	
	public static SkipnetName getSkipnetName(Node node, int pid) {
		SkipnetName nbrId = getSkipnetProtocol(node, pid).getLocalname();
		return nbrId;
	}
	
	public static NumericId getNumericId(Node node, int pid) {
		return getSkipnetProtocol(node, pid).getLocalNumId();
	}

	public static Skipnet getSkipnetProtocol(Node node, int pid) {
		return (Skipnet) node.getProtocol(pid);
	}
}

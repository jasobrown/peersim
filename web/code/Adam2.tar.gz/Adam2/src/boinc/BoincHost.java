package boinc;

/**
 * An object representing one host entry in a BOINC trace file.
 * More on BOINC traces can be found here:
 * http://boinc.berkeley.edu/trac/wiki/XmlStats
 * 
 * Some BOINC trace files can be downloaded from
 * the SETI@home project:
 * http://setiathome.berkeley.edu/stats/
 * 
 * @author Jan Sacha
 *
 */
public class BoincHost {
	
	public int id;
	public int userid;
	public double total_credit;
	public double expavg_credit;
	public double expavg_time;
	public String p_vendor;
	public String p_model;
	public String os_name;
	public String os_version;
	public long create_time;
	public long rpc_time;
	public int timezone;
	public int ncpus;
	public double p_fpops;
	public double p_iops;
	public double p_membw;
	public long m_nbytes;
	public long m_cache;
	public long m_swap;
	public long d_total;
	public long d_free;
	public double n_bwup;
	public double n_bwdown;
	public double avg_turnaround;
	public double credit_per_cpu_sec;
	public String host_cpid;

	
	public String toString() {
		return "<host>\n" +
		"  <id>" + id + "</id>\n" +
		"  <userid>" + userid + "</userid>\n" +
		"  <total_credit>" + total_credit + "</total_credit>\n" +
		"  <expavg_credit>" + expavg_credit + "</expavg_credit>\n" +
		"  <expavg_time>" + expavg_time + "</expavg_time>\n" +
		"  <p_vendor>" + p_vendor + "</p_vendor>\n" +
		"  <p_model>" + p_model + "</p_model>\n" +
		"  <os_name>" + os_name + "</os_name>\n" +
		"  <os_version>" + os_version + "</os_version>\n" +
		"  <create_time>" + create_time + "</create_time>\n" +
		"  <rpc_time>" + rpc_time + "</rpc_time>\n" +
		"  <timezone>" + timezone + "</timezone>\n" +
		"  <ncpus>" + ncpus + "</ncpus>\n" +
		"  <p_fpops>" + p_fpops + "</p_fpops>\n" +
		"  <p_iops>" + p_iops + "</p_iops>\n" +
		"  <p_membw>" + p_membw + "</p_membw>\n" +
		"  <m_nbytes>" + m_nbytes + "</m_nbytes>\n" +
		"  <m_cache>" + m_cache + "</m_cache>\n" +
		"  <m_swap>" + m_swap + "</m_swap>\n" +
		"  <d_total>" + d_total + "</d_total>\n" +
		"  <d_free>" + d_free + "</d_free>\n" +
		"  <n_bwup>" + n_bwup + "</n_bwup>\n" +
		"  <n_bwdown>" + n_bwdown + "</n_bwdown>\n" +
		"  <avg_turnaround>" + avg_turnaround + "</avg_turnaround>\n" +
		"  <credit_per_cpu_sec>" + credit_per_cpu_sec + "</credit_per_cpu_sec>\n" +
		"  <host_cpid>" + host_cpid + "</host_cpid>\n" +
		"</host>";
	}
	
}

package peersim.skipnet.messages;

import peersim.core.Node;
import peersim.skipnet.SkipnetUtil.*;

public class DisconnectionMessage extends SkipnetMessage {

	public int level;
	public Direction direction;
	public Node newNeighbor;
	
	public DisconnectionMessage(Node source, Node nextHop) {
		super(source, nextHop);
		// TODO Auto-generated constructor stub
	}

}

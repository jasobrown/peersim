/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh;

import peersim.config.*;
import peersim.core.*;
import peersim.edsim.*;


public class GoshPSO implements EDProtocol, Gosh
{

//---------------------------------------------------------------------
//CommonData
//---------------------------------------------------------------------

/**
* @config
*/
private static final String PAR_PARTICLES = "particles";

/**
 * @config
 */
private static final String PAR_FUNCTION = "function";

/**
 * @config
 */
private static final String PAR_W = "w";
/**
 * @config
 */
private static final String PAR_C1 = "c1";
/**
 * @config
 */
private static final String PAR_C2 = "c2";

//---------------------------------------------------------------------
//Fields
//---------------------------------------------------------------------

/** Current best value */
private double[] best;

/** Current best value */
private double bestval;

/** Current particle being evaluated */
private int current;

/** */
private Particle[] particles;

/** */
private PSOConfig pc;

//---------------------------------------------------------------------
//Constructor
//---------------------------------------------------------------------

public GoshPSO(String prefix)
{
	
	Function f = (Function) Configuration.getInstance(prefix + "." + PAR_FUNCTION);
	double w = Configuration.getInt(prefix + "." + PAR_W);
	double c1 = Configuration.getInt(prefix + "." + PAR_C1);
	double c2 = Configuration.getInt(prefix + "." + PAR_C2);
	int size = Configuration.getInt(prefix + "." + PAR_PARTICLES);
	init(size, new PSOConfig(f,w,c1,c2));
}

public Object clone() 
{
	GoshPSO ret = null;
	try {
		ret = (GoshPSO) super.clone();
	} catch (CloneNotSupportedException e) {
	}
	ret.init(particles.length, pc);
	return ret;
}

private void init(int size, PSOConfig pc)
{
	this.pc = pc;
	bestval = Double.MAX_VALUE;
	best = new double[pc.f.d()];
	particles = new Particle[size];
	for (int i=0; i < size; i++) {
		particles[i] = new Particle();
	}
	current = 0;
	long delay = pc.f.getTime();
	EDSimulator.add(delay, this, CommonState.getNode(), CommonState.getPid());
}


//---------------------------------------------------------------------
//Methods
//---------------------------------------------------------------------

int count = 0;

public int getCount()
{
	return count;
}

public void processEvent(Node node, int pid, Object event)
{
	count++;
	
	particles[current].update(pc, best, bestval);
	if (particles[current].lbestval < bestval) {
		bestval = particles[current].lbestval;
		System.arraycopy(particles[current].lbest, 0, best, 0, pc.f.d());
	}
	current = (current+1)%particles.length;
	long delay = pc.f.getTime();
	EDSimulator.add(delay, this, CommonState.getNode(), CommonState.getPid());
}


public double getValue()
{
	return bestval;
}

public double[] getBest()
{
	return best;
}

public void setValue(double value)
{
	this.bestval = value;
}

public void setBest(double[] best)
{
	this.best = best;
}

}

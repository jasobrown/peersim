package boinc;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.xml.stream.XMLStreamException;


/**
 * A tool that extracts a "snapshot" from a BOINC trace file, i.e., hosts that
 * exist at a given time.
 * 
 * @author Jan Sacha <jsacha@cs.vu.nl>
 */
public class Snapshot {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length != 3) {
			System.out.println("Usage: java Snapshot <dd-mm-yyyy> <trace-file> <out-file>");
			return;
		}
		
		try {
			String dateString = args[0];
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			long date = dateFormat.parse(dateString).getTime() / 1000;
			
			String traceFile = args[1];
			BoincParser parser = new BoincParser(traceFile); 
			
			String outFile = args[2];
			OutputStream outStream = new FileOutputStream(outFile);
			OutputStreamWriter writer = new OutputStreamWriter(outStream);

			writer.write("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n");
			writer.write("<hosts>\n");
			
			System.out.println("Parsing...");
			int parsed = 0;
			int selected = 0;
			for (;;) {
				BoincHost host = parser.readHost(); 	
				
				if (host == null) {
					// End of trace
					writer.write("</hosts>\n");
					writer.close();
					parser.close();
					break;
				}
				else {
					parsed++;
					if (host.create_time <= date && host.rpc_time >= date) {
						selected++;
						writer.write(host.toString());
						writer.write("\n");
					}
					if (parsed % 10000 == 0) {
						System.out.print("*");
					}
				}
			}
			System.out.println();
			System.out.println("Parsed " + parsed + " host entries. Selected " + selected + " entries.");
		} 
		catch (FileNotFoundException e) {
			System.out.println("File not found: " + e.getMessage());
		}
		catch (ParseException e) {
			System.out.println("Invalid date: " + args[0]);
		} 
		catch (XMLStreamException e) {
			System.out.println("Read error: " + e.getMessage());
		} 
		catch (IOException e) {
			System.out.println("Write error: " + e.getMessage());
		}
	}

}

/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.peersim.dynamics;

import peersim.core.*;
import peersim.config.*;
import peersim.dynamics.*;
//for GAP
import java.util.HashMap;
import java.util.Iterator;
import peersim.transport.Transport;
import lehurament.AggregateEDggapRestart.*;
/**
 * Initializes the neighbor list of a node with random links.
 */
public class RandNIforGGAPRestartOnlineChurn implements NodeInitializer {


//--------------------------------------------------------------------------
//Parameters
//--------------------------------------------------------------------------

	
private static final String PAR_GAPPROT = "GAPprotocol";	
/**
 * The protocol to operate on.
 * @config
 */
private static final String PAR_PROT = "protocol";

/**
 * The number of samples (with replacement) to draw to initialize the
 * neighbor list of the node.
 * @config
 */
private static final String PAR_DEGREE = "k";

/**
 * If this config property is defined, method {@link Linkable#pack()} is 
 * invoked on the specified protocol at the end of the wiring phase. 
 * Default to false.
 * @config
 */
private static final String PAR_PACK = "pack";


private static final String PAR_INITVALUE = "initvalue";

private static final String PAR_INITWEIGHT = "initweight";
//--------------------------------------------------------------------------
//Fields
//--------------------------------------------------------------------------

private final int GAPpid;
/**
 * The protocol we want to wire
 */
private final int pid;

/**
 * The degree of the regular graph
 */
private final int k;

private final int initvalue;
private final boolean initweight;
/**
 * If true, method pack() is invoked on the initialized protocol
 */
private final boolean pack;


//--------------------------------------------------------------------------
//Initialization
//--------------------------------------------------------------------------

/**
 * Standard constructor that reads the configuration parameters. Invoked by the
 * simulation engine.
 * @param prefix the configuration prefix for this class
 */
public RandNIforGGAPRestartOnlineChurn(String prefix)
{
	GAPpid = Configuration.getPid(prefix + "." + PAR_GAPPROT);
	pid = Configuration.getPid(prefix + "." + PAR_PROT);
	k = Configuration.getInt(prefix + "." + PAR_DEGREE);
	pack = Configuration.contains(prefix + "." + PAR_PACK);
	initvalue = Configuration.getInt(prefix + "." + PAR_INITVALUE);
	initweight = Configuration.getBoolean(prefix + "." + PAR_INITWEIGHT);
}

//--------------------------------------------------------------------------
//Methods
//--------------------------------------------------------------------------

/**
 * Takes {@value #PAR_DEGREE} random samples with replacement from the nodes of
 * the overlay network. No loop edges are added.
 */

public void initialize(Node n)
{
	if (Network.size() == 0) return;
	AggregateEDggapRestart prot = (AggregateEDggapRestart) n.getProtocol(GAPpid);
//	prot.value=initvalue;
//	if (initweight) prot.weight=0; else prot.weight=1;
//	prot.realvalue=initvalue;
	/**
	 * Vajon lealis e ezeket a kov parametereket nullazni???
	 */
//	prot.epochID=0;
//	prot.epochFreqCount=0;
//	prot.sync=false;
//	System.out.println("BETEVE "+n.getID());
//	 System.out.println("\u001B[41m"+"VisszaJOTT: "+n.getID()+" "+prot+"\u001B[0m");
	ggapRestartPacket p=new ggapRestartPacket();
	p.type=p.type.NEW;
	p.from=n;
	lehurament.AggregateEDggapRestart.SendPacketToNeighbours.broadcastPacket(n,GAPpid, p);
}
}

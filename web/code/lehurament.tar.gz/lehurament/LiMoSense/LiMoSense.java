/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.LiMoSense;

import java.lang.Math;
import lehurament.peersim.dynamics.Churnable;
import lehurament.peersim.dynamics.ChurnControl;
import peersim.config.*;
import peersim.core.*;
import peersim.cdsim.CDProtocol;
import peersim.edsim.EDProtocol;

/**
* Event driven version of epidemic averaging LiMoSense.
*/
public class LiMoSense extends LiMoSenseSingleTableHolder
implements CDProtocol, EDProtocol, Cleanable, Churnable{

	public static int packetCount;
	/**
	 * globalization of a given parameters for onKill()
	 */
	private int pid;
	private long nodeID;
	private Node node;
	private final boolean initweight;
	private static final String PAR_INITWEIGHT = "sum";
	private long sessionLength = ChurnControl.INIT_SESSION_LENGTH;
//--------------------------------------------------------------------------
// Initialization
//--------------------------------------------------------------------------
/**
 * @param prefix string prefix for config properties
 */
public LiMoSense(String prefix) { 
		super(prefix);
		initweight = Configuration.getBoolean(prefix + "." + PAR_INITWEIGHT);
}

//--------------------------------------------------------------------------
// methods
//--------------------------------------------------------------------------

public double getAverage() {
	LiMoSense p = (LiMoSense) Network.get(0).getProtocol(pid);
	return p.est.value;
}
public long getPacketCount() {
	return packetCount;
}
public void setRealValue(double value) {
	this.realvalue = value;
	if ((this.est.weight)==0) {
		return;
	}
	this.est.value += (value-this.prerealvalue)/this.est.weight;	
	this.prerealvalue = value;
}
LiMoSensePair sumOperation (LiMoSensePair a, LiMoSensePair b) {
	if ((a.weight+b.weight)==0) return new LiMoSensePair(0,0);
	a.weight=a.weight + 0.0;
	b.weight=b.weight + 0.0;
	double retValue=(a.value*a.weight+b.value*b.weight)/(a.weight+b.weight);
	double retWeight=a.weight+b.weight;
	return new LiMoSensePair(retValue,retWeight); 
}

LiMoSensePair subOperation (LiMoSensePair a, LiMoSensePair b) {
	LiMoSensePair minb = new LiMoSensePair(b.value,-b.weight);
	return sumOperation(a,minb);
}

public void pushSend(Node node,Node peer,int pid, LiMoSensePair sendVal)
{
	est=subOperation(est,sendVal);
	table.get(peer.getID()).estSent=sumOperation(table.get(peer.getID()).estSent,sendVal);
	LiMoSensePacket p = new LiMoSensePacket(table.get(peer.getID()).estSent,node);
	p.type=LiMoSensePacket.types.UPDATEPUSH;
	sendPacketToNode(node,peer,pid,p);
}
public void nextCycle( Node node, int pid ) {
	if (est.weight<2*0.00001) return;
	double part=0;
	Linkable linkable = (Linkable) node.getProtocol(FastConfig.getLinkable(pid));
   	int degree = 0;
	long nodeID = node.getID();
	/*	We will find out the real upnode degree of neighbours
	*/
	for (int i = 0; i < linkable.degree(); ++i) {
		Node peer = linkable.getNeighbor(i);
		if (!peer.isUp()) continue;
		degree+=1;
	}
	part = 1f / (degree+1);
	/*	We will subtract the share from the corresponding table row, the share which will be sent to neighbor node
	*/
	for (int i = 0; i < linkable.degree(); ++i) {
		Node peer = linkable.getNeighbor(i);
		if (!peer.isUp()) continue;
			if (table.get(peer.getID())==null) {
				newEntry(peer); 
			} 
		if (CommonState.r.nextLong(2)==1) {
			pushSend(node,peer,pid,new LiMoSensePair(est.value,est.weight*part));
		}
		else {
			LiMoSensePacket p = new LiMoSensePacket(new LiMoSensePair(est.value,est.weight*part),node);
			p.type=LiMoSensePacket.types.UPDATEPULL;
			sendPacketToNode(node,peer,pid,p);
		}
	}
}

public void processEvent( Node node, int pid, Object event ) {
	this.nodeID= node.getID();
	this.pid= pid;
	this.node=node;
	LiMoSensePacket e = (LiMoSensePacket)event;
/* necessary when NEWSCAST is on, when node got a new neighbour, the node and the new neighbour will receive NEW packets. We must create a table row for broadcast function.
*/
	if (e.type==e.type.FAIL || e.type==e.type.NEW )	
	if (table.get(e.from)!=null )
		if ((e.nodeNEWFAILPacketCount<table.get(e.from).nodeNEWFAILPacketCount) ) 
		{
			return;
		}
		if (e.type==e.type.NEW) {
			newEntry(e.nodeFrom);
		}
		if (e.type==e.type.FAIL) {
			LiMoSenseRow r=table.get(e.nodeFrom.getID());
			if (r!=null){
				this.est = subOperation(sumOperation(this.est,r.estSent),r.estReceived);
				removeEntry(e.nodeFrom.getID());
				r=null;
				newEntry(e.nodeFrom);
			}	
		}
		if (e.type==e.type.UPDATEPUSH) {
			{
				if (table.get(e.nodeFrom.getID())==null) {
					newEntry(e.nodeFrom);
				}				
				LiMoSenseRow r=table.get(e.nodeFrom.getID());
				LiMoSensePair diff = new LiMoSensePair(0,0);
				diff=subOperation(e.est,r.estReceived);	
				est=sumOperation(est,diff);
				r.estReceived=e.est;			
			}
		}
		if (e.type==e.type.UPDATEPULL) {
				if (table.get(e.nodeFrom.getID())==null) {
					newEntry(e.nodeFrom);
				}
			pushSend(node,e.nodeFrom,pid,new LiMoSensePair(e.est.value,-e.est.weight));
		}
		if (table.get(e.from)!=null) if (e.type==e.type.FAIL || e.type==e.type.NEW) table.get(e.from).nodeNEWFAILPacketCount=e.nodeNEWFAILPacketCount;

}
public void onKill() {
	LiMoSensePacket p=new LiMoSensePacket();
	p.type=p.type.FAIL;
	p.nodeFrom=node;
	table.clear();
	if (node!=null) broadcastPacket(node,pid, p);
}

public void initSession(Node node, int protocol) {
}
public void forUpNodes(Node node, int protocol) {
	LiMoSense prot = (LiMoSense) node.getProtocol(protocol);
	if (initweight) prot.est.weight=0; else prot.est.weight=1;
	prot.est.value=0;
	prot.prerealvalue=0;
}
/*	Online Churn uses this when node goes to offline
*/
public void forDownNodes(Node node, int protocol) {
	onKill();
}
public long getSessionLength() {
  return sessionLength;
}
public void setSessionLength(long sessionLength) {
  this.sessionLength = sessionLength;
}
}



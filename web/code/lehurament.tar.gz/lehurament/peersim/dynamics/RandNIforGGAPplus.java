/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.peersim.dynamics;

import peersim.core.*;
import peersim.config.*;
import peersim.dynamics.*;
//for GAPs
import java.util.HashMap;
import java.util.Iterator;
import peersim.transport.Transport;
import lehurament.AggregateEDggapPlus.*;
/**
 * Initializes the neighbor list of a node with random links.
 */
public class RandNIforGGAPplus implements NodeInitializer {


//--------------------------------------------------------------------------
//Parameters
//--------------------------------------------------------------------------

	
private static final String PAR_GAPPROT = "GAPprotocol";	
/**
 * The protocol to operate on.
 * @config
 */
private static final String PAR_PROT = "protocol";

/**
 * The number of samples (with replacement) to draw to initialize the
 * neighbor list of the node.
 * @config
 */
private static final String PAR_DEGREE = "k";

/**
 * If this config property is defined, method {@link Linkable#pack()} is 
 * invoked on the specified protocol at the end of the wiring phase. 
 * Default to false.
 * @config
 */
private static final String PAR_PACK = "pack";


private static final String PAR_INITVALUE = "initvalue";

private static final String PAR_INITWEIGHT = "initweight";
//--------------------------------------------------------------------------
//Fields
//--------------------------------------------------------------------------

private final int GAPpid;
/**
 * The protocol we want to wire
 */
private final int pid;

/**
 * The degree of the regular graph
 */
private final int k;

private final int initvalue;

private final boolean initweight;
/**
 * If true, method pack() is invoked on the initialized protocol
 */
private final boolean pack;

private HashMap<Integer, rowGGap> table;//the neighbor table

//--------------------------------------------------------------------------
//Initialization
//--------------------------------------------------------------------------

/**
 * Standard constructor that reads the configuration parameters. Invoked by the
 * simulation engine.
 * @param prefix the configuration prefix for this class
 */
public RandNIforGGAPplus(String prefix)
{
	GAPpid = Configuration.getPid(prefix + "." + PAR_GAPPROT);
	pid = Configuration.getPid(prefix + "." + PAR_PROT);
	k = Configuration.getInt(prefix + "." + PAR_DEGREE);
	pack = Configuration.contains(prefix + "." + PAR_PACK);
	initvalue = Configuration.getInt(prefix + "." + PAR_INITVALUE);
	initweight = Configuration.getBoolean(prefix + "." + PAR_INITWEIGHT);
}

//--------------------------------------------------------------------------
//Methods
//--------------------------------------------------------------------------

/**
 * Takes {@value #PAR_DEGREE} random samples with replacement from the nodes of
 * the overlay network. No loop edges are added.
 */
public void initialize(Node n)
{
	if (Network.size() == 0) return;
	//putGGAPTable(n);
	AggregateEDggapPlus prot = (AggregateEDggapPlus) n.getProtocol(GAPpid);
	prot.value=prot.realvalue;
	if (initweight) prot.weight=0; else prot.weight=1;
//	prot.realvalue=initvalue;
	
//	ggapPlusPacket p=new ggapPlusPacket();
//	p.type=p.type.UPDATELOCAL;
//	p.from=(int) n.getID();
//	p.value=initvalue;
//	p.weight=initweight;
//	lehurament.AggregateEDggapPlus.SendPacketToNeighbours.sendPacketToNode(n,n, GAPpid, p);
//	 System.out.println("BETEVE: "+n.getID());
//	 printN(n);
}
//void newEntry(int id) {
//	rowGGap r=new rowGGap();
//	r.aggregate=0;
//	r.weight=0;
//	table.put(id, r);
//}
//public void putGGAPTable(Node n) {
//    	table=new HashMap<Integer, rowGGap>();
// 		AggregateEDggapPlus prot = (AggregateEDggapPlus) n.getProtocol(GAPpid);
// 		Linkable linkable = (Linkable) n.getProtocol(pid);
//	 		for (int j = 0; j < linkable.degree(); ++j) {
//	 	   		Node peer = linkable.getNeighbor(j);
//	 			newEntry((int) peer.getID());
//	 		}
// 		prot.setTable(table);
//		prot.setValue(0);
//}
public void printN(Node n) {
	AggregateEDggapPlus prot = (AggregateEDggapPlus) n.getProtocol(GAPpid);
	Linkable linkable = (Linkable) n.getProtocol(pid);
		for (int j = 0; j < linkable.degree(); ++j) {
	   		Node peer = linkable.getNeighbor(j);
//	   	 System.out.println("Node "+n.getID()+"> "+(int) peer.getID());
		}
}
}

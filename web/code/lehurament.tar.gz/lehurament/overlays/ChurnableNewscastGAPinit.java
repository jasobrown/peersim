/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.overlays;

import peersim.core.*;
import peersim.config.*;
import java.util.HashMap;
import lehurament.CommonForGAPs.*;
/**
 */
public class ChurnableNewscastGAPinit implements ChurnableNewscastNodeInitializer {


//--------------------------------------------------------------------------
//Parameters
//--------------------------------------------------------------------------

	
private static final String PAR_GAPPROT = "GAPprotocol";	

//--------------------------------------------------------------------------
//Fields
//--------------------------------------------------------------------------

private final int GAPpid;

private HashMap<Long, row> table;//the neighbor table

//--------------------------------------------------------------------------
//Initialization
//--------------------------------------------------------------------------

/**
 * Standard constructor that reads the configuration parameters. Invoked by the
 * simulation engine.
 * @param prefix the configuration prefix for this class
 */
public ChurnableNewscastGAPinit(String prefix)
{
	GAPpid = Configuration.getPid(prefix + "." + PAR_GAPPROT);
}

//--------------------------------------------------------------------------
//Methods
//--------------------------------------------------------------------------

/**
 */

public void initialize(Node n, Node to)
{
	if (Network.size() == 0) return;
	GAPVariablesHolder prot = (GAPVariablesHolder) n.getProtocol(GAPpid);
	GAPPacket p=new GAPPacket();
	p.type=p.type.NEW;
	p.from=n.getID();
	p.nodeFrom=n;
	prot.sendPacketToNode(n,to, GAPpid, p);
//	System.out.println("|| Node-"+to.getID()+" HAS NEW NEIGHOUR(SENT NEW PACKET): "+n.getID()+" ||");
	GAPVariablesHolder prot1 = (GAPVariablesHolder) to.getProtocol(GAPpid);
	GAPPacket p1=new GAPPacket();
	p1.type=p1.type.NEW;
	p1.from=to.getID();
	p1.nodeFrom=to;
	prot1.sendPacketToNode(to,n, GAPpid, p1);
//	System.out.println("|| Node-"+n.getID()+" HAS NEW NEIGHOUR(SENT NEW PACKET): "+to.getID()+" ||");
}
}

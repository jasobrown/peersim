/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.LiMoSense;

import peersim.core.*;

public class LiMoSensePacket extends Packet {
	public LiMoSensePair est;
	public static enum types {NEW, FAIL, UPDATEPUSH, UPDATEPULL, UPDATELOCAL};
	public types type;	
	public Node nodeFrom;
	int nodeNEWFAILPacketCount;
	public LiMoSensePacket() {
		type=types.UPDATEPUSH;
		nodeFrom=null;
			est=new LiMoSensePair(0,0);
	}
	
	public LiMoSensePacket(LiMoSensePair est, Node nodeFrom) {
		type=types.UPDATEPUSH;
		this.est=est;
		this.nodeFrom=nodeFrom;
	}
	boolean equals(LiMoSensePacket p) {
		return ( this.est.equals(p.est));
	}
}

abstract class Packet {
	/**
	 * sorce of packet.
	 */
	int from;
	/**
	 * destination of packet.
	 */
	int to;
/**
 * set both to -1, the broadcast address
 *
 */
	Packet() {
		to = from = -1;
	}
}

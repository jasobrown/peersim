package peersim.skipnet.messages;

import peersim.core.Node;
import peersim.skipnet.*;

public class JoinRequest extends NumericRoutingMessage {
	
	public SkipnetName nameid;
	
	public boolean doInsertions = false;

	public JoinRequest(SkipnetName nameid, Node source, Node destination) {
		super(source, destination);
		this.nameid = nameid;
	}

}

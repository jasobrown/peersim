/*
 * Copyright (c) 2014 project TAMOP-4.2.2.C-11/1/KONV-2012-0013
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package lehurament.AggregateObservers;

import peersim.config.*;
import peersim.core.*;

/**
 */
public class SetVectForGAPSin extends peersim.vector.VectControl
{

// --------------------------------------------------------------------------
// Parameter names
// --------------------------------------------------------------------------

/**
 * @config
 */
private static final String PAR_CORRELATION_FACTOR="correlationFactor";
private static final String PAR_PERIODS = "periods";
private static final String PAR_CYCLES = "cycles";
// --------------------------------------------------------------------------
// Fields
// --------------------------------------------------------------------------

private final double correlationFactor;
private final int periods;
private final int cycles;
private int count=0;

// --------------------------------------------------------------------------
// Initialization
// --------------------------------------------------------------------------

/**
 * Standard constructor that reads the configuration parameters.
 * Invoked by the simulation engine.
 * @param prefix the configuration prefix for this class
 */
public SetVectForGAPSin(String prefix)
{
	super(prefix);
	correlationFactor = Configuration.getDouble(prefix + "." + PAR_CORRELATION_FACTOR);
    periods = Configuration.getInt(prefix + "." + PAR_PERIODS);
    cycles = Configuration.getInt(prefix + "." + PAR_CYCLES);
}

// --------------------------------------------------------------------------
// Methods
// --------------------------------------------------------------------------

/**
 * @return always false
 */
public boolean execute() {
	for (int i = 0; i < Network.size(); i++) 
		{
			double sin = 46*(1+0.5*Math.sin(count*Math.PI*2*periods/(cycles)-Math.PI*i*correlationFactor/Network.size()));
			setter.set(i,sin);
		}
	count+=1;
	return false;
}

// --------------------------------------------------------------------------

}

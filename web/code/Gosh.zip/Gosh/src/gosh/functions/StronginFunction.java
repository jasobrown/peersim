/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package gosh.functions;

import gosh.*;
import peersim.core.CommonState;
import peersim.config.*;

// d=30 ; opt.=0.0 NEEDS conf. parameter seed (positive 32bit)
public class StronginFunction extends FixedTimeAbstractFunction
{

/**
 * Number of dimensions to be considered
 * @config
 */
private static final String PAR_D = "d";

private final int d;

private final double[] rangeMin;

private final double[] rangeMax;

//private static final String PAR_SEED = "seed";

//private long seed;  // must be positive

private double A[][];
private double B[][];
private double C[][];
private double D[][];

public StronginFunction(String prefix)
{
	super(prefix);
	d = Configuration.getInt(prefix + "." + PAR_D);

//        seed = Configuration.getLong(prefix + "." + PAR_SEED);
        createTables();

        rangeMin = new double[d];
	rangeMax = new double[d];
  for ( int i = 0; i < d; i++ ) {
    rangeMin[i] = 0.0;
    rangeMax[i] = 1.0;
  }
}

public double eval(double[] x)
{
  int	i, j;

 double	a[][] = new double[7][7];
 double	b[][] = new double[7][7];

 double	s1, s2;

 for (i = 0; i < 7; ++i)
     for (j = 0; j < 7; ++j)
     {
       a[i][j] = StrictMath.sin(i*StrictMath.PI*x[0]) * StrictMath.sin(j*StrictMath.PI*x[1]);
       b[i][j] = StrictMath.cos(i*StrictMath.PI*x[0]) * StrictMath.cos(j*StrictMath.PI*x[1]);
     }
 s1 = 0;
 s2 = 0;
 for (i = 0; i < 7; ++i)
         for (j = 0; j < 7; ++j)
                 {
                   s1 += A[i][j] * a[i][j] + B[i][j] * b[i][j];
                   s2 += C[i][j] * a[i][j] - D[i][j] * b[i][j];
                 }

 return StrictMath.sqrt(s1*s1+s2*s2);
}

public double[] getRangeMax()
{
	return rangeMax;
}

public double[] getRangeMin()
{
	return rangeMin;
}

public int d()
{
	return d;

}

 private void createTables()
{
 int i,j;
 //java.util.Random rand = new java.util.Random (seed);
 A = new double[7][7];
 B = new double[7][7];
 C = new double[7][7];
 D = new double[7][7];
 for (i = 0; i < 7; ++i)
    for (j = 0; j < 7; ++j) {  //  between -1 and 1
      A[i][j] = 2*CommonState.r.nextDouble()-1.0;
      B[i][j] = 2*CommonState.r.nextDouble()-1.0;
      C[i][j] = 2*CommonState.r.nextDouble()-1.0;
      D[i][j] = 2*CommonState.r.nextDouble()-1.0;
    }
}

}
